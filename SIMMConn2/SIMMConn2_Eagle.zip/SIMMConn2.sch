<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="7.7.0">
<drawing>
<settings>
<setting alwaysvectorfont="no"/>
<setting verticaltext="up"/>
</settings>
<grid distance="50" unitdist="mil" unit="mil" style="dots" multiple="1" display="yes" altdistance="10" altunitdist="mil" altunit="mil"/>
<layers>
<layer number="1" name="Top" color="4" fill="1" visible="no" active="no"/>
<layer number="2" name="BV" color="4" fill="3" visible="no" active="no"/>
<layer number="3" name="Route3" color="4" fill="3" visible="no" active="no"/>
<layer number="4" name="Route4" color="1" fill="4" visible="no" active="no"/>
<layer number="5" name="Route5" color="4" fill="4" visible="no" active="no"/>
<layer number="6" name="Route6" color="1" fill="8" visible="no" active="no"/>
<layer number="7" name="Route7" color="4" fill="8" visible="no" active="no"/>
<layer number="8" name="Route8" color="1" fill="2" visible="no" active="no"/>
<layer number="9" name="Route9" color="4" fill="2" visible="no" active="no"/>
<layer number="10" name="Route10" color="1" fill="7" visible="no" active="no"/>
<layer number="11" name="Route11" color="4" fill="7" visible="no" active="no"/>
<layer number="12" name="Route12" color="1" fill="5" visible="no" active="no"/>
<layer number="13" name="Route13" color="4" fill="5" visible="no" active="no"/>
<layer number="14" name="Route14" color="1" fill="6" visible="no" active="no"/>
<layer number="15" name="AV" color="1" fill="6" visible="no" active="no"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="no" active="no"/>
<layer number="17" name="Pads" color="2" fill="1" visible="no" active="no"/>
<layer number="18" name="Vias" color="3" fill="1" visible="no" active="no"/>
<layer number="19" name="Unrouted" color="5" fill="1" visible="no" active="no"/>
<layer number="20" name="Dimension" color="10" fill="1" visible="no" active="no"/>
<layer number="21" name="tPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="22" name="bPlace" color="8" fill="1" visible="no" active="no"/>
<layer number="23" name="tOrigins" color="14" fill="1" visible="no" active="no"/>
<layer number="24" name="bOrigins" color="6" fill="1" visible="no" active="no"/>
<layer number="25" name="tNames" color="7" fill="1" visible="no" active="no"/>
<layer number="26" name="bNames" color="8" fill="1" visible="no" active="no"/>
<layer number="27" name="tValues" color="7" fill="1" visible="no" active="no"/>
<layer number="28" name="bValues" color="8" fill="1" visible="no" active="no"/>
<layer number="29" name="tStop" color="15" fill="3" visible="no" active="no"/>
<layer number="30" name="bStop" color="15" fill="6" visible="no" active="no"/>
<layer number="31" name="tCream" color="13" fill="4" visible="no" active="no"/>
<layer number="32" name="bCream" color="5" fill="5" visible="no" active="no"/>
<layer number="33" name="tFinish" color="6" fill="3" visible="no" active="no"/>
<layer number="34" name="bFinish" color="6" fill="6" visible="no" active="no"/>
<layer number="35" name="tGlue" color="7" fill="4" visible="no" active="no"/>
<layer number="36" name="bGlue" color="7" fill="5" visible="no" active="no"/>
<layer number="37" name="tTest" color="7" fill="1" visible="no" active="no"/>
<layer number="38" name="bTest" color="7" fill="1" visible="no" active="no"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="no" active="no"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="no" active="no"/>
<layer number="41" name="tRestrict" color="4" fill="7" visible="no" active="no"/>
<layer number="42" name="bRestrict" color="1" fill="7" visible="no" active="no"/>
<layer number="43" name="vRestrict" color="5" fill="7" visible="no" active="no"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="no"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="no"/>
<layer number="46" name="Milling" color="3" fill="1" visible="no" active="no"/>
<layer number="47" name="Koty" color="7" fill="1" visible="no" active="no"/>
<layer number="48" name="Freza" color="7" fill="1" visible="no" active="no"/>
<layer number="49" name="Reference" color="7" fill="1" visible="no" active="no"/>
<layer number="50" name="dxf" color="7" fill="1" visible="no" active="no"/>
<layer number="51" name="tPotisk" color="14" fill="1" visible="no" active="no"/>
<layer number="52" name="bPotisk" color="6" fill="1" visible="no" active="no"/>
<layer number="53" name="tPadExt" color="7" fill="1" visible="no" active="no"/>
<layer number="54" name="bPadExt" color="1" fill="1" visible="no" active="no"/>
<layer number="56" name="wert" color="7" fill="1" visible="no" active="no"/>
<layer number="88" name="SimResults" color="9" fill="1" visible="no" active="no"/>
<layer number="89" name="SimProbes" color="9" fill="1" visible="no" active="no"/>
<layer number="90" name="Modules" color="5" fill="1" visible="yes" active="yes"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="no" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
<layer number="98" name="Guide" color="6" fill="1" visible="yes" active="yes"/>
<layer number="99" name="SpiceOrder" color="5" fill="1" visible="no" active="no"/>
<layer number="100" name="Trafo" color="7" fill="1" visible="yes" active="yes"/>
<layer number="101" name="tFrames" color="11" fill="1" visible="yes" active="yes"/>
<layer number="102" name="POTISK" color="14" fill="1" visible="yes" active="yes"/>
<layer number="103" name="LED" color="11" fill="1" visible="yes" active="yes"/>
<layer number="104" name="Name" color="7" fill="1" visible="yes" active="yes"/>
<layer number="105" name="bFrames" color="3" fill="1" visible="yes" active="yes"/>
<layer number="116" name="Patch_BOT" color="7" fill="4" visible="yes" active="yes"/>
<layer number="120" name="EREX_TCLS_obrys_kolize_obe_strany" color="7" fill="1" visible="yes" active="yes"/>
<layer number="121" name="RCL_obrys_kolize" color="7" fill="1" visible="yes" active="yes"/>
<layer number="122" name="REL-C_obrys_kolize_obe_strany" color="7" fill="1" visible="yes" active="yes"/>
<layer number="123" name="TCLC_obrys_kolize_obe_strany" color="7" fill="1" visible="yes" active="yes"/>
<layer number="124" name="TDZ-L_obrys_kolize" color="7" fill="1" visible="yes" active="yes"/>
<layer number="125" name="TDZ-R_obrys_kolize" color="7" fill="1" visible="yes" active="yes"/>
<layer number="151" name="HeatSink" color="7" fill="1" visible="yes" active="yes"/>
<layer number="160" name="FAB" color="7" fill="1" visible="yes" active="yes"/>
<layer number="200" name="200bmp" color="1" fill="10" visible="no" active="no"/>
<layer number="201" name="dxf2" color="7" fill="1" visible="yes" active="yes"/>
<layer number="202" name="dxf3" color="7" fill="1" visible="yes" active="yes"/>
<layer number="250" name="Descript" color="3" fill="1" visible="no" active="no"/>
<layer number="251" name="SMDround" color="12" fill="11" visible="no" active="no"/>
<layer number="254" name="OrgLBR" color="7" fill="1" visible="yes" active="yes"/>
</layers>
<schematic xreflabel="%F%N/S%S" xrefpart="/%S.%C%R">
<libraries>
<library name="CONNEC">
<packages>
<package name="20-Z2R24T">
<description>MOLEX 2mm dual row vertical receptacle
79107-7011</description>
<wire x1="-23.1" y1="1.1" x2="1.1" y2="1.1" width="0.254" layer="21"/>
<wire x1="1.1" y1="1.1" x2="1.1" y2="-3.1" width="0.254" layer="21"/>
<wire x1="1.1" y1="-3.1" x2="-23.1" y2="-3.1" width="0.254" layer="21"/>
<wire x1="-23.1" y1="-3.1" x2="-23.1" y2="1.1" width="0.254" layer="21"/>
<wire x1="-23.1" y1="1.1" x2="1.1" y2="1.1" width="0.2032" layer="51"/>
<wire x1="1.1" y1="1.1" x2="1.1" y2="-3.1" width="0.2032" layer="51"/>
<wire x1="1.1" y1="-3.1" x2="-23.1" y2="-3.1" width="0.2032" layer="51"/>
<wire x1="-23.1" y1="-3.1" x2="-23.1" y2="1.1" width="0.2032" layer="51"/>
<wire x1="1.651" y1="0" x2="2.159" y2="-0.508" width="0.2032" layer="51"/>
<wire x1="1.651" y1="0" x2="2.159" y2="0.508" width="0.2032" layer="51"/>
<wire x1="1.651" y1="0" x2="2.794" y2="0" width="0.2032" layer="51"/>
<wire x1="1.651" y1="0" x2="2.159" y2="-0.508" width="0.254" layer="21"/>
<wire x1="1.651" y1="0" x2="2.159" y2="0.508" width="0.254" layer="21"/>
<wire x1="1.651" y1="0" x2="2.794" y2="0" width="0.254" layer="21"/>
<pad name="1" x="0" y="0" drill="0.7" diameter="1.2"/>
<text x="-16.51" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-8.89" y="1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-13.97" y="1.905" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<pad name="2" x="0" y="-2" drill="0.7" diameter="1.2"/>
<pad name="3" x="-2" y="0" drill="0.7" diameter="1.2"/>
<pad name="4" x="-2" y="-2" drill="0.7" diameter="1.2"/>
<pad name="5" x="-4" y="0" drill="0.7" diameter="1.2"/>
<pad name="6" x="-4" y="-2" drill="0.7" diameter="1.2"/>
<pad name="7" x="-6" y="0" drill="0.7" diameter="1.2"/>
<pad name="8" x="-6" y="-2" drill="0.7" diameter="1.2"/>
<pad name="9" x="-8" y="0" drill="0.7" diameter="1.2"/>
<pad name="10" x="-8" y="-2" drill="0.7" diameter="1.2"/>
<pad name="11" x="-10" y="0" drill="0.7" diameter="1.2"/>
<pad name="12" x="-10" y="-2" drill="0.7" diameter="1.2"/>
<pad name="13" x="-12" y="0" drill="0.7" diameter="1.2"/>
<pad name="14" x="-12" y="-2" drill="0.7" diameter="1.2"/>
<pad name="15" x="-14" y="0" drill="0.7" diameter="1.2"/>
<pad name="16" x="-14" y="-2" drill="0.7" diameter="1.2"/>
<pad name="17" x="-16" y="0" drill="0.7" diameter="1.2"/>
<pad name="18" x="-16" y="-2" drill="0.7" diameter="1.2"/>
<pad name="19" x="-18" y="0" drill="0.7" diameter="1.2"/>
<pad name="20" x="-18" y="-2" drill="0.7" diameter="1.2"/>
<pad name="21" x="-20" y="0" drill="0.7" diameter="1.2"/>
<pad name="22" x="-20" y="-2" drill="0.7" diameter="1.2"/>
<pad name="23" x="-22" y="0" drill="0.7" diameter="1.2"/>
<pad name="24" x="-22" y="-2" drill="0.7" diameter="1.2"/>
</package>
<package name="20-Z2R26T">
<description>MOLEX 2mm dual row vertical receptacle
79107-7012</description>
<wire x1="-25.1" y1="1.1" x2="1.1" y2="1.1" width="0.254" layer="21"/>
<wire x1="1.1" y1="1.1" x2="1.1" y2="-3.1" width="0.254" layer="21"/>
<wire x1="1.1" y1="-3.1" x2="-25.1" y2="-3.1" width="0.254" layer="21"/>
<wire x1="-25.1" y1="-3.1" x2="-25.1" y2="1.1" width="0.254" layer="21"/>
<wire x1="-25.1" y1="1.1" x2="1.1" y2="1.1" width="0.2032" layer="51"/>
<wire x1="1.1" y1="1.1" x2="1.1" y2="-3.1" width="0.2032" layer="51"/>
<wire x1="1.1" y1="-3.1" x2="-25.1" y2="-3.1" width="0.2032" layer="51"/>
<wire x1="-25.1" y1="-3.1" x2="-25.1" y2="1.1" width="0.2032" layer="51"/>
<wire x1="1.651" y1="0" x2="2.159" y2="-0.508" width="0.2032" layer="51"/>
<wire x1="1.651" y1="0" x2="2.159" y2="0.508" width="0.2032" layer="51"/>
<wire x1="1.651" y1="0" x2="2.794" y2="0" width="0.2032" layer="51"/>
<wire x1="1.651" y1="0" x2="2.159" y2="-0.508" width="0.254" layer="21"/>
<wire x1="1.651" y1="0" x2="2.159" y2="0.508" width="0.254" layer="21"/>
<wire x1="1.651" y1="0" x2="2.794" y2="0" width="0.254" layer="21"/>
<pad name="1" x="0" y="0" drill="0.7" diameter="1.2"/>
<text x="-17.78" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-10.16" y="1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-15.24" y="1.905" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<pad name="2" x="0" y="-2" drill="0.7" diameter="1.2"/>
<pad name="3" x="-2" y="0" drill="0.7" diameter="1.2"/>
<pad name="4" x="-2" y="-2" drill="0.7" diameter="1.2"/>
<pad name="5" x="-4" y="0" drill="0.7" diameter="1.2"/>
<pad name="6" x="-4" y="-2" drill="0.7" diameter="1.2"/>
<pad name="7" x="-6" y="0" drill="0.7" diameter="1.2"/>
<pad name="8" x="-6" y="-2" drill="0.7" diameter="1.2"/>
<pad name="9" x="-8" y="0" drill="0.7" diameter="1.2"/>
<pad name="10" x="-8" y="-2" drill="0.7" diameter="1.2"/>
<pad name="11" x="-10" y="0" drill="0.7" diameter="1.2"/>
<pad name="12" x="-10" y="-2" drill="0.7" diameter="1.2"/>
<pad name="13" x="-12" y="0" drill="0.7" diameter="1.2"/>
<pad name="14" x="-12" y="-2" drill="0.7" diameter="1.2"/>
<pad name="15" x="-14" y="0" drill="0.7" diameter="1.2"/>
<pad name="16" x="-14" y="-2" drill="0.7" diameter="1.2"/>
<pad name="17" x="-16" y="0" drill="0.7" diameter="1.2"/>
<pad name="18" x="-16" y="-2" drill="0.7" diameter="1.2"/>
<pad name="19" x="-18" y="0" drill="0.7" diameter="1.2"/>
<pad name="20" x="-18" y="-2" drill="0.7" diameter="1.2"/>
<pad name="21" x="-20" y="0" drill="0.7" diameter="1.2"/>
<pad name="22" x="-20" y="-2" drill="0.7" diameter="1.2"/>
<pad name="23" x="-22" y="0" drill="0.7" diameter="1.2"/>
<pad name="24" x="-22" y="-2" drill="0.7" diameter="1.2"/>
<pad name="25" x="-24" y="0" drill="0.7" diameter="1.2"/>
<pad name="26" x="-24" y="-2" drill="0.7" diameter="1.2"/>
</package>
<package name="SIMM72A">
<wire x1="-96.935" y1="4.56" x2="-96.935" y2="5.46" width="0.254" layer="21"/>
<wire x1="-96.935" y1="5.46" x2="-95.25" y2="5.46" width="0.254" layer="21"/>
<wire x1="-95.25" y1="5.46" x2="0" y2="5.46" width="0.254" layer="21"/>
<wire x1="0" y1="5.46" x2="1.685" y2="5.46" width="0.254" layer="21"/>
<wire x1="1.685" y1="5.46" x2="1.685" y2="4.56" width="0.254" layer="21"/>
<wire x1="1.685" y1="4.56" x2="2.205" y2="4.56" width="0.254" layer="21"/>
<wire x1="2.205" y1="4.56" x2="4.505" y2="4.56" width="0.254" layer="21"/>
<wire x1="4.505" y1="4.56" x2="5.835" y2="4.56" width="0.254" layer="21"/>
<wire x1="5.835" y1="4.56" x2="10.035" y2="4.56" width="0.254" layer="21"/>
<wire x1="10.035" y1="4.56" x2="10.035" y2="-2.36" width="0.254" layer="21"/>
<wire x1="10.035" y1="-2.36" x2="10.035" y2="-3.61" width="0.254" layer="21"/>
<wire x1="10.035" y1="-3.61" x2="10.035" y2="-7.51" width="0.254" layer="21"/>
<wire x1="10.035" y1="-7.51" x2="10.035" y2="-8.26" width="0.254" layer="21"/>
<wire x1="10.035" y1="-8.26" x2="6.835" y2="-8.26" width="0.254" layer="21"/>
<wire x1="6.835" y1="-8.26" x2="3.865" y2="-8.26" width="0.254" layer="21"/>
<wire x1="3.865" y1="-8.26" x2="2.165" y2="-8.26" width="0.254" layer="21"/>
<wire x1="2.165" y1="-8.26" x2="2.165" y2="-7.51" width="0.254" layer="21"/>
<wire x1="2.165" y1="-7.51" x2="2.165" y2="-6.61" width="0.254" layer="21"/>
<wire x1="2.165" y1="-6.61" x2="2.165" y2="-1.91" width="0.254" layer="21"/>
<wire x1="2.165" y1="-1.91" x2="0" y2="-1.91" width="0.254" layer="21"/>
<wire x1="0" y1="-1.91" x2="-95.25" y2="-1.91" width="0.254" layer="21"/>
<wire x1="-95.25" y1="-1.91" x2="-97.415" y2="-1.91" width="0.254" layer="21"/>
<wire x1="-105.285" y1="4.56" x2="-96.935" y2="4.56" width="0.2032" layer="51"/>
<wire x1="-96.935" y1="4.56" x2="-96.935" y2="5.46" width="0.2032" layer="51"/>
<wire x1="-96.935" y1="5.46" x2="1.685" y2="5.46" width="0.2032" layer="51"/>
<wire x1="1.685" y1="5.46" x2="1.685" y2="4.56" width="0.2032" layer="51"/>
<wire x1="1.685" y1="4.56" x2="10.035" y2="4.56" width="0.2032" layer="51"/>
<wire x1="10.035" y1="4.56" x2="10.035" y2="-8.26" width="0.2032" layer="51"/>
<wire x1="10.035" y1="-8.26" x2="2.165" y2="-8.26" width="0.2032" layer="51"/>
<wire x1="2.165" y1="-8.26" x2="2.165" y2="-1.91" width="0.2032" layer="51"/>
<wire x1="2.165" y1="-1.91" x2="-97.415" y2="-1.91" width="0.2032" layer="51"/>
<wire x1="-97.415" y1="-1.91" x2="-97.415" y2="-8.26" width="0.2032" layer="51"/>
<wire x1="-97.415" y1="-8.26" x2="-105.285" y2="-8.26" width="0.2032" layer="51"/>
<wire x1="-105.285" y1="-8.26" x2="-105.285" y2="4.56" width="0.2032" layer="51"/>
<pad name="1" x="0" y="0" drill="0.8" diameter="1.4"/>
<text x="-55.88" y="6.985" size="1.27" layer="25">&gt;NAME</text>
<text x="-45.72" y="6.985" size="1.016" layer="27">&gt;VALUE</text>
<text x="-50.8" y="6.985" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<pad name="2" x="-1.27" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="3" x="-2.54" y="0" drill="0.8" diameter="1.4"/>
<pad name="4" x="-3.81" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="5" x="-5.08" y="0" drill="0.8" diameter="1.4"/>
<pad name="6" x="-6.35" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="7" x="-7.62" y="0" drill="0.8" diameter="1.4"/>
<pad name="8" x="-8.89" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="9" x="-10.16" y="0" drill="0.8" diameter="1.4"/>
<pad name="10" x="-11.43" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="11" x="-12.7" y="0" drill="0.8" diameter="1.4"/>
<pad name="12" x="-13.97" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="13" x="-15.24" y="0" drill="0.8" diameter="1.4"/>
<pad name="14" x="-16.51" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="15" x="-17.78" y="0" drill="0.8" diameter="1.4"/>
<pad name="16" x="-19.05" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="17" x="-20.32" y="0" drill="0.8" diameter="1.4"/>
<pad name="18" x="-21.59" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="19" x="-22.86" y="0" drill="0.8" diameter="1.4"/>
<pad name="20" x="-24.13" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="21" x="-25.4" y="0" drill="0.8" diameter="1.4"/>
<pad name="22" x="-26.67" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="23" x="-27.94" y="0" drill="0.8" diameter="1.4"/>
<pad name="24" x="-29.21" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="25" x="-30.48" y="0" drill="0.8" diameter="1.4"/>
<pad name="26" x="-31.75" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="27" x="-33.02" y="0" drill="0.8" diameter="1.4"/>
<pad name="28" x="-34.29" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="29" x="-35.56" y="0" drill="0.8" diameter="1.4"/>
<pad name="30" x="-36.83" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="31" x="-38.1" y="0" drill="0.8" diameter="1.4"/>
<pad name="32" x="-39.37" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="33" x="-40.64" y="0" drill="0.8" diameter="1.4"/>
<pad name="34" x="-41.91" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="35" x="-43.18" y="0" drill="0.8" diameter="1.4"/>
<pad name="36" x="-44.45" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="37" x="-50.8" y="0" drill="0.8" diameter="1.4"/>
<pad name="38" x="-52.07" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="39" x="-53.34" y="0" drill="0.8" diameter="1.4"/>
<pad name="40" x="-54.61" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="41" x="-55.88" y="0" drill="0.8" diameter="1.4"/>
<pad name="42" x="-57.15" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="43" x="-58.42" y="0" drill="0.8" diameter="1.4"/>
<pad name="44" x="-59.69" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="45" x="-60.96" y="0" drill="0.8" diameter="1.4"/>
<pad name="46" x="-62.23" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="47" x="-63.5" y="0" drill="0.8" diameter="1.4"/>
<pad name="48" x="-64.77" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="49" x="-66.04" y="0" drill="0.8" diameter="1.4"/>
<pad name="50" x="-67.31" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="51" x="-68.58" y="0" drill="0.8" diameter="1.4"/>
<pad name="52" x="-69.85" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="53" x="-71.12" y="0" drill="0.8" diameter="1.4"/>
<pad name="54" x="-72.39" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="55" x="-73.66" y="0" drill="0.8" diameter="1.4"/>
<pad name="56" x="-74.93" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="57" x="-76.2" y="0" drill="0.8" diameter="1.4"/>
<pad name="58" x="-77.47" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="59" x="-78.74" y="0" drill="0.8" diameter="1.4"/>
<pad name="60" x="-80.01" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="61" x="-81.28" y="0" drill="0.8" diameter="1.4"/>
<pad name="62" x="-82.55" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="63" x="-83.82" y="0" drill="0.8" diameter="1.4"/>
<pad name="64" x="-85.09" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="65" x="-86.36" y="0" drill="0.8" diameter="1.4"/>
<pad name="66" x="-87.63" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="67" x="-88.9" y="0" drill="0.8" diameter="1.4"/>
<pad name="68" x="-90.17" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="69" x="-91.44" y="0" drill="0.8" diameter="1.4"/>
<pad name="70" x="-92.71" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="71" x="-93.98" y="0" drill="0.8" diameter="1.4"/>
<pad name="72" x="-95.25" y="2.54" drill="0.8" diameter="1.4"/>
<hole x="-103.51" y="1.27" drill="2.45"/>
<hole x="-47.63" y="1.27" drill="1.65"/>
<hole x="8.26" y="1.27" drill="1.65"/>
<wire x1="0" y1="-2.921" x2="-0.508" y2="-3.429" width="0.2032" layer="51"/>
<wire x1="0" y1="-2.921" x2="0.508" y2="-3.429" width="0.2032" layer="51"/>
<wire x1="0" y1="-2.921" x2="0" y2="-4.064" width="0.2032" layer="51"/>
<wire x1="0" y1="-2.921" x2="-0.508" y2="-3.429" width="0.254" layer="21"/>
<wire x1="0" y1="-2.921" x2="0.508" y2="-3.429" width="0.254" layer="21"/>
<wire x1="0" y1="-2.921" x2="0" y2="-4.064" width="0.254" layer="21"/>
<wire x1="-95.25" y1="4.86" x2="0" y2="4.86" width="0.254" layer="21"/>
<wire x1="-95.25" y1="4.86" x2="-95.25" y2="5.46" width="0.254" layer="21"/>
<wire x1="0" y1="5.46" x2="0" y2="4.86" width="0.254" layer="21"/>
<wire x1="10.035" y1="-2.36" x2="6.835" y2="-2.36" width="0.254" layer="21"/>
<wire x1="10.035" y1="-3.61" x2="9.135" y2="-3.61" width="0.254" layer="21"/>
<wire x1="9.135" y1="-3.61" x2="6.835" y2="-3.61" width="0.254" layer="21"/>
<wire x1="6.835" y1="-3.61" x2="4.035" y2="-3.61" width="0.254" layer="21"/>
<wire x1="10.035" y1="-7.51" x2="9.135" y2="-7.51" width="0.254" layer="21"/>
<wire x1="9.135" y1="-7.51" x2="6.835" y2="-7.51" width="0.254" layer="21"/>
<wire x1="9.135" y1="-3.61" x2="9.135" y2="-7.51" width="0.254" layer="21"/>
<wire x1="4.035" y1="-3.61" x2="4.035" y2="-6.61" width="0.254" layer="21"/>
<wire x1="6.835" y1="-2.36" x2="6.835" y2="-3.61" width="0.254" layer="21"/>
<wire x1="4.035" y1="-6.61" x2="6.835" y2="-6.61" width="0.254" layer="21"/>
<wire x1="6.835" y1="-6.61" x2="6.835" y2="-8.26" width="0.254" layer="21"/>
<wire x1="3.865" y1="-6.61" x2="3.865" y2="-7.51" width="0.254" layer="21"/>
<wire x1="3.865" y1="-7.51" x2="3.865" y2="-8.26" width="0.254" layer="21"/>
<wire x1="2.165" y1="-6.61" x2="3.865" y2="-6.61" width="0.254" layer="21" curve="-90"/>
<wire x1="3.865" y1="-7.51" x2="2.165" y2="-7.51" width="0.254" layer="21"/>
<wire x1="4.035" y1="-6.61" x2="6.835" y2="-3.61" width="0.254" layer="21"/>
<wire x1="6.835" y1="-2.36" x2="6.835" y2="0.56" width="0.254" layer="21"/>
<wire x1="6.835" y1="0.56" x2="5.835" y2="0.56" width="0.254" layer="21"/>
<wire x1="5.835" y1="4.56" x2="5.835" y2="0.56" width="0.254" layer="21"/>
<wire x1="5.835" y1="0.56" x2="5.835" y2="-1.14" width="0.254" layer="21"/>
<wire x1="5.835" y1="-1.14" x2="4.505" y2="-1.14" width="0.254" layer="21"/>
<wire x1="4.505" y1="4.56" x2="4.505" y2="2.56" width="0.254" layer="21"/>
<wire x1="4.505" y1="2.56" x2="4.505" y2="0.56" width="0.254" layer="21"/>
<wire x1="4.505" y1="0.56" x2="4.505" y2="-1.14" width="0.254" layer="21"/>
<wire x1="4.505" y1="2.56" x2="2.205" y2="2.56" width="0.254" layer="21"/>
<wire x1="4.505" y1="0.56" x2="0.2" y2="0.56" width="0.254" layer="21"/>
<wire x1="0.2" y1="4.39" x2="-0.2" y2="4.39" width="0.254" layer="21"/>
<wire x1="-0.2" y1="4.39" x2="-0.2" y2="2.56" width="0.254" layer="21"/>
<wire x1="-0.2" y1="2.56" x2="-0.2" y2="0.56" width="0.254" layer="21"/>
<wire x1="-0.2" y1="0.56" x2="-0.2" y2="-0.41" width="0.254" layer="21"/>
<wire x1="0.2" y1="4.39" x2="0.2" y2="2.56" width="0.254" layer="21"/>
<wire x1="0.2" y1="2.56" x2="0.2" y2="0.56" width="0.254" layer="21"/>
<wire x1="0.2" y1="0.56" x2="0.2" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-0.2" y1="-0.41" x2="0.2" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-1.07" y1="2.56" x2="-0.2" y2="2.56" width="0.254" layer="21"/>
<wire x1="-1.07" y1="0.56" x2="-0.2" y2="0.56" width="0.254" layer="21"/>
<wire x1="2.205" y1="2.56" x2="2.205" y2="1.905" width="0.254" layer="21"/>
<wire x1="2.205" y1="1.905" x2="0.605" y2="1.905" width="0.254" layer="21"/>
<wire x1="0.605" y1="1.905" x2="0.605" y2="2.56" width="0.254" layer="21"/>
<wire x1="0.605" y1="2.56" x2="0.2" y2="2.56" width="0.254" layer="21"/>
<wire x1="2.205" y1="4.56" x2="2.205" y2="2.56" width="0.254" layer="21"/>
<wire x1="-50.6" y1="0.56" x2="-44.65" y2="0.56" width="0.254" layer="21"/>
<wire x1="-50.6" y1="2.56" x2="-49.13" y2="2.56" width="0.254" layer="21"/>
<wire x1="-46.13" y1="2.56" x2="-44.65" y2="2.56" width="0.254" layer="21"/>
<wire x1="-49.13" y1="2.54" x2="-46.13" y2="2.54" width="0.254" layer="21" curve="180"/>
<wire x1="-96.935" y1="4.56" x2="-97.455" y2="4.56" width="0.254" layer="21"/>
<wire x1="-97.455" y1="4.56" x2="-105.285" y2="4.56" width="0.254" layer="21"/>
<wire x1="-105.285" y1="4.56" x2="-105.285" y2="-2.36" width="0.254" layer="21"/>
<wire x1="-105.285" y1="-2.36" x2="-105.285" y2="-3.61" width="0.254" layer="21"/>
<wire x1="-105.285" y1="-3.61" x2="-105.285" y2="-7.51" width="0.254" layer="21"/>
<wire x1="-105.285" y1="-7.51" x2="-105.285" y2="-8.26" width="0.254" layer="21"/>
<wire x1="-105.285" y1="-8.26" x2="-102.085" y2="-8.26" width="0.254" layer="21"/>
<wire x1="-102.085" y1="-8.26" x2="-99.115" y2="-8.26" width="0.254" layer="21"/>
<wire x1="-99.115" y1="-8.26" x2="-97.415" y2="-8.26" width="0.254" layer="21"/>
<wire x1="-97.415" y1="-8.26" x2="-97.415" y2="-7.51" width="0.254" layer="21"/>
<wire x1="-97.415" y1="-7.51" x2="-97.415" y2="-6.61" width="0.254" layer="21"/>
<wire x1="-97.415" y1="-6.61" x2="-97.415" y2="-1.91" width="0.254" layer="21"/>
<wire x1="-105.285" y1="-2.36" x2="-102.085" y2="-2.36" width="0.254" layer="21"/>
<wire x1="-105.285" y1="-3.61" x2="-104.385" y2="-3.61" width="0.254" layer="21"/>
<wire x1="-104.385" y1="-3.61" x2="-102.085" y2="-3.61" width="0.254" layer="21"/>
<wire x1="-102.085" y1="-3.61" x2="-99.285" y2="-3.61" width="0.254" layer="21"/>
<wire x1="-105.285" y1="-7.51" x2="-104.385" y2="-7.51" width="0.254" layer="21"/>
<wire x1="-104.385" y1="-7.51" x2="-102.085" y2="-7.51" width="0.254" layer="21"/>
<wire x1="-104.385" y1="-3.61" x2="-104.385" y2="-7.51" width="0.254" layer="21"/>
<wire x1="-99.285" y1="-3.61" x2="-99.285" y2="-6.61" width="0.254" layer="21"/>
<wire x1="-102.085" y1="-2.36" x2="-102.085" y2="-3.61" width="0.254" layer="21"/>
<wire x1="-99.285" y1="-6.61" x2="-102.085" y2="-6.61" width="0.254" layer="21"/>
<wire x1="-102.085" y1="-6.61" x2="-102.085" y2="-8.26" width="0.254" layer="21"/>
<wire x1="-99.115" y1="-6.61" x2="-99.115" y2="-7.51" width="0.254" layer="21"/>
<wire x1="-99.115" y1="-7.51" x2="-99.115" y2="-8.26" width="0.254" layer="21"/>
<wire x1="-97.415" y1="-6.61" x2="-99.115" y2="-6.61" width="0.254" layer="21" curve="90"/>
<wire x1="-99.115" y1="-7.51" x2="-97.415" y2="-7.51" width="0.254" layer="21"/>
<wire x1="-99.285" y1="-6.61" x2="-102.085" y2="-3.61" width="0.254" layer="21"/>
<wire x1="-102.085" y1="-2.36" x2="-102.085" y2="0.56" width="0.254" layer="21"/>
<wire x1="-102.085" y1="0.56" x2="-102.085" y2="2.56" width="0.254" layer="21"/>
<wire x1="-102.085" y1="2.56" x2="-97.455" y2="2.56" width="0.254" layer="21"/>
<wire x1="-102.085" y1="0.56" x2="-95.45" y2="0.56" width="0.254" layer="21"/>
<wire x1="-97.455" y1="2.56" x2="-97.455" y2="1.905" width="0.254" layer="21"/>
<wire x1="-97.455" y1="1.905" x2="-95.855" y2="1.905" width="0.254" layer="21"/>
<wire x1="-95.855" y1="1.905" x2="-95.855" y2="2.56" width="0.254" layer="21"/>
<wire x1="-95.855" y1="2.56" x2="-95.45" y2="2.56" width="0.254" layer="21"/>
<wire x1="-97.455" y1="4.56" x2="-97.455" y2="2.56" width="0.254" layer="21"/>
<wire x1="-95.25" y1="-1.31" x2="0" y2="-1.31" width="0.254" layer="21"/>
<wire x1="0" y1="-1.31" x2="0" y2="-1.91" width="0.254" layer="21"/>
<wire x1="-95.25" y1="-1.31" x2="-95.25" y2="-1.91" width="0.254" layer="21"/>
<wire x1="-1.07" y1="4.39" x2="-1.47" y2="4.39" width="0.254" layer="21"/>
<wire x1="-1.47" y1="4.39" x2="-1.47" y2="2.56" width="0.254" layer="21"/>
<wire x1="-1.47" y1="2.56" x2="-1.47" y2="0.56" width="0.254" layer="21"/>
<wire x1="-1.47" y1="0.56" x2="-1.47" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-1.07" y1="4.39" x2="-1.07" y2="2.56" width="0.254" layer="21"/>
<wire x1="-1.07" y1="2.56" x2="-1.07" y2="0.56" width="0.254" layer="21"/>
<wire x1="-1.07" y1="0.56" x2="-1.07" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-1.47" y1="-0.41" x2="-1.07" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-2.34" y1="2.56" x2="-1.47" y2="2.56" width="0.254" layer="21"/>
<wire x1="-2.34" y1="0.56" x2="-1.47" y2="0.56" width="0.254" layer="21"/>
<wire x1="-2.34" y1="4.39" x2="-2.74" y2="4.39" width="0.254" layer="21"/>
<wire x1="-2.74" y1="4.39" x2="-2.74" y2="2.56" width="0.254" layer="21"/>
<wire x1="-2.74" y1="2.56" x2="-2.74" y2="0.56" width="0.254" layer="21"/>
<wire x1="-2.74" y1="0.56" x2="-2.74" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-2.34" y1="4.39" x2="-2.34" y2="2.56" width="0.254" layer="21"/>
<wire x1="-2.34" y1="2.56" x2="-2.34" y2="0.56" width="0.254" layer="21"/>
<wire x1="-2.34" y1="0.56" x2="-2.34" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-2.74" y1="-0.41" x2="-2.34" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-3.61" y1="2.56" x2="-2.74" y2="2.56" width="0.254" layer="21"/>
<wire x1="-3.61" y1="0.56" x2="-2.74" y2="0.56" width="0.254" layer="21"/>
<wire x1="-3.61" y1="4.39" x2="-4.01" y2="4.39" width="0.254" layer="21"/>
<wire x1="-4.01" y1="4.39" x2="-4.01" y2="2.56" width="0.254" layer="21"/>
<wire x1="-4.01" y1="2.56" x2="-4.01" y2="0.56" width="0.254" layer="21"/>
<wire x1="-4.01" y1="0.56" x2="-4.01" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-3.61" y1="4.39" x2="-3.61" y2="2.56" width="0.254" layer="21"/>
<wire x1="-3.61" y1="2.56" x2="-3.61" y2="0.56" width="0.254" layer="21"/>
<wire x1="-3.61" y1="0.56" x2="-3.61" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-4.01" y1="-0.41" x2="-3.61" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-4.88" y1="2.56" x2="-4.01" y2="2.56" width="0.254" layer="21"/>
<wire x1="-4.88" y1="0.56" x2="-4.01" y2="0.56" width="0.254" layer="21"/>
<wire x1="-4.88" y1="4.39" x2="-5.28" y2="4.39" width="0.254" layer="21"/>
<wire x1="-5.28" y1="4.39" x2="-5.28" y2="2.56" width="0.254" layer="21"/>
<wire x1="-5.28" y1="2.56" x2="-5.28" y2="0.56" width="0.254" layer="21"/>
<wire x1="-5.28" y1="0.56" x2="-5.28" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-4.88" y1="4.39" x2="-4.88" y2="2.56" width="0.254" layer="21"/>
<wire x1="-4.88" y1="2.56" x2="-4.88" y2="0.56" width="0.254" layer="21"/>
<wire x1="-4.88" y1="0.56" x2="-4.88" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-5.28" y1="-0.41" x2="-4.88" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-6.15" y1="2.56" x2="-5.28" y2="2.56" width="0.254" layer="21"/>
<wire x1="-6.15" y1="0.56" x2="-5.28" y2="0.56" width="0.254" layer="21"/>
<wire x1="-6.15" y1="4.39" x2="-6.55" y2="4.39" width="0.254" layer="21"/>
<wire x1="-6.55" y1="4.39" x2="-6.55" y2="2.56" width="0.254" layer="21"/>
<wire x1="-6.55" y1="2.56" x2="-6.55" y2="0.56" width="0.254" layer="21"/>
<wire x1="-6.55" y1="0.56" x2="-6.55" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-6.15" y1="4.39" x2="-6.15" y2="2.56" width="0.254" layer="21"/>
<wire x1="-6.15" y1="2.56" x2="-6.15" y2="0.56" width="0.254" layer="21"/>
<wire x1="-6.15" y1="0.56" x2="-6.15" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-6.55" y1="-0.41" x2="-6.15" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-7.42" y1="2.56" x2="-6.55" y2="2.56" width="0.254" layer="21"/>
<wire x1="-7.42" y1="0.56" x2="-6.55" y2="0.56" width="0.254" layer="21"/>
<wire x1="-7.42" y1="4.39" x2="-7.82" y2="4.39" width="0.254" layer="21"/>
<wire x1="-7.82" y1="4.39" x2="-7.82" y2="2.56" width="0.254" layer="21"/>
<wire x1="-7.82" y1="2.56" x2="-7.82" y2="0.56" width="0.254" layer="21"/>
<wire x1="-7.82" y1="0.56" x2="-7.82" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-7.42" y1="4.39" x2="-7.42" y2="2.56" width="0.254" layer="21"/>
<wire x1="-7.42" y1="2.56" x2="-7.42" y2="0.56" width="0.254" layer="21"/>
<wire x1="-7.42" y1="0.56" x2="-7.42" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-7.82" y1="-0.41" x2="-7.42" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-8.69" y1="2.56" x2="-7.82" y2="2.56" width="0.254" layer="21"/>
<wire x1="-8.69" y1="0.56" x2="-7.82" y2="0.56" width="0.254" layer="21"/>
<wire x1="-8.69" y1="4.39" x2="-9.09" y2="4.39" width="0.254" layer="21"/>
<wire x1="-9.09" y1="4.39" x2="-9.09" y2="2.56" width="0.254" layer="21"/>
<wire x1="-9.09" y1="2.56" x2="-9.09" y2="0.56" width="0.254" layer="21"/>
<wire x1="-9.09" y1="0.56" x2="-9.09" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-8.69" y1="4.39" x2="-8.69" y2="2.56" width="0.254" layer="21"/>
<wire x1="-8.69" y1="2.56" x2="-8.69" y2="0.56" width="0.254" layer="21"/>
<wire x1="-8.69" y1="0.56" x2="-8.69" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-9.09" y1="-0.41" x2="-8.69" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-9.96" y1="2.56" x2="-9.09" y2="2.56" width="0.254" layer="21"/>
<wire x1="-9.96" y1="0.56" x2="-9.09" y2="0.56" width="0.254" layer="21"/>
<wire x1="-9.96" y1="4.39" x2="-10.36" y2="4.39" width="0.254" layer="21"/>
<wire x1="-10.36" y1="4.39" x2="-10.36" y2="2.56" width="0.254" layer="21"/>
<wire x1="-10.36" y1="2.56" x2="-10.36" y2="0.56" width="0.254" layer="21"/>
<wire x1="-10.36" y1="0.56" x2="-10.36" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-9.96" y1="4.39" x2="-9.96" y2="2.56" width="0.254" layer="21"/>
<wire x1="-9.96" y1="2.56" x2="-9.96" y2="0.56" width="0.254" layer="21"/>
<wire x1="-9.96" y1="0.56" x2="-9.96" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-10.36" y1="-0.41" x2="-9.96" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-11.23" y1="2.56" x2="-10.36" y2="2.56" width="0.254" layer="21"/>
<wire x1="-11.23" y1="0.56" x2="-10.36" y2="0.56" width="0.254" layer="21"/>
<wire x1="-11.23" y1="4.39" x2="-11.63" y2="4.39" width="0.254" layer="21"/>
<wire x1="-11.63" y1="4.39" x2="-11.63" y2="2.56" width="0.254" layer="21"/>
<wire x1="-11.63" y1="2.56" x2="-11.63" y2="0.56" width="0.254" layer="21"/>
<wire x1="-11.63" y1="0.56" x2="-11.63" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-11.23" y1="4.39" x2="-11.23" y2="2.56" width="0.254" layer="21"/>
<wire x1="-11.23" y1="2.56" x2="-11.23" y2="0.56" width="0.254" layer="21"/>
<wire x1="-11.23" y1="0.56" x2="-11.23" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-11.63" y1="-0.41" x2="-11.23" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-12.5" y1="2.56" x2="-11.63" y2="2.56" width="0.254" layer="21"/>
<wire x1="-12.5" y1="0.56" x2="-11.63" y2="0.56" width="0.254" layer="21"/>
<wire x1="-12.5" y1="4.39" x2="-12.9" y2="4.39" width="0.254" layer="21"/>
<wire x1="-12.9" y1="4.39" x2="-12.9" y2="2.56" width="0.254" layer="21"/>
<wire x1="-12.9" y1="2.56" x2="-12.9" y2="0.56" width="0.254" layer="21"/>
<wire x1="-12.9" y1="0.56" x2="-12.9" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-12.5" y1="4.39" x2="-12.5" y2="2.56" width="0.254" layer="21"/>
<wire x1="-12.5" y1="2.56" x2="-12.5" y2="0.56" width="0.254" layer="21"/>
<wire x1="-12.5" y1="0.56" x2="-12.5" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-12.9" y1="-0.41" x2="-12.5" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-13.77" y1="2.56" x2="-12.9" y2="2.56" width="0.254" layer="21"/>
<wire x1="-13.77" y1="0.56" x2="-12.9" y2="0.56" width="0.254" layer="21"/>
<wire x1="-13.77" y1="4.39" x2="-14.17" y2="4.39" width="0.254" layer="21"/>
<wire x1="-14.17" y1="4.39" x2="-14.17" y2="2.56" width="0.254" layer="21"/>
<wire x1="-14.17" y1="2.56" x2="-14.17" y2="0.56" width="0.254" layer="21"/>
<wire x1="-14.17" y1="0.56" x2="-14.17" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-13.77" y1="4.39" x2="-13.77" y2="2.56" width="0.254" layer="21"/>
<wire x1="-13.77" y1="2.56" x2="-13.77" y2="0.56" width="0.254" layer="21"/>
<wire x1="-13.77" y1="0.56" x2="-13.77" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-14.17" y1="-0.41" x2="-13.77" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-15.04" y1="2.56" x2="-14.17" y2="2.56" width="0.254" layer="21"/>
<wire x1="-15.04" y1="0.56" x2="-14.17" y2="0.56" width="0.254" layer="21"/>
<wire x1="-15.04" y1="4.39" x2="-15.44" y2="4.39" width="0.254" layer="21"/>
<wire x1="-15.44" y1="4.39" x2="-15.44" y2="2.56" width="0.254" layer="21"/>
<wire x1="-15.44" y1="2.56" x2="-15.44" y2="0.56" width="0.254" layer="21"/>
<wire x1="-15.44" y1="0.56" x2="-15.44" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-15.04" y1="4.39" x2="-15.04" y2="2.56" width="0.254" layer="21"/>
<wire x1="-15.04" y1="2.56" x2="-15.04" y2="0.56" width="0.254" layer="21"/>
<wire x1="-15.04" y1="0.56" x2="-15.04" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-15.44" y1="-0.41" x2="-15.04" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-16.31" y1="2.56" x2="-15.44" y2="2.56" width="0.254" layer="21"/>
<wire x1="-16.31" y1="0.56" x2="-15.44" y2="0.56" width="0.254" layer="21"/>
<wire x1="-16.31" y1="4.39" x2="-16.71" y2="4.39" width="0.254" layer="21"/>
<wire x1="-16.71" y1="4.39" x2="-16.71" y2="2.56" width="0.254" layer="21"/>
<wire x1="-16.71" y1="2.56" x2="-16.71" y2="0.56" width="0.254" layer="21"/>
<wire x1="-16.71" y1="0.56" x2="-16.71" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-16.31" y1="4.39" x2="-16.31" y2="2.56" width="0.254" layer="21"/>
<wire x1="-16.31" y1="2.56" x2="-16.31" y2="0.56" width="0.254" layer="21"/>
<wire x1="-16.31" y1="0.56" x2="-16.31" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-16.71" y1="-0.41" x2="-16.31" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-17.58" y1="2.56" x2="-16.71" y2="2.56" width="0.254" layer="21"/>
<wire x1="-17.58" y1="0.56" x2="-16.71" y2="0.56" width="0.254" layer="21"/>
<wire x1="-17.58" y1="4.39" x2="-17.98" y2="4.39" width="0.254" layer="21"/>
<wire x1="-17.98" y1="4.39" x2="-17.98" y2="2.56" width="0.254" layer="21"/>
<wire x1="-17.98" y1="2.56" x2="-17.98" y2="0.56" width="0.254" layer="21"/>
<wire x1="-17.98" y1="0.56" x2="-17.98" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-17.58" y1="4.39" x2="-17.58" y2="2.56" width="0.254" layer="21"/>
<wire x1="-17.58" y1="2.56" x2="-17.58" y2="0.56" width="0.254" layer="21"/>
<wire x1="-17.58" y1="0.56" x2="-17.58" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-17.98" y1="-0.41" x2="-17.58" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-18.85" y1="2.56" x2="-17.98" y2="2.56" width="0.254" layer="21"/>
<wire x1="-18.85" y1="0.56" x2="-17.98" y2="0.56" width="0.254" layer="21"/>
<wire x1="-18.85" y1="4.39" x2="-19.25" y2="4.39" width="0.254" layer="21"/>
<wire x1="-19.25" y1="4.39" x2="-19.25" y2="2.56" width="0.254" layer="21"/>
<wire x1="-19.25" y1="2.56" x2="-19.25" y2="0.56" width="0.254" layer="21"/>
<wire x1="-19.25" y1="0.56" x2="-19.25" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-18.85" y1="4.39" x2="-18.85" y2="2.56" width="0.254" layer="21"/>
<wire x1="-18.85" y1="2.56" x2="-18.85" y2="0.56" width="0.254" layer="21"/>
<wire x1="-18.85" y1="0.56" x2="-18.85" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-19.25" y1="-0.41" x2="-18.85" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-20.12" y1="2.56" x2="-19.25" y2="2.56" width="0.254" layer="21"/>
<wire x1="-20.12" y1="0.56" x2="-19.25" y2="0.56" width="0.254" layer="21"/>
<wire x1="-20.12" y1="4.39" x2="-20.52" y2="4.39" width="0.254" layer="21"/>
<wire x1="-20.52" y1="4.39" x2="-20.52" y2="2.56" width="0.254" layer="21"/>
<wire x1="-20.52" y1="2.56" x2="-20.52" y2="0.56" width="0.254" layer="21"/>
<wire x1="-20.52" y1="0.56" x2="-20.52" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-20.12" y1="4.39" x2="-20.12" y2="2.56" width="0.254" layer="21"/>
<wire x1="-20.12" y1="2.56" x2="-20.12" y2="0.56" width="0.254" layer="21"/>
<wire x1="-20.12" y1="0.56" x2="-20.12" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-20.52" y1="-0.41" x2="-20.12" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-21.39" y1="2.56" x2="-20.52" y2="2.56" width="0.254" layer="21"/>
<wire x1="-21.39" y1="0.56" x2="-20.52" y2="0.56" width="0.254" layer="21"/>
<wire x1="-21.39" y1="4.39" x2="-21.79" y2="4.39" width="0.254" layer="21"/>
<wire x1="-21.79" y1="4.39" x2="-21.79" y2="2.56" width="0.254" layer="21"/>
<wire x1="-21.79" y1="2.56" x2="-21.79" y2="0.56" width="0.254" layer="21"/>
<wire x1="-21.79" y1="0.56" x2="-21.79" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-21.39" y1="4.39" x2="-21.39" y2="2.56" width="0.254" layer="21"/>
<wire x1="-21.39" y1="2.56" x2="-21.39" y2="0.56" width="0.254" layer="21"/>
<wire x1="-21.39" y1="0.56" x2="-21.39" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-21.79" y1="-0.41" x2="-21.39" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-22.66" y1="2.56" x2="-21.79" y2="2.56" width="0.254" layer="21"/>
<wire x1="-22.66" y1="0.56" x2="-21.79" y2="0.56" width="0.254" layer="21"/>
<wire x1="-22.66" y1="4.39" x2="-23.06" y2="4.39" width="0.254" layer="21"/>
<wire x1="-23.06" y1="4.39" x2="-23.06" y2="2.56" width="0.254" layer="21"/>
<wire x1="-23.06" y1="2.56" x2="-23.06" y2="0.56" width="0.254" layer="21"/>
<wire x1="-23.06" y1="0.56" x2="-23.06" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-22.66" y1="4.39" x2="-22.66" y2="2.56" width="0.254" layer="21"/>
<wire x1="-22.66" y1="2.56" x2="-22.66" y2="0.56" width="0.254" layer="21"/>
<wire x1="-22.66" y1="0.56" x2="-22.66" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-23.06" y1="-0.41" x2="-22.66" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-23.93" y1="2.56" x2="-23.06" y2="2.56" width="0.254" layer="21"/>
<wire x1="-23.93" y1="0.56" x2="-23.06" y2="0.56" width="0.254" layer="21"/>
<wire x1="-23.93" y1="4.39" x2="-24.33" y2="4.39" width="0.254" layer="21"/>
<wire x1="-24.33" y1="4.39" x2="-24.33" y2="2.56" width="0.254" layer="21"/>
<wire x1="-24.33" y1="2.56" x2="-24.33" y2="0.56" width="0.254" layer="21"/>
<wire x1="-24.33" y1="0.56" x2="-24.33" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-23.93" y1="4.39" x2="-23.93" y2="2.56" width="0.254" layer="21"/>
<wire x1="-23.93" y1="2.56" x2="-23.93" y2="0.56" width="0.254" layer="21"/>
<wire x1="-23.93" y1="0.56" x2="-23.93" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-24.33" y1="-0.41" x2="-23.93" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-25.2" y1="2.56" x2="-24.33" y2="2.56" width="0.254" layer="21"/>
<wire x1="-25.2" y1="0.56" x2="-24.33" y2="0.56" width="0.254" layer="21"/>
<wire x1="-25.2" y1="4.39" x2="-25.6" y2="4.39" width="0.254" layer="21"/>
<wire x1="-25.6" y1="4.39" x2="-25.6" y2="2.56" width="0.254" layer="21"/>
<wire x1="-25.6" y1="2.56" x2="-25.6" y2="0.56" width="0.254" layer="21"/>
<wire x1="-25.6" y1="0.56" x2="-25.6" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-25.2" y1="4.39" x2="-25.2" y2="2.56" width="0.254" layer="21"/>
<wire x1="-25.2" y1="2.56" x2="-25.2" y2="0.56" width="0.254" layer="21"/>
<wire x1="-25.2" y1="0.56" x2="-25.2" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-25.6" y1="-0.41" x2="-25.2" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-26.47" y1="2.56" x2="-25.6" y2="2.56" width="0.254" layer="21"/>
<wire x1="-26.47" y1="0.56" x2="-25.6" y2="0.56" width="0.254" layer="21"/>
<wire x1="-26.47" y1="4.39" x2="-26.87" y2="4.39" width="0.254" layer="21"/>
<wire x1="-26.87" y1="4.39" x2="-26.87" y2="2.56" width="0.254" layer="21"/>
<wire x1="-26.87" y1="2.56" x2="-26.87" y2="0.56" width="0.254" layer="21"/>
<wire x1="-26.87" y1="0.56" x2="-26.87" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-26.47" y1="4.39" x2="-26.47" y2="2.56" width="0.254" layer="21"/>
<wire x1="-26.47" y1="2.56" x2="-26.47" y2="0.56" width="0.254" layer="21"/>
<wire x1="-26.47" y1="0.56" x2="-26.47" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-26.87" y1="-0.41" x2="-26.47" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-27.74" y1="2.56" x2="-26.87" y2="2.56" width="0.254" layer="21"/>
<wire x1="-27.74" y1="0.56" x2="-26.87" y2="0.56" width="0.254" layer="21"/>
<wire x1="-27.74" y1="4.39" x2="-28.14" y2="4.39" width="0.254" layer="21"/>
<wire x1="-28.14" y1="4.39" x2="-28.14" y2="2.56" width="0.254" layer="21"/>
<wire x1="-28.14" y1="2.56" x2="-28.14" y2="0.56" width="0.254" layer="21"/>
<wire x1="-28.14" y1="0.56" x2="-28.14" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-27.74" y1="4.39" x2="-27.74" y2="2.56" width="0.254" layer="21"/>
<wire x1="-27.74" y1="2.56" x2="-27.74" y2="0.56" width="0.254" layer="21"/>
<wire x1="-27.74" y1="0.56" x2="-27.74" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-28.14" y1="-0.41" x2="-27.74" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-29.01" y1="2.56" x2="-28.14" y2="2.56" width="0.254" layer="21"/>
<wire x1="-29.01" y1="0.56" x2="-28.14" y2="0.56" width="0.254" layer="21"/>
<wire x1="-29.01" y1="4.39" x2="-29.41" y2="4.39" width="0.254" layer="21"/>
<wire x1="-29.41" y1="4.39" x2="-29.41" y2="2.56" width="0.254" layer="21"/>
<wire x1="-29.41" y1="2.56" x2="-29.41" y2="0.56" width="0.254" layer="21"/>
<wire x1="-29.41" y1="0.56" x2="-29.41" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-29.01" y1="4.39" x2="-29.01" y2="2.56" width="0.254" layer="21"/>
<wire x1="-29.01" y1="2.56" x2="-29.01" y2="0.56" width="0.254" layer="21"/>
<wire x1="-29.01" y1="0.56" x2="-29.01" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-29.41" y1="-0.41" x2="-29.01" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-30.28" y1="2.56" x2="-29.41" y2="2.56" width="0.254" layer="21"/>
<wire x1="-30.28" y1="0.56" x2="-29.41" y2="0.56" width="0.254" layer="21"/>
<wire x1="-30.28" y1="4.39" x2="-30.68" y2="4.39" width="0.254" layer="21"/>
<wire x1="-30.68" y1="4.39" x2="-30.68" y2="2.56" width="0.254" layer="21"/>
<wire x1="-30.68" y1="2.56" x2="-30.68" y2="0.56" width="0.254" layer="21"/>
<wire x1="-30.68" y1="0.56" x2="-30.68" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-30.28" y1="4.39" x2="-30.28" y2="2.56" width="0.254" layer="21"/>
<wire x1="-30.28" y1="2.56" x2="-30.28" y2="0.56" width="0.254" layer="21"/>
<wire x1="-30.28" y1="0.56" x2="-30.28" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-30.68" y1="-0.41" x2="-30.28" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-31.55" y1="2.56" x2="-30.68" y2="2.56" width="0.254" layer="21"/>
<wire x1="-31.55" y1="0.56" x2="-30.68" y2="0.56" width="0.254" layer="21"/>
<wire x1="-31.55" y1="4.39" x2="-31.95" y2="4.39" width="0.254" layer="21"/>
<wire x1="-31.95" y1="4.39" x2="-31.95" y2="2.56" width="0.254" layer="21"/>
<wire x1="-31.95" y1="2.56" x2="-31.95" y2="0.56" width="0.254" layer="21"/>
<wire x1="-31.95" y1="0.56" x2="-31.95" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-31.55" y1="4.39" x2="-31.55" y2="2.56" width="0.254" layer="21"/>
<wire x1="-31.55" y1="2.56" x2="-31.55" y2="0.56" width="0.254" layer="21"/>
<wire x1="-31.55" y1="0.56" x2="-31.55" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-31.95" y1="-0.41" x2="-31.55" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-32.82" y1="2.56" x2="-31.95" y2="2.56" width="0.254" layer="21"/>
<wire x1="-32.82" y1="0.56" x2="-31.95" y2="0.56" width="0.254" layer="21"/>
<wire x1="-32.82" y1="4.39" x2="-33.22" y2="4.39" width="0.254" layer="21"/>
<wire x1="-33.22" y1="4.39" x2="-33.22" y2="2.56" width="0.254" layer="21"/>
<wire x1="-33.22" y1="2.56" x2="-33.22" y2="0.56" width="0.254" layer="21"/>
<wire x1="-33.22" y1="0.56" x2="-33.22" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-32.82" y1="4.39" x2="-32.82" y2="2.56" width="0.254" layer="21"/>
<wire x1="-32.82" y1="2.56" x2="-32.82" y2="0.56" width="0.254" layer="21"/>
<wire x1="-32.82" y1="0.56" x2="-32.82" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-33.22" y1="-0.41" x2="-32.82" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-34.09" y1="2.56" x2="-33.22" y2="2.56" width="0.254" layer="21"/>
<wire x1="-34.09" y1="0.56" x2="-33.22" y2="0.56" width="0.254" layer="21"/>
<wire x1="-34.09" y1="4.39" x2="-34.49" y2="4.39" width="0.254" layer="21"/>
<wire x1="-34.49" y1="4.39" x2="-34.49" y2="2.56" width="0.254" layer="21"/>
<wire x1="-34.49" y1="2.56" x2="-34.49" y2="0.56" width="0.254" layer="21"/>
<wire x1="-34.49" y1="0.56" x2="-34.49" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-34.09" y1="4.39" x2="-34.09" y2="2.56" width="0.254" layer="21"/>
<wire x1="-34.09" y1="2.56" x2="-34.09" y2="0.56" width="0.254" layer="21"/>
<wire x1="-34.09" y1="0.56" x2="-34.09" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-34.49" y1="-0.41" x2="-34.09" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-35.36" y1="2.56" x2="-34.49" y2="2.56" width="0.254" layer="21"/>
<wire x1="-35.36" y1="0.56" x2="-34.49" y2="0.56" width="0.254" layer="21"/>
<wire x1="-35.36" y1="4.39" x2="-35.76" y2="4.39" width="0.254" layer="21"/>
<wire x1="-35.76" y1="4.39" x2="-35.76" y2="2.56" width="0.254" layer="21"/>
<wire x1="-35.76" y1="2.56" x2="-35.76" y2="0.56" width="0.254" layer="21"/>
<wire x1="-35.76" y1="0.56" x2="-35.76" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-35.36" y1="4.39" x2="-35.36" y2="2.56" width="0.254" layer="21"/>
<wire x1="-35.36" y1="2.56" x2="-35.36" y2="0.56" width="0.254" layer="21"/>
<wire x1="-35.36" y1="0.56" x2="-35.36" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-35.76" y1="-0.41" x2="-35.36" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-36.63" y1="2.56" x2="-35.76" y2="2.56" width="0.254" layer="21"/>
<wire x1="-36.63" y1="0.56" x2="-35.76" y2="0.56" width="0.254" layer="21"/>
<wire x1="-36.63" y1="4.39" x2="-37.03" y2="4.39" width="0.254" layer="21"/>
<wire x1="-37.03" y1="4.39" x2="-37.03" y2="2.56" width="0.254" layer="21"/>
<wire x1="-37.03" y1="2.56" x2="-37.03" y2="0.56" width="0.254" layer="21"/>
<wire x1="-37.03" y1="0.56" x2="-37.03" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-36.63" y1="4.39" x2="-36.63" y2="2.56" width="0.254" layer="21"/>
<wire x1="-36.63" y1="2.56" x2="-36.63" y2="0.56" width="0.254" layer="21"/>
<wire x1="-36.63" y1="0.56" x2="-36.63" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-37.03" y1="-0.41" x2="-36.63" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-37.9" y1="2.56" x2="-37.03" y2="2.56" width="0.254" layer="21"/>
<wire x1="-37.9" y1="0.56" x2="-37.03" y2="0.56" width="0.254" layer="21"/>
<wire x1="-37.9" y1="4.39" x2="-38.3" y2="4.39" width="0.254" layer="21"/>
<wire x1="-38.3" y1="4.39" x2="-38.3" y2="2.56" width="0.254" layer="21"/>
<wire x1="-38.3" y1="2.56" x2="-38.3" y2="0.56" width="0.254" layer="21"/>
<wire x1="-38.3" y1="0.56" x2="-38.3" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-37.9" y1="4.39" x2="-37.9" y2="2.56" width="0.254" layer="21"/>
<wire x1="-37.9" y1="2.56" x2="-37.9" y2="0.56" width="0.254" layer="21"/>
<wire x1="-37.9" y1="0.56" x2="-37.9" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-38.3" y1="-0.41" x2="-37.9" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-39.17" y1="2.56" x2="-38.3" y2="2.56" width="0.254" layer="21"/>
<wire x1="-39.17" y1="0.56" x2="-38.3" y2="0.56" width="0.254" layer="21"/>
<wire x1="-39.17" y1="4.39" x2="-39.57" y2="4.39" width="0.254" layer="21"/>
<wire x1="-39.57" y1="4.39" x2="-39.57" y2="2.56" width="0.254" layer="21"/>
<wire x1="-39.57" y1="2.56" x2="-39.57" y2="0.56" width="0.254" layer="21"/>
<wire x1="-39.57" y1="0.56" x2="-39.57" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-39.17" y1="4.39" x2="-39.17" y2="2.56" width="0.254" layer="21"/>
<wire x1="-39.17" y1="2.56" x2="-39.17" y2="0.56" width="0.254" layer="21"/>
<wire x1="-39.17" y1="0.56" x2="-39.17" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-39.57" y1="-0.41" x2="-39.17" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-40.44" y1="2.56" x2="-39.57" y2="2.56" width="0.254" layer="21"/>
<wire x1="-40.44" y1="0.56" x2="-39.57" y2="0.56" width="0.254" layer="21"/>
<wire x1="-40.44" y1="4.39" x2="-40.84" y2="4.39" width="0.254" layer="21"/>
<wire x1="-40.84" y1="4.39" x2="-40.84" y2="2.56" width="0.254" layer="21"/>
<wire x1="-40.84" y1="2.56" x2="-40.84" y2="0.56" width="0.254" layer="21"/>
<wire x1="-40.84" y1="0.56" x2="-40.84" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-40.44" y1="4.39" x2="-40.44" y2="2.56" width="0.254" layer="21"/>
<wire x1="-40.44" y1="2.56" x2="-40.44" y2="0.56" width="0.254" layer="21"/>
<wire x1="-40.44" y1="0.56" x2="-40.44" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-40.84" y1="-0.41" x2="-40.44" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-41.71" y1="2.56" x2="-40.84" y2="2.56" width="0.254" layer="21"/>
<wire x1="-41.71" y1="0.56" x2="-40.84" y2="0.56" width="0.254" layer="21"/>
<wire x1="-41.71" y1="4.39" x2="-42.11" y2="4.39" width="0.254" layer="21"/>
<wire x1="-42.11" y1="4.39" x2="-42.11" y2="2.56" width="0.254" layer="21"/>
<wire x1="-42.11" y1="2.56" x2="-42.11" y2="0.56" width="0.254" layer="21"/>
<wire x1="-42.11" y1="0.56" x2="-42.11" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-41.71" y1="4.39" x2="-41.71" y2="2.56" width="0.254" layer="21"/>
<wire x1="-41.71" y1="2.56" x2="-41.71" y2="0.56" width="0.254" layer="21"/>
<wire x1="-41.71" y1="0.56" x2="-41.71" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-42.11" y1="-0.41" x2="-41.71" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-42.98" y1="2.56" x2="-42.11" y2="2.56" width="0.254" layer="21"/>
<wire x1="-42.98" y1="0.56" x2="-42.11" y2="0.56" width="0.254" layer="21"/>
<wire x1="-42.98" y1="4.39" x2="-43.38" y2="4.39" width="0.254" layer="21"/>
<wire x1="-43.38" y1="4.39" x2="-43.38" y2="2.56" width="0.254" layer="21"/>
<wire x1="-43.38" y1="2.56" x2="-43.38" y2="0.56" width="0.254" layer="21"/>
<wire x1="-43.38" y1="0.56" x2="-43.38" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-42.98" y1="4.39" x2="-42.98" y2="2.56" width="0.254" layer="21"/>
<wire x1="-42.98" y1="2.56" x2="-42.98" y2="0.56" width="0.254" layer="21"/>
<wire x1="-42.98" y1="0.56" x2="-42.98" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-43.38" y1="-0.41" x2="-42.98" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-44.25" y1="2.56" x2="-43.38" y2="2.56" width="0.254" layer="21"/>
<wire x1="-44.25" y1="0.56" x2="-43.38" y2="0.56" width="0.254" layer="21"/>
<wire x1="-44.25" y1="4.39" x2="-44.65" y2="4.39" width="0.254" layer="21"/>
<wire x1="-44.65" y1="4.39" x2="-44.65" y2="2.56" width="0.254" layer="21"/>
<wire x1="-44.65" y1="2.56" x2="-44.65" y2="0.56" width="0.254" layer="21"/>
<wire x1="-44.65" y1="0.56" x2="-44.65" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-44.25" y1="4.39" x2="-44.25" y2="2.56" width="0.254" layer="21"/>
<wire x1="-44.25" y1="2.56" x2="-44.25" y2="0.56" width="0.254" layer="21"/>
<wire x1="-44.25" y1="0.56" x2="-44.25" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-44.65" y1="-0.41" x2="-44.25" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-50.6" y1="4.39" x2="-51" y2="4.39" width="0.254" layer="21"/>
<wire x1="-51" y1="4.39" x2="-51" y2="2.56" width="0.254" layer="21"/>
<wire x1="-51" y1="2.56" x2="-51" y2="0.56" width="0.254" layer="21"/>
<wire x1="-51" y1="0.56" x2="-51" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-50.6" y1="4.39" x2="-50.6" y2="2.56" width="0.254" layer="21"/>
<wire x1="-50.6" y1="2.56" x2="-50.6" y2="0.56" width="0.254" layer="21"/>
<wire x1="-50.6" y1="0.56" x2="-50.6" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-51" y1="-0.41" x2="-50.6" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-51.87" y1="2.56" x2="-51" y2="2.56" width="0.254" layer="21"/>
<wire x1="-51.87" y1="0.56" x2="-51" y2="0.56" width="0.254" layer="21"/>
<wire x1="-51.87" y1="4.39" x2="-52.27" y2="4.39" width="0.254" layer="21"/>
<wire x1="-52.27" y1="4.39" x2="-52.27" y2="2.56" width="0.254" layer="21"/>
<wire x1="-52.27" y1="2.56" x2="-52.27" y2="0.56" width="0.254" layer="21"/>
<wire x1="-52.27" y1="0.56" x2="-52.27" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-51.87" y1="4.39" x2="-51.87" y2="2.56" width="0.254" layer="21"/>
<wire x1="-51.87" y1="2.56" x2="-51.87" y2="0.56" width="0.254" layer="21"/>
<wire x1="-51.87" y1="0.56" x2="-51.87" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-52.27" y1="-0.41" x2="-51.87" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-53.14" y1="2.56" x2="-52.27" y2="2.56" width="0.254" layer="21"/>
<wire x1="-53.14" y1="0.56" x2="-52.27" y2="0.56" width="0.254" layer="21"/>
<wire x1="-53.14" y1="4.39" x2="-53.54" y2="4.39" width="0.254" layer="21"/>
<wire x1="-53.54" y1="4.39" x2="-53.54" y2="2.56" width="0.254" layer="21"/>
<wire x1="-53.54" y1="2.56" x2="-53.54" y2="0.56" width="0.254" layer="21"/>
<wire x1="-53.54" y1="0.56" x2="-53.54" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-53.14" y1="4.39" x2="-53.14" y2="2.56" width="0.254" layer="21"/>
<wire x1="-53.14" y1="2.56" x2="-53.14" y2="0.56" width="0.254" layer="21"/>
<wire x1="-53.14" y1="0.56" x2="-53.14" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-53.54" y1="-0.41" x2="-53.14" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-54.41" y1="2.56" x2="-53.54" y2="2.56" width="0.254" layer="21"/>
<wire x1="-54.41" y1="0.56" x2="-53.54" y2="0.56" width="0.254" layer="21"/>
<wire x1="-54.41" y1="4.39" x2="-54.81" y2="4.39" width="0.254" layer="21"/>
<wire x1="-54.81" y1="4.39" x2="-54.81" y2="2.56" width="0.254" layer="21"/>
<wire x1="-54.81" y1="2.56" x2="-54.81" y2="0.56" width="0.254" layer="21"/>
<wire x1="-54.81" y1="0.56" x2="-54.81" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-54.41" y1="4.39" x2="-54.41" y2="2.56" width="0.254" layer="21"/>
<wire x1="-54.41" y1="2.56" x2="-54.41" y2="0.56" width="0.254" layer="21"/>
<wire x1="-54.41" y1="0.56" x2="-54.41" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-54.81" y1="-0.41" x2="-54.41" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-55.68" y1="2.56" x2="-54.81" y2="2.56" width="0.254" layer="21"/>
<wire x1="-55.68" y1="0.56" x2="-54.81" y2="0.56" width="0.254" layer="21"/>
<wire x1="-55.68" y1="4.39" x2="-56.08" y2="4.39" width="0.254" layer="21"/>
<wire x1="-56.08" y1="4.39" x2="-56.08" y2="2.56" width="0.254" layer="21"/>
<wire x1="-56.08" y1="2.56" x2="-56.08" y2="0.56" width="0.254" layer="21"/>
<wire x1="-56.08" y1="0.56" x2="-56.08" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-55.68" y1="4.39" x2="-55.68" y2="2.56" width="0.254" layer="21"/>
<wire x1="-55.68" y1="2.56" x2="-55.68" y2="0.56" width="0.254" layer="21"/>
<wire x1="-55.68" y1="0.56" x2="-55.68" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-56.08" y1="-0.41" x2="-55.68" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-56.95" y1="2.56" x2="-56.08" y2="2.56" width="0.254" layer="21"/>
<wire x1="-56.95" y1="0.56" x2="-56.08" y2="0.56" width="0.254" layer="21"/>
<wire x1="-56.95" y1="4.39" x2="-57.35" y2="4.39" width="0.254" layer="21"/>
<wire x1="-57.35" y1="4.39" x2="-57.35" y2="2.56" width="0.254" layer="21"/>
<wire x1="-57.35" y1="2.56" x2="-57.35" y2="0.56" width="0.254" layer="21"/>
<wire x1="-57.35" y1="0.56" x2="-57.35" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-56.95" y1="4.39" x2="-56.95" y2="2.56" width="0.254" layer="21"/>
<wire x1="-56.95" y1="2.56" x2="-56.95" y2="0.56" width="0.254" layer="21"/>
<wire x1="-56.95" y1="0.56" x2="-56.95" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-57.35" y1="-0.41" x2="-56.95" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-58.22" y1="2.56" x2="-57.35" y2="2.56" width="0.254" layer="21"/>
<wire x1="-58.22" y1="0.56" x2="-57.35" y2="0.56" width="0.254" layer="21"/>
<wire x1="-58.22" y1="4.39" x2="-58.62" y2="4.39" width="0.254" layer="21"/>
<wire x1="-58.62" y1="4.39" x2="-58.62" y2="2.56" width="0.254" layer="21"/>
<wire x1="-58.62" y1="2.56" x2="-58.62" y2="0.56" width="0.254" layer="21"/>
<wire x1="-58.62" y1="0.56" x2="-58.62" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-58.22" y1="4.39" x2="-58.22" y2="2.56" width="0.254" layer="21"/>
<wire x1="-58.22" y1="2.56" x2="-58.22" y2="0.56" width="0.254" layer="21"/>
<wire x1="-58.22" y1="0.56" x2="-58.22" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-58.62" y1="-0.41" x2="-58.22" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-59.49" y1="2.56" x2="-58.62" y2="2.56" width="0.254" layer="21"/>
<wire x1="-59.49" y1="0.56" x2="-58.62" y2="0.56" width="0.254" layer="21"/>
<wire x1="-59.49" y1="4.39" x2="-59.89" y2="4.39" width="0.254" layer="21"/>
<wire x1="-59.89" y1="4.39" x2="-59.89" y2="2.56" width="0.254" layer="21"/>
<wire x1="-59.89" y1="2.56" x2="-59.89" y2="0.56" width="0.254" layer="21"/>
<wire x1="-59.89" y1="0.56" x2="-59.89" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-59.49" y1="4.39" x2="-59.49" y2="2.56" width="0.254" layer="21"/>
<wire x1="-59.49" y1="2.56" x2="-59.49" y2="0.56" width="0.254" layer="21"/>
<wire x1="-59.49" y1="0.56" x2="-59.49" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-59.89" y1="-0.41" x2="-59.49" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-60.76" y1="2.56" x2="-59.89" y2="2.56" width="0.254" layer="21"/>
<wire x1="-60.76" y1="0.56" x2="-59.89" y2="0.56" width="0.254" layer="21"/>
<wire x1="-60.76" y1="4.39" x2="-61.16" y2="4.39" width="0.254" layer="21"/>
<wire x1="-61.16" y1="4.39" x2="-61.16" y2="2.56" width="0.254" layer="21"/>
<wire x1="-61.16" y1="2.56" x2="-61.16" y2="0.56" width="0.254" layer="21"/>
<wire x1="-61.16" y1="0.56" x2="-61.16" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-60.76" y1="4.39" x2="-60.76" y2="2.56" width="0.254" layer="21"/>
<wire x1="-60.76" y1="2.56" x2="-60.76" y2="0.56" width="0.254" layer="21"/>
<wire x1="-60.76" y1="0.56" x2="-60.76" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-61.16" y1="-0.41" x2="-60.76" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-62.03" y1="2.56" x2="-61.16" y2="2.56" width="0.254" layer="21"/>
<wire x1="-62.03" y1="0.56" x2="-61.16" y2="0.56" width="0.254" layer="21"/>
<wire x1="-62.03" y1="4.39" x2="-62.43" y2="4.39" width="0.254" layer="21"/>
<wire x1="-62.43" y1="4.39" x2="-62.43" y2="2.56" width="0.254" layer="21"/>
<wire x1="-62.43" y1="2.56" x2="-62.43" y2="0.56" width="0.254" layer="21"/>
<wire x1="-62.43" y1="0.56" x2="-62.43" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-62.03" y1="4.39" x2="-62.03" y2="2.56" width="0.254" layer="21"/>
<wire x1="-62.03" y1="2.56" x2="-62.03" y2="0.56" width="0.254" layer="21"/>
<wire x1="-62.03" y1="0.56" x2="-62.03" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-62.43" y1="-0.41" x2="-62.03" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-63.3" y1="2.56" x2="-62.43" y2="2.56" width="0.254" layer="21"/>
<wire x1="-63.3" y1="0.56" x2="-62.43" y2="0.56" width="0.254" layer="21"/>
<wire x1="-63.3" y1="4.39" x2="-63.7" y2="4.39" width="0.254" layer="21"/>
<wire x1="-63.7" y1="4.39" x2="-63.7" y2="2.56" width="0.254" layer="21"/>
<wire x1="-63.7" y1="2.56" x2="-63.7" y2="0.56" width="0.254" layer="21"/>
<wire x1="-63.7" y1="0.56" x2="-63.7" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-63.3" y1="4.39" x2="-63.3" y2="2.56" width="0.254" layer="21"/>
<wire x1="-63.3" y1="2.56" x2="-63.3" y2="0.56" width="0.254" layer="21"/>
<wire x1="-63.3" y1="0.56" x2="-63.3" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-63.7" y1="-0.41" x2="-63.3" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-64.57" y1="2.56" x2="-63.7" y2="2.56" width="0.254" layer="21"/>
<wire x1="-64.57" y1="0.56" x2="-63.7" y2="0.56" width="0.254" layer="21"/>
<wire x1="-64.57" y1="4.39" x2="-64.97" y2="4.39" width="0.254" layer="21"/>
<wire x1="-64.97" y1="4.39" x2="-64.97" y2="2.56" width="0.254" layer="21"/>
<wire x1="-64.97" y1="2.56" x2="-64.97" y2="0.56" width="0.254" layer="21"/>
<wire x1="-64.97" y1="0.56" x2="-64.97" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-64.57" y1="4.39" x2="-64.57" y2="2.56" width="0.254" layer="21"/>
<wire x1="-64.57" y1="2.56" x2="-64.57" y2="0.56" width="0.254" layer="21"/>
<wire x1="-64.57" y1="0.56" x2="-64.57" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-64.97" y1="-0.41" x2="-64.57" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-65.84" y1="2.56" x2="-64.97" y2="2.56" width="0.254" layer="21"/>
<wire x1="-65.84" y1="0.56" x2="-64.97" y2="0.56" width="0.254" layer="21"/>
<wire x1="-65.84" y1="4.39" x2="-66.24" y2="4.39" width="0.254" layer="21"/>
<wire x1="-66.24" y1="4.39" x2="-66.24" y2="2.56" width="0.254" layer="21"/>
<wire x1="-66.24" y1="2.56" x2="-66.24" y2="0.56" width="0.254" layer="21"/>
<wire x1="-66.24" y1="0.56" x2="-66.24" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-65.84" y1="4.39" x2="-65.84" y2="2.56" width="0.254" layer="21"/>
<wire x1="-65.84" y1="2.56" x2="-65.84" y2="0.56" width="0.254" layer="21"/>
<wire x1="-65.84" y1="0.56" x2="-65.84" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-66.24" y1="-0.41" x2="-65.84" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-67.11" y1="2.56" x2="-66.24" y2="2.56" width="0.254" layer="21"/>
<wire x1="-67.11" y1="0.56" x2="-66.24" y2="0.56" width="0.254" layer="21"/>
<wire x1="-67.11" y1="4.39" x2="-67.51" y2="4.39" width="0.254" layer="21"/>
<wire x1="-67.51" y1="4.39" x2="-67.51" y2="2.56" width="0.254" layer="21"/>
<wire x1="-67.51" y1="2.56" x2="-67.51" y2="0.56" width="0.254" layer="21"/>
<wire x1="-67.51" y1="0.56" x2="-67.51" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-67.11" y1="4.39" x2="-67.11" y2="2.56" width="0.254" layer="21"/>
<wire x1="-67.11" y1="2.56" x2="-67.11" y2="0.56" width="0.254" layer="21"/>
<wire x1="-67.11" y1="0.56" x2="-67.11" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-67.51" y1="-0.41" x2="-67.11" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-68.38" y1="2.56" x2="-67.51" y2="2.56" width="0.254" layer="21"/>
<wire x1="-68.38" y1="0.56" x2="-67.51" y2="0.56" width="0.254" layer="21"/>
<wire x1="-68.38" y1="4.39" x2="-68.78" y2="4.39" width="0.254" layer="21"/>
<wire x1="-68.78" y1="4.39" x2="-68.78" y2="2.56" width="0.254" layer="21"/>
<wire x1="-68.78" y1="2.56" x2="-68.78" y2="0.56" width="0.254" layer="21"/>
<wire x1="-68.78" y1="0.56" x2="-68.78" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-68.38" y1="4.39" x2="-68.38" y2="2.56" width="0.254" layer="21"/>
<wire x1="-68.38" y1="2.56" x2="-68.38" y2="0.56" width="0.254" layer="21"/>
<wire x1="-68.38" y1="0.56" x2="-68.38" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-68.78" y1="-0.41" x2="-68.38" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-69.65" y1="2.56" x2="-68.78" y2="2.56" width="0.254" layer="21"/>
<wire x1="-69.65" y1="0.56" x2="-68.78" y2="0.56" width="0.254" layer="21"/>
<wire x1="-69.65" y1="4.39" x2="-70.05" y2="4.39" width="0.254" layer="21"/>
<wire x1="-70.05" y1="4.39" x2="-70.05" y2="2.56" width="0.254" layer="21"/>
<wire x1="-70.05" y1="2.56" x2="-70.05" y2="0.56" width="0.254" layer="21"/>
<wire x1="-70.05" y1="0.56" x2="-70.05" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-69.65" y1="4.39" x2="-69.65" y2="2.56" width="0.254" layer="21"/>
<wire x1="-69.65" y1="2.56" x2="-69.65" y2="0.56" width="0.254" layer="21"/>
<wire x1="-69.65" y1="0.56" x2="-69.65" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-70.05" y1="-0.41" x2="-69.65" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-70.92" y1="2.56" x2="-70.05" y2="2.56" width="0.254" layer="21"/>
<wire x1="-70.92" y1="0.56" x2="-70.05" y2="0.56" width="0.254" layer="21"/>
<wire x1="-70.92" y1="4.39" x2="-71.32" y2="4.39" width="0.254" layer="21"/>
<wire x1="-71.32" y1="4.39" x2="-71.32" y2="2.56" width="0.254" layer="21"/>
<wire x1="-71.32" y1="2.56" x2="-71.32" y2="0.56" width="0.254" layer="21"/>
<wire x1="-71.32" y1="0.56" x2="-71.32" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-70.92" y1="4.39" x2="-70.92" y2="2.56" width="0.254" layer="21"/>
<wire x1="-70.92" y1="2.56" x2="-70.92" y2="0.56" width="0.254" layer="21"/>
<wire x1="-70.92" y1="0.56" x2="-70.92" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-71.32" y1="-0.41" x2="-70.92" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-72.19" y1="2.56" x2="-71.32" y2="2.56" width="0.254" layer="21"/>
<wire x1="-72.19" y1="0.56" x2="-71.32" y2="0.56" width="0.254" layer="21"/>
<wire x1="-72.19" y1="4.39" x2="-72.59" y2="4.39" width="0.254" layer="21"/>
<wire x1="-72.59" y1="4.39" x2="-72.59" y2="2.56" width="0.254" layer="21"/>
<wire x1="-72.59" y1="2.56" x2="-72.59" y2="0.56" width="0.254" layer="21"/>
<wire x1="-72.59" y1="0.56" x2="-72.59" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-72.19" y1="4.39" x2="-72.19" y2="2.56" width="0.254" layer="21"/>
<wire x1="-72.19" y1="2.56" x2="-72.19" y2="0.56" width="0.254" layer="21"/>
<wire x1="-72.19" y1="0.56" x2="-72.19" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-72.59" y1="-0.41" x2="-72.19" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-73.46" y1="2.56" x2="-72.59" y2="2.56" width="0.254" layer="21"/>
<wire x1="-73.46" y1="0.56" x2="-72.59" y2="0.56" width="0.254" layer="21"/>
<wire x1="-73.46" y1="4.39" x2="-73.86" y2="4.39" width="0.254" layer="21"/>
<wire x1="-73.86" y1="4.39" x2="-73.86" y2="2.56" width="0.254" layer="21"/>
<wire x1="-73.86" y1="2.56" x2="-73.86" y2="0.56" width="0.254" layer="21"/>
<wire x1="-73.86" y1="0.56" x2="-73.86" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-73.46" y1="4.39" x2="-73.46" y2="2.56" width="0.254" layer="21"/>
<wire x1="-73.46" y1="2.56" x2="-73.46" y2="0.56" width="0.254" layer="21"/>
<wire x1="-73.46" y1="0.56" x2="-73.46" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-73.86" y1="-0.41" x2="-73.46" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-74.73" y1="2.56" x2="-73.86" y2="2.56" width="0.254" layer="21"/>
<wire x1="-74.73" y1="0.56" x2="-73.86" y2="0.56" width="0.254" layer="21"/>
<wire x1="-74.73" y1="4.39" x2="-75.13" y2="4.39" width="0.254" layer="21"/>
<wire x1="-75.13" y1="4.39" x2="-75.13" y2="2.56" width="0.254" layer="21"/>
<wire x1="-75.13" y1="2.56" x2="-75.13" y2="0.56" width="0.254" layer="21"/>
<wire x1="-75.13" y1="0.56" x2="-75.13" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-74.73" y1="4.39" x2="-74.73" y2="2.56" width="0.254" layer="21"/>
<wire x1="-74.73" y1="2.56" x2="-74.73" y2="0.56" width="0.254" layer="21"/>
<wire x1="-74.73" y1="0.56" x2="-74.73" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-75.13" y1="-0.41" x2="-74.73" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-76" y1="2.56" x2="-75.13" y2="2.56" width="0.254" layer="21"/>
<wire x1="-76" y1="0.56" x2="-75.13" y2="0.56" width="0.254" layer="21"/>
<wire x1="-76" y1="4.39" x2="-76.4" y2="4.39" width="0.254" layer="21"/>
<wire x1="-76.4" y1="4.39" x2="-76.4" y2="2.56" width="0.254" layer="21"/>
<wire x1="-76.4" y1="2.56" x2="-76.4" y2="0.56" width="0.254" layer="21"/>
<wire x1="-76.4" y1="0.56" x2="-76.4" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-76" y1="4.39" x2="-76" y2="2.56" width="0.254" layer="21"/>
<wire x1="-76" y1="2.56" x2="-76" y2="0.56" width="0.254" layer="21"/>
<wire x1="-76" y1="0.56" x2="-76" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-76.4" y1="-0.41" x2="-76" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-77.27" y1="2.56" x2="-76.4" y2="2.56" width="0.254" layer="21"/>
<wire x1="-77.27" y1="0.56" x2="-76.4" y2="0.56" width="0.254" layer="21"/>
<wire x1="-77.27" y1="4.39" x2="-77.67" y2="4.39" width="0.254" layer="21"/>
<wire x1="-77.67" y1="4.39" x2="-77.67" y2="2.56" width="0.254" layer="21"/>
<wire x1="-77.67" y1="2.56" x2="-77.67" y2="0.56" width="0.254" layer="21"/>
<wire x1="-77.67" y1="0.56" x2="-77.67" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-77.27" y1="4.39" x2="-77.27" y2="2.56" width="0.254" layer="21"/>
<wire x1="-77.27" y1="2.56" x2="-77.27" y2="0.56" width="0.254" layer="21"/>
<wire x1="-77.27" y1="0.56" x2="-77.27" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-77.67" y1="-0.41" x2="-77.27" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-78.54" y1="2.56" x2="-77.67" y2="2.56" width="0.254" layer="21"/>
<wire x1="-78.54" y1="0.56" x2="-77.67" y2="0.56" width="0.254" layer="21"/>
<wire x1="-78.54" y1="4.39" x2="-78.94" y2="4.39" width="0.254" layer="21"/>
<wire x1="-78.94" y1="4.39" x2="-78.94" y2="2.56" width="0.254" layer="21"/>
<wire x1="-78.94" y1="2.56" x2="-78.94" y2="0.56" width="0.254" layer="21"/>
<wire x1="-78.94" y1="0.56" x2="-78.94" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-78.54" y1="4.39" x2="-78.54" y2="2.56" width="0.254" layer="21"/>
<wire x1="-78.54" y1="2.56" x2="-78.54" y2="0.56" width="0.254" layer="21"/>
<wire x1="-78.54" y1="0.56" x2="-78.54" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-78.94" y1="-0.41" x2="-78.54" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-79.81" y1="2.56" x2="-78.94" y2="2.56" width="0.254" layer="21"/>
<wire x1="-79.81" y1="0.56" x2="-78.94" y2="0.56" width="0.254" layer="21"/>
<wire x1="-79.81" y1="4.39" x2="-80.21" y2="4.39" width="0.254" layer="21"/>
<wire x1="-80.21" y1="4.39" x2="-80.21" y2="2.56" width="0.254" layer="21"/>
<wire x1="-80.21" y1="2.56" x2="-80.21" y2="0.56" width="0.254" layer="21"/>
<wire x1="-80.21" y1="0.56" x2="-80.21" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-79.81" y1="4.39" x2="-79.81" y2="2.56" width="0.254" layer="21"/>
<wire x1="-79.81" y1="2.56" x2="-79.81" y2="0.56" width="0.254" layer="21"/>
<wire x1="-79.81" y1="0.56" x2="-79.81" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-80.21" y1="-0.41" x2="-79.81" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-81.08" y1="2.56" x2="-80.21" y2="2.56" width="0.254" layer="21"/>
<wire x1="-81.08" y1="0.56" x2="-80.21" y2="0.56" width="0.254" layer="21"/>
<wire x1="-81.08" y1="4.39" x2="-81.48" y2="4.39" width="0.254" layer="21"/>
<wire x1="-81.48" y1="4.39" x2="-81.48" y2="2.56" width="0.254" layer="21"/>
<wire x1="-81.48" y1="2.56" x2="-81.48" y2="0.56" width="0.254" layer="21"/>
<wire x1="-81.48" y1="0.56" x2="-81.48" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-81.08" y1="4.39" x2="-81.08" y2="2.56" width="0.254" layer="21"/>
<wire x1="-81.08" y1="2.56" x2="-81.08" y2="0.56" width="0.254" layer="21"/>
<wire x1="-81.08" y1="0.56" x2="-81.08" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-81.48" y1="-0.41" x2="-81.08" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-82.35" y1="2.56" x2="-81.48" y2="2.56" width="0.254" layer="21"/>
<wire x1="-82.35" y1="0.56" x2="-81.48" y2="0.56" width="0.254" layer="21"/>
<wire x1="-82.35" y1="4.39" x2="-82.75" y2="4.39" width="0.254" layer="21"/>
<wire x1="-82.75" y1="4.39" x2="-82.75" y2="2.56" width="0.254" layer="21"/>
<wire x1="-82.75" y1="2.56" x2="-82.75" y2="0.56" width="0.254" layer="21"/>
<wire x1="-82.75" y1="0.56" x2="-82.75" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-82.35" y1="4.39" x2="-82.35" y2="2.56" width="0.254" layer="21"/>
<wire x1="-82.35" y1="2.56" x2="-82.35" y2="0.56" width="0.254" layer="21"/>
<wire x1="-82.35" y1="0.56" x2="-82.35" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-82.75" y1="-0.41" x2="-82.35" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-83.62" y1="2.56" x2="-82.75" y2="2.56" width="0.254" layer="21"/>
<wire x1="-83.62" y1="0.56" x2="-82.75" y2="0.56" width="0.254" layer="21"/>
<wire x1="-83.62" y1="4.39" x2="-84.02" y2="4.39" width="0.254" layer="21"/>
<wire x1="-84.02" y1="4.39" x2="-84.02" y2="2.56" width="0.254" layer="21"/>
<wire x1="-84.02" y1="2.56" x2="-84.02" y2="0.56" width="0.254" layer="21"/>
<wire x1="-84.02" y1="0.56" x2="-84.02" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-83.62" y1="4.39" x2="-83.62" y2="2.56" width="0.254" layer="21"/>
<wire x1="-83.62" y1="2.56" x2="-83.62" y2="0.56" width="0.254" layer="21"/>
<wire x1="-83.62" y1="0.56" x2="-83.62" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-84.02" y1="-0.41" x2="-83.62" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-84.89" y1="2.56" x2="-84.02" y2="2.56" width="0.254" layer="21"/>
<wire x1="-84.89" y1="0.56" x2="-84.02" y2="0.56" width="0.254" layer="21"/>
<wire x1="-84.89" y1="4.39" x2="-85.29" y2="4.39" width="0.254" layer="21"/>
<wire x1="-85.29" y1="4.39" x2="-85.29" y2="2.56" width="0.254" layer="21"/>
<wire x1="-85.29" y1="2.56" x2="-85.29" y2="0.56" width="0.254" layer="21"/>
<wire x1="-85.29" y1="0.56" x2="-85.29" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-84.89" y1="4.39" x2="-84.89" y2="2.56" width="0.254" layer="21"/>
<wire x1="-84.89" y1="2.56" x2="-84.89" y2="0.56" width="0.254" layer="21"/>
<wire x1="-84.89" y1="0.56" x2="-84.89" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-85.29" y1="-0.41" x2="-84.89" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-86.16" y1="2.56" x2="-85.29" y2="2.56" width="0.254" layer="21"/>
<wire x1="-86.16" y1="0.56" x2="-85.29" y2="0.56" width="0.254" layer="21"/>
<wire x1="-86.16" y1="4.39" x2="-86.56" y2="4.39" width="0.254" layer="21"/>
<wire x1="-86.56" y1="4.39" x2="-86.56" y2="2.56" width="0.254" layer="21"/>
<wire x1="-86.56" y1="2.56" x2="-86.56" y2="0.56" width="0.254" layer="21"/>
<wire x1="-86.56" y1="0.56" x2="-86.56" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-86.16" y1="4.39" x2="-86.16" y2="2.56" width="0.254" layer="21"/>
<wire x1="-86.16" y1="2.56" x2="-86.16" y2="0.56" width="0.254" layer="21"/>
<wire x1="-86.16" y1="0.56" x2="-86.16" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-86.56" y1="-0.41" x2="-86.16" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-87.43" y1="2.56" x2="-86.56" y2="2.56" width="0.254" layer="21"/>
<wire x1="-87.43" y1="0.56" x2="-86.56" y2="0.56" width="0.254" layer="21"/>
<wire x1="-87.43" y1="4.39" x2="-87.83" y2="4.39" width="0.254" layer="21"/>
<wire x1="-87.83" y1="4.39" x2="-87.83" y2="2.56" width="0.254" layer="21"/>
<wire x1="-87.83" y1="2.56" x2="-87.83" y2="0.56" width="0.254" layer="21"/>
<wire x1="-87.83" y1="0.56" x2="-87.83" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-87.43" y1="4.39" x2="-87.43" y2="2.56" width="0.254" layer="21"/>
<wire x1="-87.43" y1="2.56" x2="-87.43" y2="0.56" width="0.254" layer="21"/>
<wire x1="-87.43" y1="0.56" x2="-87.43" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-87.83" y1="-0.41" x2="-87.43" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-88.7" y1="2.56" x2="-87.83" y2="2.56" width="0.254" layer="21"/>
<wire x1="-88.7" y1="0.56" x2="-87.83" y2="0.56" width="0.254" layer="21"/>
<wire x1="-88.7" y1="4.39" x2="-89.1" y2="4.39" width="0.254" layer="21"/>
<wire x1="-89.1" y1="4.39" x2="-89.1" y2="2.56" width="0.254" layer="21"/>
<wire x1="-89.1" y1="2.56" x2="-89.1" y2="0.56" width="0.254" layer="21"/>
<wire x1="-89.1" y1="0.56" x2="-89.1" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-88.7" y1="4.39" x2="-88.7" y2="2.56" width="0.254" layer="21"/>
<wire x1="-88.7" y1="2.56" x2="-88.7" y2="0.56" width="0.254" layer="21"/>
<wire x1="-88.7" y1="0.56" x2="-88.7" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-89.1" y1="-0.41" x2="-88.7" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-89.97" y1="2.56" x2="-89.1" y2="2.56" width="0.254" layer="21"/>
<wire x1="-89.97" y1="0.56" x2="-89.1" y2="0.56" width="0.254" layer="21"/>
<wire x1="-89.97" y1="4.39" x2="-90.37" y2="4.39" width="0.254" layer="21"/>
<wire x1="-90.37" y1="4.39" x2="-90.37" y2="2.56" width="0.254" layer="21"/>
<wire x1="-90.37" y1="2.56" x2="-90.37" y2="0.56" width="0.254" layer="21"/>
<wire x1="-90.37" y1="0.56" x2="-90.37" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-89.97" y1="4.39" x2="-89.97" y2="2.56" width="0.254" layer="21"/>
<wire x1="-89.97" y1="2.56" x2="-89.97" y2="0.56" width="0.254" layer="21"/>
<wire x1="-89.97" y1="0.56" x2="-89.97" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-90.37" y1="-0.41" x2="-89.97" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-91.24" y1="2.56" x2="-90.37" y2="2.56" width="0.254" layer="21"/>
<wire x1="-91.24" y1="0.56" x2="-90.37" y2="0.56" width="0.254" layer="21"/>
<wire x1="-91.24" y1="4.39" x2="-91.64" y2="4.39" width="0.254" layer="21"/>
<wire x1="-91.64" y1="4.39" x2="-91.64" y2="2.56" width="0.254" layer="21"/>
<wire x1="-91.64" y1="2.56" x2="-91.64" y2="0.56" width="0.254" layer="21"/>
<wire x1="-91.64" y1="0.56" x2="-91.64" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-91.24" y1="4.39" x2="-91.24" y2="2.56" width="0.254" layer="21"/>
<wire x1="-91.24" y1="2.56" x2="-91.24" y2="0.56" width="0.254" layer="21"/>
<wire x1="-91.24" y1="0.56" x2="-91.24" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-91.64" y1="-0.41" x2="-91.24" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-92.51" y1="2.56" x2="-91.64" y2="2.56" width="0.254" layer="21"/>
<wire x1="-92.51" y1="0.56" x2="-91.64" y2="0.56" width="0.254" layer="21"/>
<wire x1="-92.51" y1="4.39" x2="-92.91" y2="4.39" width="0.254" layer="21"/>
<wire x1="-92.91" y1="4.39" x2="-92.91" y2="2.56" width="0.254" layer="21"/>
<wire x1="-92.91" y1="2.56" x2="-92.91" y2="0.56" width="0.254" layer="21"/>
<wire x1="-92.91" y1="0.56" x2="-92.91" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-92.51" y1="4.39" x2="-92.51" y2="2.56" width="0.254" layer="21"/>
<wire x1="-92.51" y1="2.56" x2="-92.51" y2="0.56" width="0.254" layer="21"/>
<wire x1="-92.51" y1="0.56" x2="-92.51" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-92.91" y1="-0.41" x2="-92.51" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-93.78" y1="2.56" x2="-92.91" y2="2.56" width="0.254" layer="21"/>
<wire x1="-93.78" y1="0.56" x2="-92.91" y2="0.56" width="0.254" layer="21"/>
<wire x1="-93.78" y1="4.39" x2="-94.18" y2="4.39" width="0.254" layer="21"/>
<wire x1="-94.18" y1="4.39" x2="-94.18" y2="2.56" width="0.254" layer="21"/>
<wire x1="-94.18" y1="2.56" x2="-94.18" y2="0.56" width="0.254" layer="21"/>
<wire x1="-94.18" y1="0.56" x2="-94.18" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-93.78" y1="4.39" x2="-93.78" y2="2.56" width="0.254" layer="21"/>
<wire x1="-93.78" y1="2.56" x2="-93.78" y2="0.56" width="0.254" layer="21"/>
<wire x1="-93.78" y1="0.56" x2="-93.78" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-94.18" y1="-0.41" x2="-93.78" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-95.05" y1="2.56" x2="-94.18" y2="2.56" width="0.254" layer="21"/>
<wire x1="-95.05" y1="0.56" x2="-94.18" y2="0.56" width="0.254" layer="21"/>
<wire x1="-95.05" y1="4.39" x2="-95.45" y2="4.39" width="0.254" layer="21"/>
<wire x1="-95.45" y1="4.39" x2="-95.45" y2="2.56" width="0.254" layer="21"/>
<wire x1="-95.45" y1="2.56" x2="-95.45" y2="0.56" width="0.254" layer="21"/>
<wire x1="-95.45" y1="0.56" x2="-95.45" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-95.05" y1="4.39" x2="-95.05" y2="2.56" width="0.254" layer="21"/>
<wire x1="-95.05" y1="2.56" x2="-95.05" y2="0.56" width="0.254" layer="21"/>
<wire x1="-95.05" y1="0.56" x2="-95.05" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-95.45" y1="-0.41" x2="-95.05" y2="-0.41" width="0.254" layer="21"/>
<wire x1="-102.085" y1="-8.26" x2="-102.085" y2="-19.06" width="0.254" layer="47"/>
<wire x1="-102.085" y1="-19.06" x2="6.835" y2="-19.06" width="0.254" layer="47"/>
<wire x1="6.835" y1="-19.06" x2="6.835" y2="-8.26" width="0.254" layer="47"/>
<wire x1="-95.25" y1="-2.54" x2="-95.25" y2="-17.78" width="0.254" layer="47"/>
<wire x1="-95.25" y1="-17.78" x2="-87.63" y2="-17.78" width="0.254" layer="47"/>
<wire x1="-87.63" y1="-17.78" x2="-87.63" y2="-2.54" width="0.254" layer="47"/>
<wire x1="-87.63" y1="-2.54" x2="-95.25" y2="-2.54" width="0.254" layer="47"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="-17.78" width="0.254" layer="47"/>
<wire x1="-7.62" y1="-17.78" x2="0" y2="-17.78" width="0.254" layer="47"/>
<wire x1="0" y1="-17.78" x2="0" y2="-2.54" width="0.254" layer="47"/>
<wire x1="0" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="47"/>
<wire x1="-59.055" y1="-2.54" x2="-59.055" y2="-17.78" width="0.254" layer="47"/>
<wire x1="-59.055" y1="-17.78" x2="-51.435" y2="-17.78" width="0.254" layer="47"/>
<wire x1="-51.435" y1="-17.78" x2="-51.435" y2="-2.54" width="0.254" layer="47"/>
<wire x1="-51.435" y1="-2.54" x2="-59.055" y2="-2.54" width="0.254" layer="47"/>
<wire x1="-83.185" y1="-2.54" x2="-83.185" y2="-17.78" width="0.254" layer="47"/>
<wire x1="-83.185" y1="-17.78" x2="-75.565" y2="-17.78" width="0.254" layer="47"/>
<wire x1="-75.565" y1="-17.78" x2="-75.565" y2="-2.54" width="0.254" layer="47"/>
<wire x1="-75.565" y1="-2.54" x2="-83.185" y2="-2.54" width="0.254" layer="47"/>
<wire x1="-71.12" y1="-2.54" x2="-71.12" y2="-17.78" width="0.254" layer="47"/>
<wire x1="-71.12" y1="-17.78" x2="-63.5" y2="-17.78" width="0.254" layer="47"/>
<wire x1="-63.5" y1="-17.78" x2="-63.5" y2="-2.54" width="0.254" layer="47"/>
<wire x1="-63.5" y1="-2.54" x2="-71.12" y2="-2.54" width="0.254" layer="47"/>
<wire x1="-19.685" y1="-2.54" x2="-19.685" y2="-17.78" width="0.254" layer="47"/>
<wire x1="-19.685" y1="-17.78" x2="-12.065" y2="-17.78" width="0.254" layer="47"/>
<wire x1="-12.065" y1="-17.78" x2="-12.065" y2="-2.54" width="0.254" layer="47"/>
<wire x1="-12.065" y1="-2.54" x2="-19.685" y2="-2.54" width="0.254" layer="47"/>
<wire x1="-31.75" y1="-2.54" x2="-31.75" y2="-17.78" width="0.254" layer="47"/>
<wire x1="-31.75" y1="-17.78" x2="-24.13" y2="-17.78" width="0.254" layer="47"/>
<wire x1="-24.13" y1="-17.78" x2="-24.13" y2="-2.54" width="0.254" layer="47"/>
<wire x1="-24.13" y1="-2.54" x2="-31.75" y2="-2.54" width="0.254" layer="47"/>
<wire x1="-43.815" y1="-2.54" x2="-43.815" y2="-17.78" width="0.254" layer="47"/>
<wire x1="-43.815" y1="-17.78" x2="-36.195" y2="-17.78" width="0.254" layer="47"/>
<wire x1="-36.195" y1="-17.78" x2="-36.195" y2="-2.54" width="0.254" layer="47"/>
<wire x1="-36.195" y1="-2.54" x2="-43.815" y2="-2.54" width="0.254" layer="47"/>
</package>
</packages>
<symbols>
<symbol name="ZAS24">
<wire x1="0" y1="0" x2="10.16" y2="0" width="0.254" layer="94"/>
<wire x1="10.16" y1="0" x2="10.16" y2="-63.5" width="0.254" layer="94"/>
<wire x1="10.16" y1="-63.5" x2="0" y2="-63.5" width="0.254" layer="94"/>
<wire x1="3.175" y1="-3.175" x2="3.175" y2="-1.905" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-1.905" x2="7.62" y2="-1.905" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-3.175" x2="7.62" y2="-3.175" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-5.715" x2="3.175" y2="-4.445" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-4.445" x2="7.62" y2="-4.445" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-5.715" x2="7.62" y2="-5.715" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-8.255" x2="3.175" y2="-6.985" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-6.985" x2="7.62" y2="-6.985" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-8.255" x2="7.62" y2="-8.255" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-10.795" x2="3.175" y2="-9.525" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-9.525" x2="7.62" y2="-9.525" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-10.795" x2="7.62" y2="-10.795" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-13.335" x2="3.175" y2="-12.065" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-12.065" x2="7.62" y2="-12.065" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-13.335" x2="7.62" y2="-13.335" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-15.875" x2="3.175" y2="-14.605" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-14.605" x2="7.62" y2="-14.605" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-15.875" x2="7.62" y2="-15.875" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-18.415" x2="3.175" y2="-17.145" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-17.145" x2="7.62" y2="-17.145" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-18.415" x2="7.62" y2="-18.415" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-20.955" x2="3.175" y2="-19.685" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-19.685" x2="7.62" y2="-19.685" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-20.955" x2="7.62" y2="-20.955" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-23.495" x2="3.175" y2="-22.225" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-22.225" x2="7.62" y2="-22.225" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-23.495" x2="7.62" y2="-23.495" width="0.3048" layer="94"/>
<wire x1="-2.54" y1="-2.54" x2="2.54" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-5.08" x2="2.54" y2="-5.08" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-7.62" x2="2.54" y2="-7.62" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-10.16" x2="2.54" y2="-10.16" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-12.7" x2="2.54" y2="-12.7" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-15.24" x2="2.54" y2="-15.24" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-17.78" x2="2.54" y2="-17.78" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-20.32" x2="2.54" y2="-20.32" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-22.86" x2="2.54" y2="-22.86" width="0.1524" layer="94"/>
<wire x1="3.175" y1="-26.035" x2="3.175" y2="-24.765" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-24.765" x2="7.62" y2="-24.765" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-26.035" x2="7.62" y2="-26.035" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-28.575" x2="3.175" y2="-27.305" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-27.305" x2="7.62" y2="-27.305" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-28.575" x2="7.62" y2="-28.575" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-31.115" x2="3.175" y2="-29.845" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-29.845" x2="7.62" y2="-29.845" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-31.115" x2="7.62" y2="-31.115" width="0.3048" layer="94"/>
<wire x1="-2.54" y1="-25.4" x2="2.54" y2="-25.4" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-27.94" x2="2.54" y2="-27.94" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-30.48" x2="2.54" y2="-30.48" width="0.1524" layer="94"/>
<wire x1="3.175" y1="-33.655" x2="3.175" y2="-32.385" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-32.385" x2="7.62" y2="-32.385" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-33.655" x2="7.62" y2="-33.655" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-36.195" x2="3.175" y2="-34.925" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-34.925" x2="7.62" y2="-34.925" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-36.195" x2="7.62" y2="-36.195" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-38.735" x2="3.175" y2="-37.465" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-37.465" x2="7.62" y2="-37.465" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-38.735" x2="7.62" y2="-38.735" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-41.275" x2="3.175" y2="-40.005" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-40.005" x2="7.62" y2="-40.005" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-41.275" x2="7.62" y2="-41.275" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-43.815" x2="3.175" y2="-42.545" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-42.545" x2="7.62" y2="-42.545" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-43.815" x2="7.62" y2="-43.815" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-46.355" x2="3.175" y2="-45.085" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-45.085" x2="7.62" y2="-45.085" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-46.355" x2="7.62" y2="-46.355" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-48.895" x2="3.175" y2="-47.625" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-47.625" x2="7.62" y2="-47.625" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-48.895" x2="7.62" y2="-48.895" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-51.435" x2="3.175" y2="-50.165" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-50.165" x2="7.62" y2="-50.165" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-51.435" x2="7.62" y2="-51.435" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-53.975" x2="3.175" y2="-52.705" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-52.705" x2="7.62" y2="-52.705" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-53.975" x2="7.62" y2="-53.975" width="0.3048" layer="94"/>
<wire x1="-2.54" y1="-33.02" x2="2.54" y2="-33.02" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-35.56" x2="2.54" y2="-35.56" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-38.1" x2="2.54" y2="-38.1" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-40.64" x2="2.54" y2="-40.64" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-43.18" x2="2.54" y2="-43.18" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-45.72" x2="2.54" y2="-45.72" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-48.26" x2="2.54" y2="-48.26" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-50.8" x2="2.54" y2="-50.8" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-53.34" x2="2.54" y2="-53.34" width="0.1524" layer="94"/>
<wire x1="3.175" y1="-56.515" x2="3.175" y2="-55.245" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-55.245" x2="7.62" y2="-55.245" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-56.515" x2="7.62" y2="-56.515" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-59.055" x2="3.175" y2="-57.785" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-57.785" x2="7.62" y2="-57.785" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-59.055" x2="7.62" y2="-59.055" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-61.595" x2="3.175" y2="-60.325" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-60.325" x2="7.62" y2="-60.325" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-61.595" x2="7.62" y2="-61.595" width="0.3048" layer="94"/>
<wire x1="-2.54" y1="-55.88" x2="2.54" y2="-55.88" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-58.42" x2="2.54" y2="-58.42" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-60.96" x2="2.54" y2="-60.96" width="0.1524" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="-63.5" width="0.254" layer="94"/>
<text x="0" y="3.81" size="1.524" layer="95">&gt;NAME</text>
<text x="0" y="1.27" size="1.524" layer="96">&gt;VALUE</text>
<pin name="1" x="-5.08" y="-2.54" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="2" x="-5.08" y="-5.08" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="3" x="-5.08" y="-7.62" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="4" x="-5.08" y="-10.16" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="5" x="-5.08" y="-12.7" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="6" x="-5.08" y="-15.24" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="7" x="-5.08" y="-17.78" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="8" x="-5.08" y="-20.32" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="9" x="-5.08" y="-22.86" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="10" x="-5.08" y="-25.4" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="11" x="-5.08" y="-27.94" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="12" x="-5.08" y="-30.48" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="13" x="-5.08" y="-33.02" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="14" x="-5.08" y="-35.56" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="15" x="-5.08" y="-38.1" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="16" x="-5.08" y="-40.64" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="17" x="-5.08" y="-43.18" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="18" x="-5.08" y="-45.72" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="19" x="-5.08" y="-48.26" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="20" x="-5.08" y="-50.8" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="21" x="-5.08" y="-53.34" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="22" x="-5.08" y="-55.88" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="23" x="-5.08" y="-58.42" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="24" x="-5.08" y="-60.96" visible="pad" length="short" direction="pas" swaplevel="1"/>
</symbol>
<symbol name="ZAS26">
<wire x1="0" y1="0" x2="10.16" y2="0" width="0.254" layer="94"/>
<wire x1="10.16" y1="0" x2="10.16" y2="-68.58" width="0.254" layer="94"/>
<wire x1="10.16" y1="-68.58" x2="0" y2="-68.58" width="0.254" layer="94"/>
<wire x1="3.175" y1="-3.175" x2="3.175" y2="-1.905" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-1.905" x2="7.62" y2="-1.905" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-3.175" x2="7.62" y2="-3.175" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-5.715" x2="3.175" y2="-4.445" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-4.445" x2="7.62" y2="-4.445" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-5.715" x2="7.62" y2="-5.715" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-8.255" x2="3.175" y2="-6.985" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-6.985" x2="7.62" y2="-6.985" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-8.255" x2="7.62" y2="-8.255" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-10.795" x2="3.175" y2="-9.525" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-9.525" x2="7.62" y2="-9.525" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-10.795" x2="7.62" y2="-10.795" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-13.335" x2="3.175" y2="-12.065" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-12.065" x2="7.62" y2="-12.065" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-13.335" x2="7.62" y2="-13.335" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-15.875" x2="3.175" y2="-14.605" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-14.605" x2="7.62" y2="-14.605" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-15.875" x2="7.62" y2="-15.875" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-18.415" x2="3.175" y2="-17.145" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-17.145" x2="7.62" y2="-17.145" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-18.415" x2="7.62" y2="-18.415" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-20.955" x2="3.175" y2="-19.685" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-19.685" x2="7.62" y2="-19.685" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-20.955" x2="7.62" y2="-20.955" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-23.495" x2="3.175" y2="-22.225" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-22.225" x2="7.62" y2="-22.225" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-23.495" x2="7.62" y2="-23.495" width="0.3048" layer="94"/>
<wire x1="-2.54" y1="-2.54" x2="2.54" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-5.08" x2="2.54" y2="-5.08" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-7.62" x2="2.54" y2="-7.62" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-10.16" x2="2.54" y2="-10.16" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-12.7" x2="2.54" y2="-12.7" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-15.24" x2="2.54" y2="-15.24" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-17.78" x2="2.54" y2="-17.78" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-20.32" x2="2.54" y2="-20.32" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-22.86" x2="2.54" y2="-22.86" width="0.1524" layer="94"/>
<wire x1="3.175" y1="-26.035" x2="3.175" y2="-24.765" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-24.765" x2="7.62" y2="-24.765" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-26.035" x2="7.62" y2="-26.035" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-28.575" x2="3.175" y2="-27.305" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-27.305" x2="7.62" y2="-27.305" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-28.575" x2="7.62" y2="-28.575" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-31.115" x2="3.175" y2="-29.845" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-29.845" x2="7.62" y2="-29.845" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-31.115" x2="7.62" y2="-31.115" width="0.3048" layer="94"/>
<wire x1="-2.54" y1="-25.4" x2="2.54" y2="-25.4" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-27.94" x2="2.54" y2="-27.94" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-30.48" x2="2.54" y2="-30.48" width="0.1524" layer="94"/>
<wire x1="3.175" y1="-33.655" x2="3.175" y2="-32.385" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-32.385" x2="7.62" y2="-32.385" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-33.655" x2="7.62" y2="-33.655" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-36.195" x2="3.175" y2="-34.925" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-34.925" x2="7.62" y2="-34.925" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-36.195" x2="7.62" y2="-36.195" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-38.735" x2="3.175" y2="-37.465" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-37.465" x2="7.62" y2="-37.465" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-38.735" x2="7.62" y2="-38.735" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-41.275" x2="3.175" y2="-40.005" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-40.005" x2="7.62" y2="-40.005" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-41.275" x2="7.62" y2="-41.275" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-43.815" x2="3.175" y2="-42.545" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-42.545" x2="7.62" y2="-42.545" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-43.815" x2="7.62" y2="-43.815" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-46.355" x2="3.175" y2="-45.085" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-45.085" x2="7.62" y2="-45.085" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-46.355" x2="7.62" y2="-46.355" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-48.895" x2="3.175" y2="-47.625" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-47.625" x2="7.62" y2="-47.625" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-48.895" x2="7.62" y2="-48.895" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-51.435" x2="3.175" y2="-50.165" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-50.165" x2="7.62" y2="-50.165" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-51.435" x2="7.62" y2="-51.435" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-53.975" x2="3.175" y2="-52.705" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-52.705" x2="7.62" y2="-52.705" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-53.975" x2="7.62" y2="-53.975" width="0.3048" layer="94"/>
<wire x1="-2.54" y1="-33.02" x2="2.54" y2="-33.02" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-35.56" x2="2.54" y2="-35.56" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-38.1" x2="2.54" y2="-38.1" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-40.64" x2="2.54" y2="-40.64" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-43.18" x2="2.54" y2="-43.18" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-45.72" x2="2.54" y2="-45.72" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-48.26" x2="2.54" y2="-48.26" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-50.8" x2="2.54" y2="-50.8" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-53.34" x2="2.54" y2="-53.34" width="0.1524" layer="94"/>
<wire x1="3.175" y1="-56.515" x2="3.175" y2="-55.245" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-55.245" x2="7.62" y2="-55.245" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-56.515" x2="7.62" y2="-56.515" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-59.055" x2="3.175" y2="-57.785" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-57.785" x2="7.62" y2="-57.785" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-59.055" x2="7.62" y2="-59.055" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-61.595" x2="3.175" y2="-60.325" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-60.325" x2="7.62" y2="-60.325" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-61.595" x2="7.62" y2="-61.595" width="0.3048" layer="94"/>
<wire x1="-2.54" y1="-55.88" x2="2.54" y2="-55.88" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-58.42" x2="2.54" y2="-58.42" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-60.96" x2="2.54" y2="-60.96" width="0.1524" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="-68.58" width="0.254" layer="94"/>
<text x="0" y="3.81" size="1.524" layer="95">&gt;NAME</text>
<text x="0" y="1.27" size="1.524" layer="96">&gt;VALUE</text>
<pin name="1" x="-5.08" y="-2.54" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="2" x="-5.08" y="-5.08" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="3" x="-5.08" y="-7.62" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="4" x="-5.08" y="-10.16" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="5" x="-5.08" y="-12.7" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="6" x="-5.08" y="-15.24" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="7" x="-5.08" y="-17.78" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="8" x="-5.08" y="-20.32" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="9" x="-5.08" y="-22.86" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="10" x="-5.08" y="-25.4" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="11" x="-5.08" y="-27.94" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="12" x="-5.08" y="-30.48" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="13" x="-5.08" y="-33.02" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="14" x="-5.08" y="-35.56" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="15" x="-5.08" y="-38.1" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="16" x="-5.08" y="-40.64" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="17" x="-5.08" y="-43.18" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="18" x="-5.08" y="-45.72" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="19" x="-5.08" y="-48.26" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="20" x="-5.08" y="-50.8" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="21" x="-5.08" y="-53.34" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="22" x="-5.08" y="-55.88" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="23" x="-5.08" y="-58.42" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="24" x="-5.08" y="-60.96" visible="pad" length="short" direction="pas" swaplevel="1"/>
<wire x1="3.175" y1="-64.135" x2="3.175" y2="-62.865" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-62.865" x2="7.62" y2="-62.865" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-64.135" x2="7.62" y2="-64.135" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-66.675" x2="3.175" y2="-65.405" width="0.3048" layer="94" curve="-180"/>
<wire x1="3.175" y1="-65.405" x2="7.62" y2="-65.405" width="0.3048" layer="94"/>
<wire x1="3.175" y1="-66.675" x2="7.62" y2="-66.675" width="0.3048" layer="94"/>
<wire x1="-2.54" y1="-63.5" x2="2.54" y2="-63.5" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-66.04" x2="2.54" y2="-66.04" width="0.1524" layer="94"/>
<pin name="25" x="-5.08" y="-63.5" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="26" x="-5.08" y="-66.04" visible="pad" length="short" direction="pas" swaplevel="1"/>
</symbol>
<symbol name="SIMM72">
<wire x1="-11.43" y1="-48.26" x2="11.43" y2="-48.26" width="0.254" layer="94"/>
<wire x1="11.43" y1="-48.26" x2="11.43" y2="48.26" width="0.254" layer="94"/>
<wire x1="11.43" y1="48.26" x2="-11.43" y2="48.26" width="0.254" layer="94"/>
<wire x1="-11.43" y1="48.26" x2="-11.43" y2="-48.26" width="0.254" layer="94"/>
<text x="-11.43" y="49.53" size="1.524" layer="95">&gt;NAME</text>
<text x="-11.43" y="-50.8" size="1.524" layer="96">&gt;VALUE</text>
<pin name="A0" x="-16.51" y="45.72" length="middle" direction="in" swaplevel="1"/>
<pin name="A1" x="-16.51" y="43.18" length="middle" direction="in" swaplevel="1"/>
<pin name="A2" x="-16.51" y="40.64" length="middle" direction="in" swaplevel="1"/>
<pin name="D0" x="16.51" y="45.72" length="middle" swaplevel="1" rot="R180"/>
<pin name="D1" x="16.51" y="43.18" length="middle" swaplevel="1" rot="R180"/>
<pin name="D2" x="16.51" y="40.64" length="middle" swaplevel="1" rot="R180"/>
<pin name="D3" x="16.51" y="38.1" length="middle" swaplevel="1" rot="R180"/>
<pin name="D4" x="16.51" y="35.56" length="middle" swaplevel="1" rot="R180"/>
<pin name="D5" x="16.51" y="33.02" length="middle" swaplevel="1" rot="R180"/>
<pin name="D6" x="16.51" y="30.48" length="middle" swaplevel="1" rot="R180"/>
<pin name="D7" x="16.51" y="27.94" length="middle" swaplevel="1" rot="R180"/>
<pin name="!RAS0" x="-16.51" y="12.7" length="middle" direction="in" swaplevel="1"/>
<pin name="PD1" x="-16.51" y="-15.24" length="middle" swaplevel="1"/>
<pin name="VCC" x="-16.51" y="-40.64" length="middle" direction="pwr" swaplevel="1"/>
<pin name="A3" x="-16.51" y="38.1" length="middle" direction="in" swaplevel="1"/>
<pin name="A4" x="-16.51" y="35.56" length="middle" direction="in" swaplevel="1"/>
<pin name="A5" x="-16.51" y="33.02" length="middle" direction="in" swaplevel="1"/>
<pin name="A6" x="-16.51" y="30.48" length="middle" direction="in" swaplevel="1"/>
<pin name="A7" x="-16.51" y="27.94" length="middle" direction="in" swaplevel="1"/>
<pin name="A8" x="-16.51" y="25.4" length="middle" direction="in" swaplevel="1"/>
<pin name="A9" x="-16.51" y="22.86" length="middle" direction="in" swaplevel="1"/>
<pin name="A10" x="-16.51" y="20.32" length="middle" direction="in" swaplevel="1"/>
<pin name="A11" x="-16.51" y="17.78" length="middle" direction="in" swaplevel="1"/>
<pin name="!RAS1" x="-16.51" y="10.16" length="middle" direction="in" swaplevel="1"/>
<pin name="!RAS2" x="-16.51" y="7.62" length="middle" direction="in" swaplevel="1"/>
<pin name="!RAS3" x="-16.51" y="5.08" length="middle" direction="in" swaplevel="1"/>
<pin name="!WE" x="-16.51" y="-12.7" length="middle" direction="in" swaplevel="1"/>
<pin name="PD2" x="-16.51" y="-17.78" length="middle" swaplevel="1"/>
<pin name="GND" x="-16.51" y="-45.72" length="middle" direction="pwr" swaplevel="1"/>
<pin name="D8" x="16.51" y="25.4" length="middle" swaplevel="1" rot="R180"/>
<pin name="D9" x="16.51" y="22.86" length="middle" swaplevel="1" rot="R180"/>
<pin name="D10" x="16.51" y="20.32" length="middle" swaplevel="1" rot="R180"/>
<pin name="D11" x="16.51" y="17.78" length="middle" swaplevel="1" rot="R180"/>
<pin name="D12" x="16.51" y="15.24" length="middle" swaplevel="1" rot="R180"/>
<pin name="D13" x="16.51" y="12.7" length="middle" swaplevel="1" rot="R180"/>
<pin name="D14" x="16.51" y="10.16" length="middle" swaplevel="1" rot="R180"/>
<pin name="D15" x="16.51" y="7.62" length="middle" swaplevel="1" rot="R180"/>
<pin name="D16" x="16.51" y="5.08" length="middle" swaplevel="1" rot="R180"/>
<pin name="D17" x="16.51" y="2.54" length="middle" swaplevel="1" rot="R180"/>
<pin name="D18" x="16.51" y="0" length="middle" swaplevel="1" rot="R180"/>
<pin name="D19" x="16.51" y="-2.54" length="middle" swaplevel="1" rot="R180"/>
<pin name="D20" x="16.51" y="-5.08" length="middle" swaplevel="1" rot="R180"/>
<pin name="D21" x="16.51" y="-7.62" length="middle" swaplevel="1" rot="R180"/>
<pin name="D22" x="16.51" y="-10.16" length="middle" swaplevel="1" rot="R180"/>
<pin name="D23" x="16.51" y="-12.7" length="middle" swaplevel="1" rot="R180"/>
<pin name="D24" x="16.51" y="-15.24" length="middle" swaplevel="1" rot="R180"/>
<pin name="D25" x="16.51" y="-17.78" length="middle" swaplevel="1" rot="R180"/>
<pin name="D26" x="16.51" y="-20.32" length="middle" swaplevel="1" rot="R180"/>
<pin name="D27" x="16.51" y="-22.86" length="middle" swaplevel="1" rot="R180"/>
<pin name="D28" x="16.51" y="-25.4" length="middle" swaplevel="1" rot="R180"/>
<pin name="D29" x="16.51" y="-27.94" length="middle" swaplevel="1" rot="R180"/>
<pin name="D30" x="16.51" y="-30.48" length="middle" swaplevel="1" rot="R180"/>
<pin name="D31" x="16.51" y="-33.02" length="middle" swaplevel="1" rot="R180"/>
<pin name="!CAS0" x="-16.51" y="0" length="middle" direction="in" swaplevel="1"/>
<pin name="!CAS1" x="-16.51" y="-2.54" length="middle" direction="in" swaplevel="1"/>
<pin name="!CAS2" x="-16.51" y="-5.08" length="middle" direction="in" swaplevel="1"/>
<pin name="!CAS3" x="-16.51" y="-7.62" length="middle" direction="in" swaplevel="1"/>
<pin name="PD3" x="-16.51" y="-20.32" length="middle" swaplevel="1"/>
<pin name="PD4" x="-16.51" y="-22.86" length="middle" swaplevel="1"/>
<pin name="PD5" x="-16.51" y="-25.4" length="middle" swaplevel="1"/>
<pin name="DP0" x="16.51" y="-38.1" length="middle" swaplevel="1" rot="R180"/>
<pin name="DP1" x="16.51" y="-40.64" length="middle" swaplevel="1" rot="R180"/>
<pin name="DP2" x="16.51" y="-43.18" length="middle" swaplevel="1" rot="R180"/>
<pin name="DP3" x="16.51" y="-45.72" length="middle" swaplevel="1" rot="R180"/>
<pin name="!ECC" x="-16.51" y="-30.48" length="middle" swaplevel="1"/>
<pin name="!EDO" x="-16.51" y="-33.02" length="middle" swaplevel="1"/>
<pin name="PD" x="-16.51" y="-35.56" length="middle" swaplevel="1"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="20-Z2R24T" prefix="X" uservalue="yes">
<gates>
<gate name="A" symbol="ZAS24" x="0" y="0"/>
</gates>
<devices>
<device name="" package="20-Z2R24T">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="10" pad="10"/>
<connect gate="A" pin="11" pad="11"/>
<connect gate="A" pin="12" pad="12"/>
<connect gate="A" pin="13" pad="13"/>
<connect gate="A" pin="14" pad="14"/>
<connect gate="A" pin="15" pad="15"/>
<connect gate="A" pin="16" pad="16"/>
<connect gate="A" pin="17" pad="17"/>
<connect gate="A" pin="18" pad="18"/>
<connect gate="A" pin="19" pad="19"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="20" pad="20"/>
<connect gate="A" pin="21" pad="21"/>
<connect gate="A" pin="22" pad="22"/>
<connect gate="A" pin="23" pad="23"/>
<connect gate="A" pin="24" pad="24"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
<connect gate="A" pin="9" pad="9"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="20-Z2R26T" prefix="X" uservalue="yes">
<gates>
<gate name="A" symbol="ZAS26" x="0" y="0"/>
</gates>
<devices>
<device name="" package="20-Z2R26T">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="10" pad="10"/>
<connect gate="A" pin="11" pad="11"/>
<connect gate="A" pin="12" pad="12"/>
<connect gate="A" pin="13" pad="13"/>
<connect gate="A" pin="14" pad="14"/>
<connect gate="A" pin="15" pad="15"/>
<connect gate="A" pin="16" pad="16"/>
<connect gate="A" pin="17" pad="17"/>
<connect gate="A" pin="18" pad="18"/>
<connect gate="A" pin="19" pad="19"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="20" pad="20"/>
<connect gate="A" pin="21" pad="21"/>
<connect gate="A" pin="22" pad="22"/>
<connect gate="A" pin="23" pad="23"/>
<connect gate="A" pin="24" pad="24"/>
<connect gate="A" pin="25" pad="25"/>
<connect gate="A" pin="26" pad="26"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
<connect gate="A" pin="9" pad="9"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="SIMM72" prefix="SIMM" uservalue="yes">
<gates>
<gate name="A" symbol="SIMM72" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SIMM72A">
<connects>
<connect gate="A" pin="!CAS0" pad="40"/>
<connect gate="A" pin="!CAS1" pad="43"/>
<connect gate="A" pin="!CAS2" pad="41"/>
<connect gate="A" pin="!CAS3" pad="42"/>
<connect gate="A" pin="!ECC" pad="48"/>
<connect gate="A" pin="!EDO" pad="66"/>
<connect gate="A" pin="!RAS0" pad="44"/>
<connect gate="A" pin="!RAS1" pad="45"/>
<connect gate="A" pin="!RAS2" pad="34"/>
<connect gate="A" pin="!RAS3" pad="33"/>
<connect gate="A" pin="!WE" pad="47"/>
<connect gate="A" pin="A0" pad="12"/>
<connect gate="A" pin="A1" pad="13"/>
<connect gate="A" pin="A10" pad="19"/>
<connect gate="A" pin="A11" pad="29"/>
<connect gate="A" pin="A2" pad="14"/>
<connect gate="A" pin="A3" pad="15"/>
<connect gate="A" pin="A4" pad="16"/>
<connect gate="A" pin="A5" pad="17"/>
<connect gate="A" pin="A6" pad="18"/>
<connect gate="A" pin="A7" pad="28"/>
<connect gate="A" pin="A8" pad="31"/>
<connect gate="A" pin="A9" pad="32"/>
<connect gate="A" pin="D0" pad="2"/>
<connect gate="A" pin="D1" pad="4"/>
<connect gate="A" pin="D10" pad="53"/>
<connect gate="A" pin="D11" pad="55"/>
<connect gate="A" pin="D12" pad="57"/>
<connect gate="A" pin="D13" pad="61"/>
<connect gate="A" pin="D14" pad="63"/>
<connect gate="A" pin="D15" pad="65"/>
<connect gate="A" pin="D16" pad="3"/>
<connect gate="A" pin="D17" pad="5"/>
<connect gate="A" pin="D18" pad="7"/>
<connect gate="A" pin="D19" pad="9"/>
<connect gate="A" pin="D2" pad="6"/>
<connect gate="A" pin="D20" pad="21"/>
<connect gate="A" pin="D21" pad="23"/>
<connect gate="A" pin="D22" pad="25"/>
<connect gate="A" pin="D23" pad="27"/>
<connect gate="A" pin="D24" pad="50"/>
<connect gate="A" pin="D25" pad="52"/>
<connect gate="A" pin="D26" pad="54"/>
<connect gate="A" pin="D27" pad="56"/>
<connect gate="A" pin="D28" pad="58"/>
<connect gate="A" pin="D29" pad="60"/>
<connect gate="A" pin="D3" pad="8"/>
<connect gate="A" pin="D30" pad="62"/>
<connect gate="A" pin="D31" pad="64"/>
<connect gate="A" pin="D4" pad="20"/>
<connect gate="A" pin="D5" pad="22"/>
<connect gate="A" pin="D6" pad="24"/>
<connect gate="A" pin="D7" pad="26"/>
<connect gate="A" pin="D8" pad="49"/>
<connect gate="A" pin="D9" pad="51"/>
<connect gate="A" pin="DP0" pad="36"/>
<connect gate="A" pin="DP1" pad="37"/>
<connect gate="A" pin="DP2" pad="35"/>
<connect gate="A" pin="DP3" pad="38"/>
<connect gate="A" pin="GND" pad="1 39 72"/>
<connect gate="A" pin="PD" pad="71"/>
<connect gate="A" pin="PD1" pad="67"/>
<connect gate="A" pin="PD2" pad="68"/>
<connect gate="A" pin="PD3" pad="69"/>
<connect gate="A" pin="PD4" pad="70"/>
<connect gate="A" pin="PD5" pad="11"/>
<connect gate="A" pin="VCC" pad="10 30 59"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="IC">
<packages>
<package name="SO20">
<wire x1="-6.3" y1="-2.65" x2="6.3" y2="-2.65" width="0.254" layer="21"/>
<wire x1="6.3" y1="-2.65" x2="6.3" y2="-2.2987" width="0.254" layer="21"/>
<wire x1="6.3" y1="-2.2987" x2="6.3" y2="-2.0447" width="0.254" layer="21"/>
<wire x1="6.3" y1="-2.0447" x2="6.3" y2="2.65" width="0.254" layer="21"/>
<wire x1="6.3" y1="2.65" x2="-6.3" y2="2.65" width="0.254" layer="21"/>
<wire x1="-6.3" y1="2.65" x2="-6.3" y2="0.635" width="0.254" layer="21"/>
<wire x1="-6.3" y1="0.635" x2="-5.85" y2="0.635" width="0.254" layer="21"/>
<wire x1="-5.85" y1="0.635" x2="-5.85" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-5.85" y1="-0.635" x2="-6.3" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-6.3" y1="-0.635" x2="-6.3" y2="-2.0447" width="0.254" layer="21"/>
<wire x1="-6.3" y1="-2.0447" x2="-6.3" y2="-2.2987" width="0.254" layer="21"/>
<wire x1="-6.3" y1="-2.2987" x2="-6.3" y2="-2.65" width="0.254" layer="21"/>
<wire x1="-6.3246" y1="-0.635" x2="-6.3246" y2="-4.9403" width="0.2032" layer="51"/>
<wire x1="-6.3246" y1="-4.9403" x2="6.3246" y2="-4.9403" width="0.2032" layer="51"/>
<wire x1="6.3246" y1="-4.9403" x2="6.3246" y2="4.9403" width="0.2032" layer="51"/>
<wire x1="6.3246" y1="4.9403" x2="-6.3246" y2="4.9403" width="0.2032" layer="51"/>
<wire x1="-6.3246" y1="4.9403" x2="-6.3246" y2="0.635" width="0.2032" layer="51"/>
<wire x1="-6.3246" y1="0.635" x2="-5.85" y2="0.635" width="0.2032" layer="51"/>
<wire x1="-5.85" y1="0.635" x2="-5.85" y2="-0.635" width="0.2032" layer="51"/>
<wire x1="-5.85" y1="-0.635" x2="-6.3246" y2="-0.635" width="0.2032" layer="51"/>
<wire x1="-6.3" y1="-2.2987" x2="6.3" y2="-2.2987" width="0.254" layer="21"/>
<wire x1="-6.3" y1="-2.0447" x2="6.3" y2="-2.0447" width="0.254" layer="21"/>
<smd name="1" x="-5.715" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="20" x="-5.715" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="2" x="-4.445" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="3" x="-3.175" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="19" x="-4.445" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="18" x="-3.175" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="4" x="-1.905" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="17" x="-1.905" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="5" x="-0.635" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="6" x="0.635" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="7" x="1.905" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="8" x="3.175" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="9" x="4.445" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="10" x="5.715" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="16" x="-0.635" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="15" x="0.635" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="14" x="1.905" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="13" x="3.175" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="12" x="4.445" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="11" x="5.715" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<text x="-2.54" y="0.3175" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-0.9525" size="1.016" layer="27">&gt;VALUE</text>
<text x="-3.175" y="-0.4445" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<rectangle x1="-5.8928" y1="-3.9" x2="-5.5372" y2="-2.6035" layer="21"/>
<rectangle x1="-4.6228" y1="-3.9" x2="-4.2672" y2="-2.6035" layer="21"/>
<rectangle x1="-3.3528" y1="-3.9" x2="-2.9972" y2="-2.6035" layer="21"/>
<rectangle x1="-2.0828" y1="-3.9" x2="-1.7272" y2="-2.6035" layer="21"/>
<rectangle x1="-0.8128" y1="-3.9" x2="-0.4572" y2="-2.6035" layer="21"/>
<rectangle x1="0.4572" y1="-3.9" x2="0.8128" y2="-2.6035" layer="21"/>
<rectangle x1="1.7272" y1="-3.9" x2="2.0828" y2="-2.6035" layer="21"/>
<rectangle x1="2.9972" y1="-3.9" x2="3.3528" y2="-2.6035" layer="21"/>
<rectangle x1="4.2672" y1="-3.9" x2="4.6228" y2="-2.6035" layer="21"/>
<rectangle x1="5.5372" y1="-3.9" x2="5.8928" y2="-2.6035" layer="21"/>
<rectangle x1="-5.8928" y1="2.6035" x2="-5.5372" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="-4.6228" y1="2.6035" x2="-4.2672" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="-3.3528" y1="2.6035" x2="-2.9972" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="-2.0828" y1="2.6035" x2="-1.7272" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="-0.8128" y1="2.6035" x2="-0.4572" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="0.4572" y1="2.6035" x2="0.8128" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="1.7272" y1="2.6035" x2="2.0828" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="2.9972" y1="2.6035" x2="3.3528" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="4.2672" y1="2.6035" x2="4.6228" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="5.5372" y1="2.6035" x2="5.8928" y2="3.9" layer="21" rot="R180"/>
</package>
<package name="SOT23-5">
<wire x1="1.4525" y1="0.77" x2="-1.4526" y2="0.77" width="0.254" layer="21"/>
<wire x1="-1.4526" y1="0.77" x2="-1.4526" y2="-0.7701" width="0.254" layer="21"/>
<wire x1="-1.4526" y1="-0.7701" x2="1.4525" y2="-0.7701" width="0.254" layer="21"/>
<wire x1="1.4525" y1="-0.7701" x2="1.4525" y2="0.77" width="0.254" layer="21"/>
<circle x="0.9525" y="0.3175" radius="0.127" width="0.254" layer="21"/>
<smd name="1" x="0.9525" y="1.27" dx="0.5842" dy="1.27" layer="1"/>
<smd name="2" x="0" y="1.27" dx="0.5842" dy="1.27" layer="1"/>
<smd name="3" x="-0.9525" y="1.27" dx="0.5842" dy="1.27" layer="1"/>
<smd name="4" x="-0.9525" y="-1.27" dx="0.5842" dy="1.27" layer="1"/>
<smd name="5" x="0.9525" y="-1.27" dx="0.5842" dy="1.27" layer="1"/>
<text x="2.2225" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="2.2225" y="-1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="2.2225" y="-0.635" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<rectangle x1="0.7025" y1="0.77" x2="1.2025" y2="1.27" layer="21"/>
<rectangle x1="-0.25" y1="0.77" x2="0.25" y2="1.27" layer="21"/>
<rectangle x1="-1.2026" y1="0.77" x2="-0.7026" y2="1.27" layer="21"/>
<rectangle x1="0.7025" y1="-1.2701" x2="1.2025" y2="-0.7701" layer="21"/>
<rectangle x1="-1.2026" y1="-1.2701" x2="-0.7026" y2="-0.7701" layer="21"/>
<wire x1="-1.5494" y1="2.2098" x2="1.5494" y2="2.2098" width="0.2032" layer="51"/>
<wire x1="1.5494" y1="2.2098" x2="1.5494" y2="0.3302" width="0.2032" layer="51"/>
<wire x1="1.5494" y1="0.3302" x2="1.27" y2="0.3302" width="0.2032" layer="51"/>
<wire x1="1.27" y1="0.3302" x2="1.27" y2="-0.3302" width="0.2032" layer="51"/>
<wire x1="1.27" y1="-0.3302" x2="1.5494" y2="-0.3302" width="0.2032" layer="51"/>
<wire x1="1.5494" y1="-0.3302" x2="1.5494" y2="-2.2098" width="0.2032" layer="51"/>
<wire x1="1.5494" y1="-2.2098" x2="-1.5494" y2="-2.2098" width="0.2032" layer="51"/>
<wire x1="-1.5494" y1="-2.2098" x2="-1.5494" y2="2.2098" width="0.2032" layer="51"/>
</package>
<package name="TSSOP20">
<wire x1="-3.3" y1="2.25" x2="3.3" y2="2.25" width="0.254" layer="21"/>
<wire x1="3.3" y1="2.25" x2="3.3" y2="-2.25" width="0.254" layer="21"/>
<wire x1="3.3" y1="-2.25" x2="-3.3" y2="-2.25" width="0.254" layer="21"/>
<wire x1="-3.3" y1="-2.25" x2="-3.3" y2="2.25" width="0.254" layer="21"/>
<wire x1="-3.429" y1="3.81" x2="3.429" y2="3.81" width="0.2032" layer="51"/>
<wire x1="3.429" y1="3.81" x2="3.429" y2="-3.81" width="0.2032" layer="51"/>
<wire x1="3.429" y1="-3.81" x2="-3.429" y2="-3.81" width="0.2032" layer="51"/>
<wire x1="-3.429" y1="-3.81" x2="-3.429" y2="-0.635" width="0.2032" layer="51"/>
<wire x1="-3.429" y1="-0.635" x2="-3.0734" y2="-0.635" width="0.2032" layer="51"/>
<wire x1="-3.0734" y1="-0.635" x2="-3.0734" y2="0.635" width="0.2032" layer="51"/>
<wire x1="-3.0734" y1="0.635" x2="-3.429" y2="0.635" width="0.2032" layer="51"/>
<wire x1="-3.429" y1="0.635" x2="-3.429" y2="3.81" width="0.2032" layer="51"/>
<circle x="-2.5" y="-1.45" radius="0.3535" width="0.254" layer="21"/>
<smd name="1" x="-2.925" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="2" x="-2.275" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="3" x="-1.625" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="4" x="-0.975" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="5" x="-0.325" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="6" x="0.325" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="7" x="0.975" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="8" x="1.625" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="9" x="2.275" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="10" x="2.925" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="11" x="2.925" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="12" x="2.275" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="13" x="1.625" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="14" x="0.975" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="15" x="0.325" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="16" x="-0.325" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="17" x="-0.975" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="18" x="-1.625" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="19" x="-2.275" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="20" x="-2.925" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<text x="-1.89" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.89" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.89" y="-0.762" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<rectangle x1="0.8251" y1="2.2" x2="1.1251" y2="3.2" layer="21"/>
<rectangle x1="0.8251" y1="-3.2" x2="1.1251" y2="-2.2" layer="21"/>
<rectangle x1="0.1751" y1="2.2" x2="0.4751" y2="3.2" layer="21"/>
<rectangle x1="-0.4749" y1="2.2" x2="-0.1749" y2="3.2" layer="21"/>
<rectangle x1="-1.1249" y1="2.2" x2="-0.8249" y2="3.2" layer="21"/>
<rectangle x1="-1.7749" y1="2.2" x2="-1.4749" y2="3.2" layer="21"/>
<rectangle x1="-2.4249" y1="2.2" x2="-2.1249" y2="3.2" layer="21"/>
<rectangle x1="-3.0749" y1="2.2" x2="-2.7749" y2="3.2" layer="21"/>
<rectangle x1="1.4751" y1="2.2" x2="1.7751" y2="3.2" layer="21"/>
<rectangle x1="2.1251" y1="2.2" x2="2.4251" y2="3.2" layer="21"/>
<rectangle x1="2.7751" y1="2.2" x2="3.0751" y2="3.2" layer="21"/>
<rectangle x1="-3.0749" y1="-3.2" x2="-2.7749" y2="-2.2" layer="21"/>
<rectangle x1="-2.4249" y1="-3.2" x2="-2.1249" y2="-2.2" layer="21"/>
<rectangle x1="-1.7749" y1="-3.2" x2="-1.4749" y2="-2.2" layer="21"/>
<rectangle x1="-1.1249" y1="-3.2" x2="-0.8249" y2="-2.2" layer="21"/>
<rectangle x1="-0.4749" y1="-3.2" x2="-0.1749" y2="-2.2" layer="21"/>
<rectangle x1="0.1751" y1="-3.2" x2="0.4751" y2="-2.2" layer="21"/>
<rectangle x1="1.4751" y1="-3.2" x2="1.7751" y2="-2.2" layer="21"/>
<rectangle x1="2.1251" y1="-3.2" x2="2.4251" y2="-2.2" layer="21"/>
<rectangle x1="2.7751" y1="-3.2" x2="3.0751" y2="-2.2" layer="21"/>
</package>
</packages>
<symbols>
<symbol name="74245">
<wire x1="-8.89" y1="15.24" x2="-8.89" y2="-15.24" width="0.254" layer="94"/>
<wire x1="8.89" y1="-15.24" x2="-8.89" y2="-15.24" width="0.254" layer="94"/>
<wire x1="8.89" y1="-15.24" x2="8.89" y2="15.24" width="0.254" layer="94"/>
<wire x1="8.89" y1="15.24" x2="-8.89" y2="15.24" width="0.254" layer="94"/>
<text x="-8.89" y="16.51" size="1.524" layer="95">&gt;NAME</text>
<text x="-8.89" y="-17.78" size="1.524" layer="96">&gt;VALUE</text>
<pin name="A1" x="-13.97" y="5.08" length="middle" swaplevel="1"/>
<pin name="A2" x="-13.97" y="2.54" length="middle" swaplevel="1"/>
<pin name="A3" x="-13.97" y="0" length="middle" swaplevel="1"/>
<pin name="A4" x="-13.97" y="-2.54" length="middle" swaplevel="1"/>
<pin name="A5" x="-13.97" y="-5.08" length="middle" swaplevel="1"/>
<pin name="A6" x="-13.97" y="-7.62" length="middle" swaplevel="1"/>
<pin name="A7" x="-13.97" y="-10.16" length="middle" swaplevel="1"/>
<pin name="A8" x="-13.97" y="-12.7" length="middle" swaplevel="1"/>
<pin name="!OE" x="-13.97" y="12.7" length="middle" direction="in" swaplevel="1"/>
<pin name="DIR" x="-13.97" y="10.16" length="middle" direction="in" swaplevel="1"/>
<pin name="B1" x="13.97" y="5.08" length="middle" swaplevel="1" rot="R180"/>
<pin name="B2" x="13.97" y="2.54" length="middle" swaplevel="1" rot="R180"/>
<pin name="B3" x="13.97" y="0" length="middle" swaplevel="1" rot="R180"/>
<pin name="B4" x="13.97" y="-2.54" length="middle" swaplevel="1" rot="R180"/>
<pin name="B5" x="13.97" y="-5.08" length="middle" swaplevel="1" rot="R180"/>
<pin name="B6" x="13.97" y="-7.62" length="middle" swaplevel="1" rot="R180"/>
<pin name="B7" x="13.97" y="-10.16" length="middle" swaplevel="1" rot="R180"/>
<pin name="B8" x="13.97" y="-12.7" length="middle" swaplevel="1" rot="R180"/>
</symbol>
<symbol name="NAP">
<text x="0.635" y="-6.985" size="1.27" layer="95" rot="R90">GND</text>
<text x="0.635" y="3.81" size="1.27" layer="95" rot="R90">VCC</text>
<text x="-0.635" y="-0.635" size="1.27" layer="95">&gt;NAME</text>
<pin name="VCC" x="0" y="10.16" visible="pad" length="short" direction="pwr" swaplevel="1" rot="R270"/>
<pin name="GND" x="0" y="-10.16" visible="pad" length="short" direction="pwr" swaplevel="1" rot="R90"/>
</symbol>
<symbol name="74-G126">
<wire x1="6.35" y1="-5.08" x2="-6.35" y2="-5.08" width="0.254" layer="94"/>
<wire x1="-3.175" y1="3.81" x2="-0.635" y2="2.54" width="0.1524" layer="94"/>
<wire x1="0.635" y1="-1.27" x2="1.905" y2="-1.905" width="0.1524" layer="94"/>
<wire x1="1.905" y1="-1.905" x2="3.175" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="3.175" y1="-2.54" x2="0.635" y2="-3.81" width="0.1524" layer="94"/>
<wire x1="-6.35" y1="5.08" x2="-6.35" y2="2.54" width="0.254" layer="94"/>
<wire x1="-6.35" y1="2.54" x2="-6.35" y2="-5.08" width="0.254" layer="94"/>
<wire x1="6.35" y1="-5.08" x2="6.35" y2="5.08" width="0.254" layer="94"/>
<wire x1="0.635" y1="-3.81" x2="0.635" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="0.635" y1="-2.54" x2="0.635" y2="-1.27" width="0.1524" layer="94"/>
<wire x1="-6.35" y1="5.08" x2="6.35" y2="5.08" width="0.2032" layer="94"/>
<text x="-6.35" y="6.35" size="1.524" layer="95">&gt;NAME</text>
<text x="-6.35" y="-7.62" size="1.524" layer="96">&gt;VALUE</text>
<pin name="Y" x="11.43" y="-2.54" visible="pad" length="middle" direction="out" swaplevel="1" rot="R180"/>
<pin name="OE" x="-11.43" y="2.54" visible="pad" length="middle" direction="in" swaplevel="1"/>
<pin name="A" x="-11.43" y="-2.54" visible="pad" length="middle" direction="in" swaplevel="1"/>
<wire x1="-0.635" y1="2.54" x2="-3.175" y2="1.27" width="0.1524" layer="94"/>
<wire x1="-3.175" y1="1.27" x2="-3.175" y2="2.54" width="0.1524" layer="94"/>
<wire x1="-3.175" y1="2.54" x2="-3.175" y2="3.81" width="0.1524" layer="94"/>
<wire x1="6.35" y1="-2.54" x2="3.175" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-6.35" y1="-2.54" x2="0.635" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-6.35" y1="2.54" x2="-3.175" y2="2.54" width="0.1524" layer="94"/>
<wire x1="-0.635" y1="2.54" x2="1.905" y2="2.54" width="0.1524" layer="94"/>
<wire x1="1.905" y1="2.54" x2="1.905" y2="-1.905" width="0.1524" layer="94"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="74245" prefix="IC" uservalue="yes">
<gates>
<gate name="A" symbol="74245" x="0" y="0"/>
<gate name="P" symbol="NAP" x="-26.67" y="0" addlevel="request"/>
</gates>
<devices>
<device name="-NS" package="SO20">
<connects>
<connect gate="A" pin="!OE" pad="19"/>
<connect gate="A" pin="A1" pad="2"/>
<connect gate="A" pin="A2" pad="3"/>
<connect gate="A" pin="A3" pad="4"/>
<connect gate="A" pin="A4" pad="5"/>
<connect gate="A" pin="A5" pad="6"/>
<connect gate="A" pin="A6" pad="7"/>
<connect gate="A" pin="A7" pad="8"/>
<connect gate="A" pin="A8" pad="9"/>
<connect gate="A" pin="B1" pad="18"/>
<connect gate="A" pin="B2" pad="17"/>
<connect gate="A" pin="B3" pad="16"/>
<connect gate="A" pin="B4" pad="15"/>
<connect gate="A" pin="B5" pad="14"/>
<connect gate="A" pin="B6" pad="13"/>
<connect gate="A" pin="B7" pad="12"/>
<connect gate="A" pin="B8" pad="11"/>
<connect gate="A" pin="DIR" pad="1"/>
<connect gate="P" pin="GND" pad="10"/>
<connect gate="P" pin="VCC" pad="20"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-PW" package="TSSOP20">
<connects>
<connect gate="A" pin="!OE" pad="19"/>
<connect gate="A" pin="A1" pad="2"/>
<connect gate="A" pin="A2" pad="3"/>
<connect gate="A" pin="A3" pad="4"/>
<connect gate="A" pin="A4" pad="5"/>
<connect gate="A" pin="A5" pad="6"/>
<connect gate="A" pin="A6" pad="7"/>
<connect gate="A" pin="A7" pad="8"/>
<connect gate="A" pin="A8" pad="9"/>
<connect gate="A" pin="B1" pad="18"/>
<connect gate="A" pin="B2" pad="17"/>
<connect gate="A" pin="B3" pad="16"/>
<connect gate="A" pin="B4" pad="15"/>
<connect gate="A" pin="B5" pad="14"/>
<connect gate="A" pin="B6" pad="13"/>
<connect gate="A" pin="B7" pad="12"/>
<connect gate="A" pin="B8" pad="11"/>
<connect gate="A" pin="DIR" pad="1"/>
<connect gate="P" pin="GND" pad="10"/>
<connect gate="P" pin="VCC" pad="20"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="74-1G126" prefix="IC" uservalue="yes">
<gates>
<gate name="A" symbol="74-G126" x="0" y="0"/>
<gate name="P" symbol="NAP" x="-24.13" y="0" addlevel="request"/>
</gates>
<devices>
<device name="DBV" package="SOT23-5">
<connects>
<connect gate="A" pin="A" pad="2"/>
<connect gate="A" pin="OE" pad="1"/>
<connect gate="A" pin="Y" pad="4"/>
<connect gate="P" pin="GND" pad="3"/>
<connect gate="P" pin="VCC" pad="5"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="MEMORY">
<packages>
<package name="PLCC20SKT">
<wire x1="0" y1="2.54" x2="0" y2="1.27" width="0.254" layer="21"/>
<wire x1="0" y1="2.54" x2="0.635" y2="1.905" width="0.254" layer="21"/>
<wire x1="0.635" y1="1.905" x2="-0.635" y2="1.905" width="0.254" layer="21"/>
<wire x1="-0.635" y1="1.905" x2="0" y2="2.54" width="0.254" layer="21"/>
<wire x1="-6.325" y1="-7.825" x2="6.325" y2="-7.825" width="0.2032" layer="51"/>
<wire x1="7.825" y1="6.325" x2="7.825" y2="-6.325" width="0.2032" layer="51"/>
<wire x1="6.325" y1="7.825" x2="-5.825" y2="7.825" width="0.2032" layer="51"/>
<wire x1="-5.825" y1="7.825" x2="-7.825" y2="5.825" width="0.2032" layer="51"/>
<wire x1="-7.825" y1="5.825" x2="-7.825" y2="-6.325" width="0.2032" layer="51"/>
<wire x1="-2.8575" y1="3.81" x2="3.81" y2="3.81" width="0.254" layer="21"/>
<wire x1="3.81" y1="3.81" x2="3.81" y2="2.8575" width="0.254" layer="21"/>
<wire x1="3.81" y1="2.8575" x2="3.81" y2="-3.81" width="0.254" layer="21"/>
<wire x1="3.81" y1="-3.81" x2="-3.81" y2="-3.81" width="0.254" layer="21"/>
<wire x1="-3.81" y1="-3.81" x2="-3.81" y2="2.8575" width="0.254" layer="21"/>
<wire x1="-3.81" y1="2.8575" x2="-2.8575" y2="3.81" width="0.254" layer="21"/>
<wire x1="-3.81" y1="2.8575" x2="3.81" y2="2.8575" width="0.254" layer="21"/>
<smd name="5" x="-4.06" y="1.27" dx="1.91" dy="0.7" layer="1"/>
<smd name="6" x="-4.06" y="0" dx="1.91" dy="0.7" layer="1"/>
<smd name="7" x="-4.06" y="-1.27" dx="1.91" dy="0.7" layer="1"/>
<smd name="8" x="-4.06" y="-2.54" dx="1.91" dy="0.7" layer="1"/>
<smd name="15" x="4.06" y="-1.27" dx="1.91" dy="0.7" layer="1"/>
<smd name="14" x="4.06" y="-2.54" dx="1.91" dy="0.7" layer="1"/>
<smd name="3" x="-2.54" y="4.06" dx="0.7" dy="1.91" layer="1"/>
<smd name="20" x="1.27" y="4.06" dx="0.7" dy="1.91" layer="1"/>
<smd name="19" x="2.54" y="4.06" dx="0.7" dy="1.91" layer="1"/>
<smd name="9" x="-2.54" y="-4.06" dx="0.7" dy="1.91" layer="1"/>
<smd name="12" x="1.27" y="-4.06" dx="0.7" dy="1.91" layer="1"/>
<smd name="13" x="2.54" y="-4.06" dx="0.7" dy="1.91" layer="1"/>
<smd name="16" x="4.06" y="0" dx="1.91" dy="0.7" layer="1"/>
<smd name="17" x="4.06" y="1.27" dx="1.91" dy="0.7" layer="1"/>
<smd name="11" x="0" y="-4.06" dx="0.7" dy="1.91" layer="1"/>
<smd name="10" x="-1.27" y="-4.06" dx="0.7" dy="1.91" layer="1"/>
<smd name="1" x="0" y="4.06" dx="0.7" dy="1.91" layer="1"/>
<smd name="2" x="-1.27" y="4.06" dx="0.7" dy="1.91" layer="1"/>
<smd name="18" x="4.06" y="2.54" dx="1.91" dy="0.7" layer="1"/>
<smd name="4" x="-4.06" y="2.54" dx="1.91" dy="0.7" layer="1"/>
<text x="-2.54" y="-2.54" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="-0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="8.89" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<rectangle x1="3.81" y1="2.2225" x2="4.1275" y2="2.8575" layer="21"/>
<rectangle x1="3.81" y1="0.9525" x2="4.1275" y2="1.5875" layer="21"/>
<rectangle x1="3.81" y1="-0.3175" x2="4.1275" y2="0.3175" layer="21"/>
<rectangle x1="3.81" y1="-1.5875" x2="4.1275" y2="-0.9525" layer="21"/>
<rectangle x1="3.81" y1="-2.8575" x2="4.1275" y2="-2.2225" layer="21"/>
<rectangle x1="-2.8575" y1="3.81" x2="-2.2225" y2="4.1275" layer="21"/>
<rectangle x1="-1.5875" y1="3.81" x2="-0.9525" y2="4.1275" layer="21"/>
<rectangle x1="-0.3175" y1="3.81" x2="0.3175" y2="4.1275" layer="21"/>
<rectangle x1="0.9525" y1="3.81" x2="1.5875" y2="4.1275" layer="21"/>
<rectangle x1="2.2225" y1="3.81" x2="2.8575" y2="4.1275" layer="21"/>
<rectangle x1="-4.1275" y1="-2.8575" x2="-3.81" y2="-2.2225" layer="21"/>
<rectangle x1="-4.1275" y1="-1.5875" x2="-3.81" y2="-0.9525" layer="21"/>
<rectangle x1="-4.1275" y1="-0.3175" x2="-3.81" y2="0.3175" layer="21"/>
<rectangle x1="-4.1275" y1="0.9525" x2="-3.81" y2="1.5875" layer="21"/>
<rectangle x1="-4.1275" y1="2.2225" x2="-3.81" y2="2.8575" layer="21"/>
<rectangle x1="2.2225" y1="-4.1275" x2="2.8575" y2="-3.81" layer="21"/>
<rectangle x1="0.9525" y1="-4.1275" x2="1.5875" y2="-3.81" layer="21"/>
<rectangle x1="-0.3175" y1="-4.1275" x2="0.3175" y2="-3.81" layer="21"/>
<rectangle x1="-1.5875" y1="-4.1275" x2="-0.9525" y2="-3.81" layer="21"/>
<rectangle x1="-2.8575" y1="-4.1275" x2="-2.2225" y2="-3.81" layer="21"/>
<wire x1="6.325" y1="7.825" x2="-5.825" y2="7.825" width="0.254" layer="21"/>
<wire x1="-5.825" y1="7.825" x2="-7.825" y2="5.825" width="0.254" layer="21"/>
<wire x1="-7.825" y1="5.825" x2="-7.825" y2="-6.325" width="0.254" layer="21"/>
<wire x1="7.825" y1="6.325" x2="7.825" y2="-6.325" width="0.254" layer="21"/>
<wire x1="-6.325" y1="-7.825" x2="6.325" y2="-7.825" width="0.254" layer="21"/>
<wire x1="6.325" y1="7.825" x2="7.825" y2="6.325" width="0.254" layer="21" curve="-90"/>
<wire x1="6.325" y1="7.825" x2="7.825" y2="6.325" width="0.2032" layer="51" curve="-90"/>
<wire x1="7.825" y1="-6.325" x2="6.325" y2="-7.825" width="0.2032" layer="51" curve="-90"/>
<wire x1="7.825" y1="-6.325" x2="6.325" y2="-7.825" width="0.254" layer="21" curve="-90"/>
<wire x1="-6.325" y1="-7.825" x2="-7.825" y2="-6.325" width="0.2032" layer="51" curve="-90"/>
<wire x1="-6.325" y1="-7.825" x2="-7.825" y2="-6.325" width="0.254" layer="21" curve="-90"/>
<wire x1="-4.445" y1="3.175" x2="-3.175" y2="4.445" width="0.254" layer="21"/>
<wire x1="-5.588" y1="-6.604" x2="-3.429" y2="-4.445" width="0.254" layer="21"/>
<wire x1="-5.588" y1="-6.604" x2="-6.604" y2="-5.588" width="0.254" layer="21"/>
<wire x1="-6.604" y1="-5.588" x2="-4.445" y2="-3.429" width="0.254" layer="21"/>
<wire x1="-3.429" y1="-4.445" x2="-2.921" y2="-4.445" width="0.254" layer="21"/>
<wire x1="-2.921" y1="-6.604" x2="-2.921" y2="-4.445" width="0.254" layer="21"/>
<wire x1="-2.921" y1="-6.604" x2="-2.159" y2="-6.604" width="0.254" layer="21"/>
<wire x1="-2.159" y1="-4.445" x2="-2.159" y2="-6.604" width="0.254" layer="21"/>
<wire x1="6.604" y1="5.588" x2="4.445" y2="3.429" width="0.254" layer="21"/>
<wire x1="6.604" y1="5.588" x2="5.588" y2="6.604" width="0.254" layer="21"/>
<wire x1="5.588" y1="6.604" x2="3.429" y2="4.445" width="0.254" layer="21"/>
<wire x1="4.445" y1="3.429" x2="4.445" y2="2.921" width="0.254" layer="21"/>
<wire x1="6.604" y1="2.921" x2="4.445" y2="2.921" width="0.254" layer="21"/>
<wire x1="6.604" y1="2.921" x2="6.604" y2="2.159" width="0.254" layer="21"/>
<wire x1="4.445" y1="2.159" x2="6.604" y2="2.159" width="0.254" layer="21"/>
<wire x1="-4.445" y1="-3.429" x2="-4.445" y2="-2.921" width="0.254" layer="21"/>
<wire x1="-6.604" y1="-2.921" x2="-4.445" y2="-2.921" width="0.254" layer="21"/>
<wire x1="-6.604" y1="-2.921" x2="-6.604" y2="-2.159" width="0.254" layer="21"/>
<wire x1="-4.445" y1="-2.159" x2="-6.604" y2="-2.159" width="0.254" layer="21"/>
<wire x1="-4.445" y1="-2.159" x2="-4.445" y2="-1.651" width="0.254" layer="21"/>
<wire x1="-6.604" y1="-1.651" x2="-4.445" y2="-1.651" width="0.254" layer="21"/>
<wire x1="-6.604" y1="-1.651" x2="-6.604" y2="-0.889" width="0.254" layer="21"/>
<wire x1="-4.445" y1="-0.889" x2="-6.604" y2="-0.889" width="0.254" layer="21"/>
<wire x1="-4.445" y1="-0.889" x2="-4.445" y2="-0.381" width="0.254" layer="21"/>
<wire x1="-6.604" y1="-0.381" x2="-4.445" y2="-0.381" width="0.254" layer="21"/>
<wire x1="-6.604" y1="-0.381" x2="-6.604" y2="0.381" width="0.254" layer="21"/>
<wire x1="-4.445" y1="0.381" x2="-6.604" y2="0.381" width="0.254" layer="21"/>
<wire x1="-4.445" y1="0.381" x2="-4.445" y2="0.889" width="0.254" layer="21"/>
<wire x1="-6.604" y1="0.889" x2="-4.445" y2="0.889" width="0.254" layer="21"/>
<wire x1="-6.604" y1="0.889" x2="-6.604" y2="1.651" width="0.254" layer="21"/>
<wire x1="-4.445" y1="1.651" x2="-6.604" y2="1.651" width="0.254" layer="21"/>
<wire x1="-4.445" y1="1.651" x2="-4.445" y2="2.159" width="0.254" layer="21"/>
<wire x1="-6.604" y1="2.159" x2="-4.445" y2="2.159" width="0.254" layer="21"/>
<wire x1="-6.604" y1="2.159" x2="-6.604" y2="2.921" width="0.254" layer="21"/>
<wire x1="3.429" y1="4.445" x2="2.921" y2="4.445" width="0.254" layer="21"/>
<wire x1="2.921" y1="6.604" x2="2.921" y2="4.445" width="0.254" layer="21"/>
<wire x1="2.921" y1="6.604" x2="2.159" y2="6.604" width="0.254" layer="21"/>
<wire x1="2.159" y1="4.445" x2="2.159" y2="6.604" width="0.254" layer="21"/>
<wire x1="2.159" y1="4.445" x2="1.651" y2="4.445" width="0.254" layer="21"/>
<wire x1="1.651" y1="6.604" x2="1.651" y2="4.445" width="0.254" layer="21"/>
<wire x1="1.651" y1="6.604" x2="0.889" y2="6.604" width="0.254" layer="21"/>
<wire x1="0.889" y1="4.445" x2="0.889" y2="6.604" width="0.254" layer="21"/>
<wire x1="0.889" y1="4.445" x2="0.381" y2="4.445" width="0.254" layer="21"/>
<wire x1="0.381" y1="6.604" x2="0.381" y2="4.445" width="0.254" layer="21"/>
<wire x1="0.381" y1="6.604" x2="-0.381" y2="6.604" width="0.254" layer="21"/>
<wire x1="-0.381" y1="4.445" x2="-0.381" y2="6.604" width="0.254" layer="21"/>
<wire x1="-0.381" y1="4.445" x2="-0.889" y2="4.445" width="0.254" layer="21"/>
<wire x1="-0.889" y1="6.604" x2="-0.889" y2="4.445" width="0.254" layer="21"/>
<wire x1="-0.889" y1="6.604" x2="-1.651" y2="6.604" width="0.254" layer="21"/>
<wire x1="-1.651" y1="4.445" x2="-1.651" y2="6.604" width="0.254" layer="21"/>
<wire x1="-1.651" y1="4.445" x2="-2.159" y2="4.445" width="0.254" layer="21"/>
<wire x1="-2.159" y1="6.604" x2="-2.159" y2="4.445" width="0.254" layer="21"/>
<wire x1="-2.159" y1="6.604" x2="-2.921" y2="6.604" width="0.254" layer="21"/>
<wire x1="-2.921" y1="4.445" x2="-2.921" y2="6.604" width="0.254" layer="21"/>
<wire x1="-2.159" y1="-4.445" x2="-1.651" y2="-4.445" width="0.254" layer="21"/>
<wire x1="-1.651" y1="-6.604" x2="-1.651" y2="-4.445" width="0.254" layer="21"/>
<wire x1="-1.651" y1="-6.604" x2="-0.889" y2="-6.604" width="0.254" layer="21"/>
<wire x1="-0.889" y1="-4.445" x2="-0.889" y2="-6.604" width="0.254" layer="21"/>
<wire x1="-0.889" y1="-4.445" x2="-0.381" y2="-4.445" width="0.254" layer="21"/>
<wire x1="-0.381" y1="-6.604" x2="-0.381" y2="-4.445" width="0.254" layer="21"/>
<wire x1="-0.381" y1="-6.604" x2="0.381" y2="-6.604" width="0.254" layer="21"/>
<wire x1="0.381" y1="-4.445" x2="0.381" y2="-6.604" width="0.254" layer="21"/>
<wire x1="0.381" y1="-4.445" x2="0.889" y2="-4.445" width="0.254" layer="21"/>
<wire x1="0.889" y1="-6.604" x2="0.889" y2="-4.445" width="0.254" layer="21"/>
<wire x1="0.889" y1="-6.604" x2="1.651" y2="-6.604" width="0.254" layer="21"/>
<wire x1="1.651" y1="-4.445" x2="1.651" y2="-6.604" width="0.254" layer="21"/>
<wire x1="1.651" y1="-4.445" x2="2.159" y2="-4.445" width="0.254" layer="21"/>
<wire x1="2.159" y1="-6.604" x2="2.159" y2="-4.445" width="0.254" layer="21"/>
<wire x1="2.159" y1="-6.604" x2="2.921" y2="-6.604" width="0.254" layer="21"/>
<wire x1="2.921" y1="-4.445" x2="2.921" y2="-6.604" width="0.254" layer="21"/>
<wire x1="-6.604" y1="2.921" x2="-4.445" y2="2.921" width="0.254" layer="21"/>
<wire x1="6.604" y1="-2.921" x2="4.445" y2="-2.921" width="0.254" layer="21"/>
<wire x1="6.604" y1="-2.921" x2="6.604" y2="-2.159" width="0.254" layer="21"/>
<wire x1="4.445" y1="-2.159" x2="6.604" y2="-2.159" width="0.254" layer="21"/>
<wire x1="4.445" y1="-2.159" x2="4.445" y2="-1.651" width="0.254" layer="21"/>
<wire x1="6.604" y1="-1.651" x2="4.445" y2="-1.651" width="0.254" layer="21"/>
<wire x1="6.604" y1="-1.651" x2="6.604" y2="-0.889" width="0.254" layer="21"/>
<wire x1="4.445" y1="-0.889" x2="6.604" y2="-0.889" width="0.254" layer="21"/>
<wire x1="4.445" y1="-0.889" x2="4.445" y2="-0.381" width="0.254" layer="21"/>
<wire x1="6.604" y1="-0.381" x2="4.445" y2="-0.381" width="0.254" layer="21"/>
<wire x1="6.604" y1="-0.381" x2="6.604" y2="0.381" width="0.254" layer="21"/>
<wire x1="4.445" y1="0.381" x2="6.604" y2="0.381" width="0.254" layer="21"/>
<wire x1="4.445" y1="0.381" x2="4.445" y2="0.889" width="0.254" layer="21"/>
<wire x1="6.604" y1="0.889" x2="4.445" y2="0.889" width="0.254" layer="21"/>
<wire x1="6.604" y1="0.889" x2="6.604" y2="1.651" width="0.254" layer="21"/>
<wire x1="4.445" y1="1.651" x2="6.604" y2="1.651" width="0.254" layer="21"/>
<wire x1="2.921" y1="-4.445" x2="4.445" y2="-4.445" width="0.254" layer="21"/>
<wire x1="4.445" y1="-4.445" x2="4.445" y2="-2.921" width="0.254" layer="21"/>
<wire x1="4.445" y1="2.159" x2="4.445" y2="1.651" width="0.254" layer="21"/>
<wire x1="-3.175" y1="4.445" x2="-2.921" y2="4.445" width="0.254" layer="21"/>
<wire x1="-4.445" y1="2.921" x2="-4.445" y2="3.175" width="0.254" layer="21"/>
</package>
</packages>
<symbols>
<symbol name="ATF16V8C">
<wire x1="-8.89" y1="13.97" x2="8.89" y2="13.97" width="0.254" layer="94"/>
<wire x1="8.89" y1="-13.97" x2="8.89" y2="13.97" width="0.254" layer="94"/>
<wire x1="-8.89" y1="-13.97" x2="8.89" y2="-13.97" width="0.254" layer="94"/>
<wire x1="-8.89" y1="-13.97" x2="-8.89" y2="13.97" width="0.254" layer="94"/>
<text x="-8.89" y="15.24" size="1.524" layer="95">&gt;NAME</text>
<text x="-8.89" y="-16.51" size="1.524" layer="96">&gt;VALUE</text>
<pin name="IN0/CLK" x="-13.97" y="11.43" length="middle" direction="in" swaplevel="1"/>
<pin name="IN1" x="-13.97" y="8.89" length="middle" direction="in" swaplevel="1"/>
<pin name="IN2" x="-13.97" y="6.35" length="middle" direction="in" swaplevel="1"/>
<pin name="IN3/PD" x="-13.97" y="3.81" length="middle" direction="in" swaplevel="1"/>
<pin name="IN4" x="-13.97" y="1.27" length="middle" direction="in" swaplevel="1"/>
<pin name="IN5" x="-13.97" y="-1.27" length="middle" direction="in" swaplevel="1"/>
<pin name="IN6" x="-13.97" y="-3.81" length="middle" direction="in" swaplevel="1"/>
<pin name="IN7" x="-13.97" y="-6.35" length="middle" direction="in" swaplevel="1"/>
<pin name="IN8" x="-13.97" y="-8.89" length="middle" direction="in" swaplevel="1"/>
<pin name="IN9/!OE" x="-13.97" y="-11.43" length="middle" direction="in" swaplevel="1"/>
<pin name="IO0" x="13.97" y="11.43" length="middle" swaplevel="1" rot="R180"/>
<pin name="IO1" x="13.97" y="8.89" length="middle" swaplevel="1" rot="R180"/>
<pin name="IO2" x="13.97" y="6.35" length="middle" swaplevel="1" rot="R180"/>
<pin name="IO3" x="13.97" y="3.81" length="middle" swaplevel="1" rot="R180"/>
<pin name="IO4" x="13.97" y="1.27" length="middle" swaplevel="1" rot="R180"/>
<pin name="IO5" x="13.97" y="-1.27" length="middle" swaplevel="1" rot="R180"/>
<pin name="IO6" x="13.97" y="-3.81" length="middle" swaplevel="1" rot="R180"/>
<pin name="IO7" x="13.97" y="-6.35" length="middle" swaplevel="1" rot="R180"/>
</symbol>
<symbol name="PWR20">
<text x="-0.635" y="-0.635" size="1.27" layer="95">&gt;NAME</text>
<text x="0.635" y="-6.985" size="1.27" layer="95" rot="R90">GND</text>
<text x="0.635" y="3.81" size="1.27" layer="95" rot="R90">VCC</text>
<pin name="GND" x="0" y="-10.16" visible="pad" length="short" direction="pwr" swaplevel="1" rot="R90"/>
<pin name="VCC" x="0" y="10.16" visible="pad" length="short" direction="pwr" swaplevel="1" rot="R270"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="ATF16V8C" prefix="IC" uservalue="yes">
<gates>
<gate name="A" symbol="ATF16V8C" x="0" y="0"/>
<gate name="P" symbol="PWR20" x="-26.67" y="0" addlevel="request"/>
</gates>
<devices>
<device name="" package="PLCC20SKT">
<connects>
<connect gate="A" pin="IN0/CLK" pad="1"/>
<connect gate="A" pin="IN1" pad="2"/>
<connect gate="A" pin="IN2" pad="3"/>
<connect gate="A" pin="IN3/PD" pad="4"/>
<connect gate="A" pin="IN4" pad="5"/>
<connect gate="A" pin="IN5" pad="6"/>
<connect gate="A" pin="IN6" pad="7"/>
<connect gate="A" pin="IN7" pad="8"/>
<connect gate="A" pin="IN8" pad="9"/>
<connect gate="A" pin="IN9/!OE" pad="11"/>
<connect gate="A" pin="IO0" pad="12"/>
<connect gate="A" pin="IO1" pad="13"/>
<connect gate="A" pin="IO2" pad="14"/>
<connect gate="A" pin="IO3" pad="15"/>
<connect gate="A" pin="IO4" pad="16"/>
<connect gate="A" pin="IO5" pad="17"/>
<connect gate="A" pin="IO6" pad="18"/>
<connect gate="A" pin="IO7" pad="19"/>
<connect gate="P" pin="GND" pad="10"/>
<connect gate="P" pin="VCC" pad="20"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="PASIV">
<packages>
<package name="CK-0603">
<wire x1="-1.4732" y1="-0.7112" x2="1.4732" y2="-0.7112" width="0.2032" layer="51"/>
<wire x1="-1.4732" y1="-0.7112" x2="-1.4732" y2="0.7112" width="0.2032" layer="51"/>
<wire x1="-1.4732" y1="0.7112" x2="1.4732" y2="0.7112" width="0.2032" layer="51"/>
<wire x1="1.4732" y1="-0.7112" x2="1.4732" y2="0.7112" width="0.2032" layer="51"/>
<wire x1="-0.635" y1="0.254" x2="-0.381" y2="0.254" width="0.254" layer="21"/>
<wire x1="-0.381" y1="0.254" x2="0.381" y2="0.254" width="0.254" layer="21"/>
<wire x1="0.381" y1="0.254" x2="0.635" y2="0.254" width="0.254" layer="21"/>
<wire x1="0.635" y1="0.254" x2="0.635" y2="-0.254" width="0.254" layer="21"/>
<wire x1="0.635" y1="-0.254" x2="0.381" y2="-0.254" width="0.254" layer="21"/>
<wire x1="0.381" y1="-0.254" x2="-0.381" y2="-0.254" width="0.254" layer="21"/>
<wire x1="-0.381" y1="-0.254" x2="-0.635" y2="-0.254" width="0.254" layer="21"/>
<wire x1="-0.635" y1="-0.254" x2="-0.635" y2="0.254" width="0.254" layer="21"/>
<wire x1="-0.381" y1="-0.254" x2="-0.381" y2="0.254" width="0.254" layer="21"/>
<wire x1="0.381" y1="0.254" x2="0.381" y2="-0.254" width="0.254" layer="21"/>
<smd name="2" x="0.762" y="0" dx="0.7874" dy="0.7874" layer="1"/>
<smd name="1" x="-0.762" y="0" dx="0.7874" dy="0.7874" layer="1"/>
<text x="-1.27" y="0.9525" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.905" y="1.524" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="CK-0805">
<wire x1="-1.7018" y1="-0.9525" x2="1.7018" y2="-0.9525" width="0.2032" layer="51"/>
<wire x1="-1.7018" y1="-0.9525" x2="-1.7018" y2="0.9525" width="0.2032" layer="51"/>
<wire x1="-1.7018" y1="0.9525" x2="1.7018" y2="0.9525" width="0.2032" layer="51"/>
<wire x1="1.7018" y1="-0.9525" x2="1.7018" y2="0.9525" width="0.2032" layer="51"/>
<wire x1="-0.8636" y1="0.508" x2="-0.6096" y2="0.508" width="0.254" layer="21"/>
<wire x1="-0.6096" y1="0.508" x2="0.6096" y2="0.508" width="0.254" layer="21"/>
<wire x1="0.6096" y1="0.508" x2="0.8636" y2="0.508" width="0.254" layer="21"/>
<wire x1="0.8636" y1="0.508" x2="0.8636" y2="-0.508" width="0.254" layer="21"/>
<wire x1="0.8636" y1="-0.508" x2="0.6096" y2="-0.508" width="0.254" layer="21"/>
<wire x1="0.6096" y1="-0.508" x2="-0.6096" y2="-0.508" width="0.254" layer="21"/>
<wire x1="-0.6096" y1="-0.508" x2="-0.8636" y2="-0.508" width="0.254" layer="21"/>
<wire x1="-0.8636" y1="-0.508" x2="-0.8636" y2="0.508" width="0.254" layer="21"/>
<wire x1="-0.6096" y1="-0.508" x2="-0.6096" y2="0.508" width="0.254" layer="21"/>
<wire x1="0.6096" y1="0.508" x2="0.6096" y2="-0.508" width="0.254" layer="21"/>
<smd name="2" x="0.9525" y="0" dx="0.889" dy="1.2954" layer="1"/>
<smd name="1" x="-0.9525" y="0" dx="0.889" dy="1.2954" layer="1"/>
<text x="-1.27" y="0.9525" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.905" y="1.524" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="CK-1206">
<wire x1="-1.4541" y1="-0.675" x2="-1.2541" y2="-0.675" width="0.254" layer="21"/>
<wire x1="-1.2541" y1="-0.675" x2="-1.0541" y2="-0.675" width="0.254" layer="21"/>
<wire x1="-1.0541" y1="-0.675" x2="1.0541" y2="-0.675" width="0.254" layer="21"/>
<wire x1="1.0541" y1="-0.675" x2="1.2541" y2="-0.675" width="0.254" layer="21"/>
<wire x1="1.2541" y1="-0.675" x2="1.4541" y2="-0.675" width="0.254" layer="21"/>
<wire x1="-1.4541" y1="-0.675" x2="-1.4541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.4541" y1="0.675" x2="-1.2541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.2541" y1="0.675" x2="-1.0541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.0541" y1="0.675" x2="1.2541" y2="0.675" width="0.254" layer="21"/>
<wire x1="1.2541" y1="0.675" x2="1.4541" y2="0.675" width="0.254" layer="21"/>
<wire x1="1.4541" y1="-0.675" x2="1.4541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.2541" y1="-0.675" x2="-1.2541" y2="0.675" width="0.254" layer="21"/>
<wire x1="1.2541" y1="-0.675" x2="1.2541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.0541" y1="-0.675" x2="-1.0541" y2="0.675" width="0.254" layer="21"/>
<wire x1="1.0541" y1="-0.675" x2="1.0541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-2.1844" y1="-1.1303" x2="2.1844" y2="-1.1303" width="0.2032" layer="51"/>
<wire x1="-2.1844" y1="-1.1303" x2="-2.1844" y2="1.1303" width="0.2032" layer="51"/>
<wire x1="-2.1844" y1="1.1303" x2="2.1844" y2="1.1303" width="0.2032" layer="51"/>
<wire x1="2.1844" y1="-1.1303" x2="2.1844" y2="1.1303" width="0.2032" layer="51"/>
<smd name="1" x="-1.4224" y="0" dx="0.9144" dy="1.651" layer="1"/>
<smd name="2" x="1.4224" y="0" dx="0.9144" dy="1.651" layer="1"/>
<text x="-1.4287" y="0.9525" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.4287" y="-1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.0637" y="1.524" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="CK-1210">
<wire x1="-1.5113" y1="-1.1068" x2="-1.3113" y2="-1.1068" width="0.254" layer="21"/>
<wire x1="-1.3113" y1="-1.1068" x2="-1.1113" y2="-1.1068" width="0.254" layer="21"/>
<wire x1="-1.1113" y1="-1.1068" x2="1.1112" y2="-1.1068" width="0.254" layer="21"/>
<wire x1="1.1112" y1="-1.1068" x2="1.3112" y2="-1.1068" width="0.254" layer="21"/>
<wire x1="1.3112" y1="-1.1068" x2="1.5112" y2="-1.1068" width="0.254" layer="21"/>
<wire x1="-1.5113" y1="-1.1068" x2="-1.5113" y2="1.1068" width="0.254" layer="21"/>
<wire x1="-1.5113" y1="1.1068" x2="-1.3113" y2="1.1068" width="0.254" layer="21"/>
<wire x1="-1.3113" y1="1.1068" x2="-1.1113" y2="1.1068" width="0.254" layer="21"/>
<wire x1="-1.1113" y1="1.1068" x2="1.3112" y2="1.1068" width="0.254" layer="21"/>
<wire x1="1.3112" y1="1.1068" x2="1.5112" y2="1.1068" width="0.254" layer="21"/>
<wire x1="1.5112" y1="-1.1068" x2="1.5112" y2="1.1068" width="0.254" layer="21"/>
<wire x1="-1.3113" y1="-1.1068" x2="-1.3113" y2="1.1068" width="0.254" layer="21"/>
<wire x1="1.3112" y1="-1.1068" x2="1.3112" y2="1.1068" width="0.254" layer="21"/>
<wire x1="-1.1113" y1="-1.1068" x2="-1.1113" y2="1.1068" width="0.254" layer="21"/>
<wire x1="1.1112" y1="-1.1068" x2="1.1112" y2="1.1068" width="0.254" layer="21"/>
<wire x1="-2.3495" y1="-1.5748" x2="2.3495" y2="-1.5748" width="0.2032" layer="51"/>
<wire x1="-2.3495" y1="-1.5748" x2="-2.3495" y2="1.5748" width="0.2032" layer="51"/>
<wire x1="-2.3495" y1="1.5748" x2="2.3495" y2="1.5748" width="0.2032" layer="51"/>
<wire x1="2.3495" y1="-1.5748" x2="2.3495" y2="1.5748" width="0.2032" layer="51"/>
<smd name="1" x="-1.5875" y="0" dx="0.9144" dy="2.54" layer="1"/>
<smd name="2" x="1.5875" y="0" dx="0.9144" dy="2.54" layer="1"/>
<text x="-1.5875" y="1.3589" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.5875" y="-2.3114" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.2225" y="1.9304" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="CT-SMD-A">
<wire x1="-2.3241" y1="-0.9525" x2="2.3241" y2="-0.9525" width="0.2032" layer="51"/>
<wire x1="-2.3241" y1="-0.9525" x2="-2.3241" y2="0.9525" width="0.2032" layer="51"/>
<wire x1="-2.3241" y1="0.9525" x2="2.3241" y2="0.9525" width="0.2032" layer="51"/>
<wire x1="2.3241" y1="-0.9525" x2="2.3241" y2="0.9525" width="0.2032" layer="51"/>
<wire x1="-1.6002" y1="-0.7874" x2="-1.3462" y2="-0.7874" width="0.254" layer="21"/>
<wire x1="-1.3462" y1="-0.7874" x2="-1.0922" y2="-0.7874" width="0.254" layer="21"/>
<wire x1="-1.0922" y1="-0.7874" x2="-0.8382" y2="-0.7874" width="0.254" layer="21"/>
<wire x1="-0.8382" y1="-0.7874" x2="-0.5842" y2="-0.7874" width="0.254" layer="21"/>
<wire x1="-0.5842" y1="-0.7874" x2="1.6002" y2="-0.7874" width="0.254" layer="21"/>
<wire x1="-1.6002" y1="-0.7874" x2="-1.6002" y2="0.7874" width="0.254" layer="21"/>
<wire x1="-1.6002" y1="0.7874" x2="-1.3462" y2="0.7874" width="0.254" layer="21"/>
<wire x1="-1.3462" y1="0.7874" x2="-1.0922" y2="0.7874" width="0.254" layer="21"/>
<wire x1="-1.0922" y1="0.7874" x2="-0.8382" y2="0.7874" width="0.254" layer="21"/>
<wire x1="-0.8382" y1="0.7874" x2="1.6002" y2="0.7874" width="0.254" layer="21"/>
<wire x1="1.6002" y1="-0.7874" x2="1.6002" y2="0.7874" width="0.254" layer="21"/>
<wire x1="-2.6289" y1="-0.9525" x2="-2.6289" y2="0.9525" width="0.2032" layer="51"/>
<wire x1="-1.3462" y1="-0.7874" x2="-1.3462" y2="0.7874" width="0.254" layer="21"/>
<wire x1="-1.0922" y1="-0.7874" x2="-1.0922" y2="0.7874" width="0.254" layer="21"/>
<wire x1="-0.8382" y1="-0.7874" x2="-0.8382" y2="0.7874" width="0.254" layer="21"/>
<wire x1="-0.5842" y1="-0.7874" x2="-0.5842" y2="0.6858" width="0.254" layer="21"/>
<smd name="A" x="-1.4224" y="0" dx="1.1938" dy="1.2954" layer="1"/>
<smd name="K" x="1.4224" y="0" dx="1.1938" dy="1.2954" layer="1"/>
<text x="-2.3813" y="0.9525" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.3813" y="-1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.3813" y="1.27" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="CT-SMD-B">
<wire x1="-2.5146" y1="-1.4986" x2="2.5146" y2="-1.4986" width="0.2032" layer="51"/>
<wire x1="-2.5146" y1="-1.4986" x2="-2.5146" y2="1.4986" width="0.2032" layer="51"/>
<wire x1="-2.5146" y1="1.4986" x2="2.5146" y2="1.4986" width="0.2032" layer="51"/>
<wire x1="2.5146" y1="-1.4986" x2="2.5146" y2="1.4986" width="0.2032" layer="51"/>
<wire x1="-1.7526" y1="-1.397" x2="-1.4986" y2="-1.397" width="0.254" layer="21"/>
<wire x1="-1.4986" y1="-1.397" x2="-1.2446" y2="-1.397" width="0.254" layer="21"/>
<wire x1="-1.2446" y1="-1.397" x2="-0.9906" y2="-1.397" width="0.254" layer="21"/>
<wire x1="-0.9906" y1="-1.397" x2="-0.7366" y2="-1.397" width="0.254" layer="21"/>
<wire x1="-0.7366" y1="-1.397" x2="1.7526" y2="-1.397" width="0.254" layer="21"/>
<wire x1="-1.7526" y1="-1.397" x2="-1.7526" y2="1.397" width="0.254" layer="21"/>
<wire x1="-1.7526" y1="1.397" x2="-1.4986" y2="1.397" width="0.254" layer="21"/>
<wire x1="-1.4986" y1="1.397" x2="-1.2446" y2="1.397" width="0.254" layer="21"/>
<wire x1="-1.2446" y1="1.397" x2="-0.9906" y2="1.397" width="0.254" layer="21"/>
<wire x1="-0.9906" y1="1.397" x2="1.7526" y2="1.397" width="0.254" layer="21"/>
<wire x1="1.7526" y1="-1.397" x2="1.7526" y2="1.397" width="0.254" layer="21"/>
<wire x1="-2.8194" y1="-1.4605" x2="-2.8194" y2="1.4605" width="0.2032" layer="51"/>
<wire x1="-1.4986" y1="-1.397" x2="-1.4986" y2="1.397" width="0.254" layer="21"/>
<wire x1="-1.2446" y1="-1.397" x2="-1.2446" y2="1.397" width="0.254" layer="21"/>
<wire x1="-0.9906" y1="-1.397" x2="-0.9906" y2="1.397" width="0.254" layer="21"/>
<wire x1="-0.7366" y1="-1.397" x2="-0.7366" y2="1.27" width="0.254" layer="21"/>
<smd name="A" x="-1.5875" y="0" dx="1.2446" dy="2.3114" layer="1"/>
<smd name="K" x="1.5875" y="0" dx="1.2446" dy="2.3114" layer="1"/>
<text x="-2.54" y="1.5875" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-2.54" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="1.905" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="CT-SMD-C">
<wire x1="-3.7211" y1="-1.7018" x2="3.7211" y2="-1.7018" width="0.2032" layer="51"/>
<wire x1="-3.7211" y1="-1.7018" x2="-3.7211" y2="1.7018" width="0.2032" layer="51"/>
<wire x1="-3.7211" y1="1.7018" x2="3.7211" y2="1.7018" width="0.2032" layer="51"/>
<wire x1="3.7211" y1="-1.7018" x2="3.7211" y2="1.7018" width="0.2032" layer="51"/>
<wire x1="-2.9972" y1="-1.6002" x2="-2.7432" y2="-1.6002" width="0.254" layer="21"/>
<wire x1="-2.7432" y1="-1.6002" x2="-2.4892" y2="-1.6002" width="0.254" layer="21"/>
<wire x1="-2.4892" y1="-1.6002" x2="-2.2352" y2="-1.6002" width="0.254" layer="21"/>
<wire x1="-2.2352" y1="-1.6002" x2="-1.9812" y2="-1.6002" width="0.254" layer="21"/>
<wire x1="-1.9812" y1="-1.6002" x2="2.9972" y2="-1.6002" width="0.254" layer="21"/>
<wire x1="-2.9972" y1="-1.6002" x2="-2.9972" y2="1.6002" width="0.254" layer="21"/>
<wire x1="-2.9972" y1="1.6002" x2="-2.7432" y2="1.6002" width="0.254" layer="21"/>
<wire x1="-2.7432" y1="1.6002" x2="-2.4892" y2="1.6002" width="0.254" layer="21"/>
<wire x1="-2.4892" y1="1.6002" x2="-2.2352" y2="1.6002" width="0.254" layer="21"/>
<wire x1="-2.2352" y1="1.6002" x2="2.9972" y2="1.6002" width="0.254" layer="21"/>
<wire x1="2.9972" y1="-1.6002" x2="2.9972" y2="1.6002" width="0.254" layer="21"/>
<wire x1="-4.0259" y1="-1.6002" x2="-4.0259" y2="1.6002" width="0.2032" layer="51"/>
<wire x1="-2.7432" y1="-1.6002" x2="-2.7432" y2="1.6002" width="0.254" layer="21"/>
<wire x1="-2.4892" y1="-1.6002" x2="-2.4892" y2="1.6002" width="0.254" layer="21"/>
<wire x1="-2.2352" y1="-1.6002" x2="-2.2352" y2="1.6002" width="0.254" layer="21"/>
<wire x1="-1.9812" y1="-1.6002" x2="-1.9812" y2="1.4732" width="0.254" layer="21"/>
<smd name="A" x="-2.54" y="0" dx="1.7526" dy="2.3114" layer="1"/>
<smd name="K" x="2.54" y="0" dx="1.7526" dy="2.3114" layer="1"/>
<text x="-2.8575" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.8575" y="-2.8575" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.8575" y="1.905" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="CT-SMD-D">
<wire x1="-4.3815" y1="-2.2606" x2="4.3815" y2="-2.2606" width="0.2032" layer="51"/>
<wire x1="-4.3815" y1="-2.2606" x2="-4.3815" y2="2.2606" width="0.2032" layer="51"/>
<wire x1="-4.3815" y1="2.2606" x2="4.3815" y2="2.2606" width="0.2032" layer="51"/>
<wire x1="4.3815" y1="-2.2606" x2="4.3815" y2="2.2606" width="0.2032" layer="51"/>
<wire x1="-3.6576" y1="-2.159" x2="-3.4036" y2="-2.159" width="0.254" layer="21"/>
<wire x1="-3.4036" y1="-2.159" x2="-3.1496" y2="-2.159" width="0.254" layer="21"/>
<wire x1="-3.1496" y1="-2.159" x2="-2.8956" y2="-2.159" width="0.254" layer="21"/>
<wire x1="-2.8956" y1="-2.159" x2="-2.6416" y2="-2.159" width="0.254" layer="21"/>
<wire x1="-2.6416" y1="-2.159" x2="3.6576" y2="-2.159" width="0.254" layer="21"/>
<wire x1="-3.6576" y1="-2.159" x2="-3.6576" y2="2.159" width="0.254" layer="21"/>
<wire x1="-3.6576" y1="2.159" x2="-3.4036" y2="2.159" width="0.254" layer="21"/>
<wire x1="-3.4036" y1="2.159" x2="-3.1496" y2="2.159" width="0.254" layer="21"/>
<wire x1="-3.1496" y1="2.159" x2="-2.8956" y2="2.159" width="0.254" layer="21"/>
<wire x1="-2.8956" y1="2.159" x2="3.6576" y2="2.159" width="0.254" layer="21"/>
<wire x1="3.6576" y1="-2.159" x2="3.6576" y2="2.159" width="0.254" layer="21"/>
<wire x1="-4.6863" y1="-2.2606" x2="-4.6863" y2="2.2606" width="0.2032" layer="51"/>
<wire x1="-3.4036" y1="-2.159" x2="-3.4036" y2="2.159" width="0.254" layer="21"/>
<wire x1="-3.1496" y1="-2.159" x2="-3.1496" y2="2.159" width="0.254" layer="21"/>
<wire x1="-2.8956" y1="-2.159" x2="-2.8956" y2="2.159" width="0.254" layer="21"/>
<wire x1="-2.6416" y1="-2.159" x2="-2.6416" y2="2.032" width="0.254" layer="21"/>
<smd name="A" x="-3.175" y="0" dx="1.8034" dy="2.5146" layer="1"/>
<smd name="K" x="3.175" y="0" dx="1.8034" dy="2.5146" layer="1"/>
<text x="-3.4925" y="2.54" size="1.27" layer="25">&gt;NAME</text>
<text x="-3.4925" y="-3.4925" size="1.016" layer="27">&gt;VALUE</text>
<text x="-3.4925" y="2.54" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
</packages>
<symbols>
<symbol name="KOND">
<wire x1="-2.54" y1="0" x2="-0.762" y2="0" width="0.1524" layer="94"/>
<wire x1="0.762" y1="0" x2="2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="-0.762" y1="-2.54" x2="-0.762" y2="0" width="0.508" layer="94"/>
<wire x1="0.762" y1="-2.54" x2="0.762" y2="0" width="0.508" layer="94"/>
<wire x1="0.762" y1="0" x2="0.762" y2="2.54" width="0.508" layer="94"/>
<wire x1="-0.762" y1="0" x2="-0.762" y2="2.54" width="0.508" layer="94"/>
<text x="-2.54" y="3.556" size="1.524" layer="95">&gt;NAME</text>
<text x="-2.54" y="-5.08" size="1.524" layer="96">&gt;VALUE</text>
<pin name="1" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
<pin name="2" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
<symbol name="EL">
<wire x1="-2.54" y1="0" x2="-0.762" y2="0" width="0.1524" layer="94"/>
<wire x1="0.762" y1="0" x2="2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="-0.762" y1="-2.54" x2="-0.762" y2="0" width="0.508" layer="94"/>
<wire x1="0.762" y1="-2.54" x2="0.762" y2="0" width="0.508" layer="94"/>
<wire x1="-2.032" y1="1.27" x2="-2.032" y2="2.54" width="0.254" layer="94"/>
<wire x1="-2.667" y1="1.905" x2="-1.397" y2="1.905" width="0.254" layer="94"/>
<wire x1="0.762" y1="0" x2="0.762" y2="2.54" width="0.508" layer="94"/>
<wire x1="-0.762" y1="0" x2="-0.762" y2="2.54" width="0.508" layer="94"/>
<text x="-2.54" y="3.556" size="1.524" layer="95">&gt;NAME</text>
<text x="-2.54" y="-5.08" size="1.524" layer="96">&gt;VALUE</text>
<pin name="A" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
<pin name="K" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="CK-SMD" prefix="C" uservalue="yes">
<description>SMD keramické vícevrstvé kondenzátory</description>
<gates>
<gate name="A" symbol="KOND" x="0" y="0"/>
</gates>
<devices>
<device name="-0603" package="CK-0603">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-0805" package="CK-0805">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-1206" package="CK-1206">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-1210" package="CK-1210">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="CT-SMD" prefix="C" uservalue="yes">
<description>SMD tantalové kondenzátory</description>
<gates>
<gate name="A" symbol="EL" x="0" y="0"/>
</gates>
<devices>
<device name="-A" package="CT-SMD-A">
<connects>
<connect gate="A" pin="A" pad="A"/>
<connect gate="A" pin="K" pad="K"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-B" package="CT-SMD-B">
<connects>
<connect gate="A" pin="A" pad="A"/>
<connect gate="A" pin="K" pad="K"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-C" package="CT-SMD-C">
<connects>
<connect gate="A" pin="A" pad="A"/>
<connect gate="A" pin="K" pad="K"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-D" package="CT-SMD-D">
<connects>
<connect gate="A" pin="A" pad="A"/>
<connect gate="A" pin="K" pad="K"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="KONSTR">
<packages>
<package name="JMP3-1">
<wire x1="-0.635" y1="0.635" x2="-0.635" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-0.635" y1="-0.635" x2="0.635" y2="-0.635" width="0.254" layer="21"/>
<wire x1="0.635" y1="-0.635" x2="0.635" y2="0.635" width="0.254" layer="21"/>
<wire x1="0.635" y1="0.635" x2="-0.635" y2="0.635" width="0.254" layer="21"/>
<wire x1="1.905" y1="0.635" x2="1.905" y2="-0.635" width="0.254" layer="21"/>
<wire x1="3.175" y1="-0.635" x2="1.905" y2="-0.635" width="0.254" layer="21"/>
<wire x1="3.175" y1="-0.635" x2="3.175" y2="0.635" width="0.254" layer="21"/>
<wire x1="1.905" y1="0.635" x2="3.175" y2="0.635" width="0.254" layer="21"/>
<wire x1="4.445" y1="0.635" x2="4.445" y2="-0.635" width="0.254" layer="21"/>
<wire x1="5.715" y1="-0.635" x2="4.445" y2="-0.635" width="0.254" layer="21"/>
<wire x1="5.715" y1="-0.635" x2="5.715" y2="0.635" width="0.254" layer="21"/>
<wire x1="4.445" y1="0.635" x2="5.715" y2="0.635" width="0.254" layer="21"/>
<pad name="1" x="0" y="0" drill="1" diameter="1.6764"/>
<pad name="2" x="2.54" y="0" drill="1" diameter="1.6764"/>
<pad name="3" x="5.08" y="0" drill="1" diameter="1.6764"/>
<text x="6.985" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="6.985" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="6.985" y="-0.635" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-1.27" y1="-1.27" x2="6.35" y2="-1.27" width="0.254" layer="21"/>
<wire x1="6.35" y1="-1.27" x2="6.35" y2="1.27" width="0.254" layer="21"/>
<wire x1="6.35" y1="1.27" x2="-1.27" y2="1.27" width="0.254" layer="21"/>
<wire x1="-1.27" y1="1.27" x2="6.35" y2="1.27" width="0.2032" layer="51"/>
<wire x1="6.35" y1="1.27" x2="6.35" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="6.35" y1="-1.27" x2="-1.27" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="-1.27" x2="-1.27" y2="1.27" width="0.2032" layer="51"/>
<wire x1="-1.66" y1="-1.27" x2="-1.66" y2="1.27" width="0.2032" layer="51"/>
<wire x1="-1.66" y1="1.27" x2="-1.66" y2="-1.27" width="0.254" layer="21"/>
</package>
</packages>
<symbols>
<symbol name="JMP1-3">
<wire x1="0.762" y1="1.778" x2="-0.762" y2="1.778" width="0.254" layer="94"/>
<wire x1="-0.762" y1="1.778" x2="-0.762" y2="3.302" width="0.254" layer="94"/>
<wire x1="-0.762" y1="3.302" x2="0.762" y2="3.302" width="0.254" layer="94"/>
<wire x1="0.762" y1="1.778" x2="0.762" y2="3.302" width="0.254" layer="94"/>
<text x="-3.175" y="4.445" size="1.524" layer="95">&gt;NAME</text>
<pin name="1" x="2.54" y="2.54" visible="pin" length="short" direction="pas" swaplevel="1" rot="R180"/>
<wire x1="0.762" y1="-0.762" x2="-0.762" y2="-0.762" width="0.254" layer="94"/>
<wire x1="-0.762" y1="-0.762" x2="-0.762" y2="0.762" width="0.254" layer="94"/>
<wire x1="-0.762" y1="0.762" x2="0.762" y2="0.762" width="0.254" layer="94"/>
<wire x1="0.762" y1="-0.762" x2="0.762" y2="0.762" width="0.254" layer="94"/>
<pin name="2" x="2.54" y="0" visible="pin" length="short" direction="pas" swaplevel="1" rot="R180"/>
<wire x1="0.762" y1="-3.302" x2="-0.762" y2="-3.302" width="0.254" layer="94"/>
<wire x1="-0.762" y1="-3.302" x2="-0.762" y2="-1.778" width="0.254" layer="94"/>
<wire x1="-0.762" y1="-1.778" x2="0.762" y2="-1.778" width="0.254" layer="94"/>
<wire x1="0.762" y1="-3.302" x2="0.762" y2="-1.778" width="0.254" layer="94"/>
<pin name="3" x="2.54" y="-2.54" visible="pin" length="short" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="JMP1-3" prefix="JP" uservalue="yes">
<gates>
<gate name="A" symbol="JMP1-3" x="0" y="0"/>
</gates>
<devices>
<device name="" package="JMP3-1">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="SYMBOLY">
<packages>
</packages>
<symbols>
<symbol name="VCC">
<text x="-4.699" y="-0.635" size="1.524" layer="94">VCC</text>
<pin name="VCC" x="2.54" y="0" visible="off" length="short" direction="sup" rot="R180"/>
</symbol>
<symbol name="GND">
<wire x1="-2.54" y1="0" x2="2.54" y2="0" width="0.6096" layer="94"/>
<pin name="GND" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="VCC">
<gates>
<gate name="VCC" symbol="VCC" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="GND">
<gates>
<gate name="GND" symbol="GND" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
</libraries>
<attributes>
</attributes>
<variantdefs>
</variantdefs>
<classes>
<class number="0" name="default" width="0" drill="0">
</class>
</classes>
<parts>
<part name="J1" library="CONNEC" deviceset="20-Z2R24T" device="" value="2x12"/>
<part name="J2" library="CONNEC" deviceset="20-Z2R26T" device="" value="2x13"/>
<part name="SIMM1" library="CONNEC" deviceset="SIMM72" device=""/>
<part name="IC1" library="IC" deviceset="74245" device="-PW" value="SN74ACT245PW"/>
<part name="IC3" library="MEMORY" deviceset="ATF16V8C" device="" value="ATF16V8C-7JU"/>
<part name="C1" library="PASIV" deviceset="CK-SMD" device="-0805" value="100n"/>
<part name="C2" library="PASIV" deviceset="CK-SMD" device="-0805" value="100n"/>
<part name="C3" library="PASIV" deviceset="CK-SMD" device="-0805" value="100n"/>
<part name="JP1" library="KONSTR" deviceset="JMP1-3" device=""/>
<part name="JP2" library="KONSTR" deviceset="JMP1-3" device=""/>
<part name="U$1" library="SYMBOLY" deviceset="VCC" device=""/>
<part name="U$2" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$3" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$4" library="SYMBOLY" deviceset="VCC" device=""/>
<part name="U$5" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$6" library="SYMBOLY" deviceset="VCC" device=""/>
<part name="U$7" library="SYMBOLY" deviceset="VCC" device=""/>
<part name="U$8" library="SYMBOLY" deviceset="VCC" device=""/>
<part name="U$9" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$10" library="SYMBOLY" deviceset="VCC" device=""/>
<part name="U$11" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$12" library="SYMBOLY" deviceset="VCC" device=""/>
<part name="IC4" library="IC" deviceset="74-1G126" device="DBV" value="SN74LVC1G126DBV"/>
<part name="C4" library="PASIV" deviceset="CK-SMD" device="-0805" value="100n"/>
<part name="U$13" library="SYMBOLY" deviceset="VCC" device=""/>
<part name="U$14" library="SYMBOLY" deviceset="VCC" device=""/>
<part name="U$15" library="SYMBOLY" deviceset="VCC" device=""/>
<part name="U$16" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$17" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$18" library="SYMBOLY" deviceset="VCC" device=""/>
<part name="U$19" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$20" library="SYMBOLY" deviceset="VCC" device=""/>
<part name="U$21" library="SYMBOLY" deviceset="GND" device=""/>
<part name="IC2" library="IC" deviceset="74245" device="-PW" value="SN74ACT245PW"/>
<part name="C5" library="PASIV" deviceset="CT-SMD" device="-B" value="6u8/10V"/>
<part name="U$22" library="SYMBOLY" deviceset="GND" device=""/>
</parts>
<sheets>
<sheet>
<plain>
</plain>
<instances>
<instance part="J1" gate="A" x="-7.62" y="68.58" rot="MR0"/>
<instance part="J2" gate="A" x="-7.62" y="-5.08" rot="MR0"/>
<instance part="SIMM1" gate="A" x="189.23" y="17.78"/>
<instance part="IC1" gate="A" x="106.68" y="50.8"/>
<instance part="IC3" gate="A" x="106.68" y="11.43"/>
<instance part="IC1" gate="P" x="166.37" y="-55.88"/>
<instance part="IC3" gate="P" x="199.39" y="-55.88"/>
<instance part="C1" gate="A" x="175.26" y="-55.88" smashed="yes" rot="R90">
<attribute name="NAME" x="171.45" y="-53.594" size="1.524" layer="95"/>
<attribute name="VALUE" x="170.18" y="-59.69" size="1.524" layer="96"/>
</instance>
<instance part="C2" gate="A" x="191.77" y="-55.88" smashed="yes" rot="R90">
<attribute name="NAME" x="187.96" y="-53.594" size="1.524" layer="95"/>
<attribute name="VALUE" x="186.69" y="-59.69" size="1.524" layer="96"/>
</instance>
<instance part="C3" gate="A" x="208.28" y="-55.88" smashed="yes" rot="R90">
<attribute name="NAME" x="204.47" y="-53.594" size="1.524" layer="95"/>
<attribute name="VALUE" x="203.2" y="-59.69" size="1.524" layer="96"/>
</instance>
<instance part="JP1" gate="A" x="49.53" y="-22.86" smashed="yes" rot="MR180">
<attribute name="NAME" x="47.625" y="-17.145" size="1.524" layer="95"/>
</instance>
<instance part="JP2" gate="A" x="49.53" y="-55.88" smashed="yes" rot="MR180">
<attribute name="NAME" x="47.625" y="-50.165" size="1.524" layer="95"/>
</instance>
<instance part="U$1" gate="VCC" x="55.88" y="-15.24" rot="R270"/>
<instance part="U$2" gate="GND" x="55.88" y="-63.5"/>
<instance part="U$3" gate="GND" x="55.88" y="-30.48"/>
<instance part="U$4" gate="VCC" x="55.88" y="-48.26" rot="R270"/>
<instance part="U$5" gate="GND" x="158.75" y="-73.66"/>
<instance part="U$6" gate="VCC" x="158.75" y="-43.18"/>
<instance part="U$7" gate="VCC" x="5.08" y="-7.62" rot="R180"/>
<instance part="U$8" gate="VCC" x="5.08" y="-68.58" rot="R180"/>
<instance part="U$9" gate="GND" x="6.35" y="-34.29"/>
<instance part="U$10" gate="VCC" x="5.08" y="63.5" rot="R180"/>
<instance part="U$11" gate="GND" x="6.35" y="41.91"/>
<instance part="U$12" gate="VCC" x="5.08" y="10.16" rot="R180"/>
<instance part="IC4" gate="A" x="106.68" y="-68.58"/>
<instance part="IC4" gate="P" x="215.9" y="-55.88"/>
<instance part="C4" gate="A" x="224.79" y="-55.88" smashed="yes" rot="R90">
<attribute name="NAME" x="220.98" y="-53.594" size="1.524" layer="95"/>
<attribute name="VALUE" x="219.71" y="-59.69" size="1.524" layer="96"/>
</instance>
<instance part="U$13" gate="VCC" x="91.44" y="-66.04"/>
<instance part="U$14" gate="VCC" x="88.9" y="60.96"/>
<instance part="U$15" gate="VCC" x="88.9" y="-29.21"/>
<instance part="U$16" gate="GND" x="86.36" y="63.5"/>
<instance part="U$17" gate="GND" x="86.36" y="-26.67"/>
<instance part="U$18" gate="VCC" x="87.63" y="10.16"/>
<instance part="U$19" gate="GND" x="88.9" y="-3.81"/>
<instance part="U$20" gate="VCC" x="158.75" y="-22.86"/>
<instance part="U$21" gate="GND" x="168.91" y="-31.75"/>
<instance part="IC2" gate="A" x="106.68" y="-39.37"/>
<instance part="IC2" gate="P" x="182.88" y="-55.88"/>
<instance part="C5" gate="A" x="161.29" y="-12.7" smashed="yes" rot="MR0">
<attribute name="NAME" x="158.75" y="-5.334" size="1.524" layer="95"/>
<attribute name="VALUE" x="158.75" y="-7.62" size="1.524" layer="96"/>
</instance>
<instance part="U$22" gate="GND" x="154.94" y="-16.51"/>
</instances>
<busses>
<bus name="D:SD6/D0,SD7/D1,SD4/D2,SD5/D3,SD2/D5,SD3/D4,SD0/D7,SD1/D6,SD9/D8,SD8/D15,SD11/D9,SD10/D14,SD13/D10,SD12/D13,SD15/D11,SD14/D12">
<segment>
<wire x1="39.37" y1="-64.77" x2="39.37" y2="72.39" width="0.762" layer="92"/>
<wire x1="39.37" y1="72.39" x2="223.52" y2="72.39" width="0.762" layer="92"/>
<wire x1="223.52" y1="72.39" x2="223.52" y2="-13.97" width="0.762" layer="92"/>
</segment>
</bus>
<bus name="A:SMA3/A3,SMA20/A10,SMA1/A1,SMA2/A2,SMA19/A11,SMA0/A0,WRN/WE,SMRAS/RAS,SMA4/A4,SMA18/A9,SMA6/A6,SMA5/A5,SMA16/A8,SMA7/A7,SMCAS/CAS,BASEM1,PD1,PD2,JP1,JP2">
<segment>
<wire x1="25.4" y1="-73.66" x2="25.4" y2="62.23" width="0.762" layer="92"/>
<wire x1="25.4" y1="-73.66" x2="67.31" y2="-73.66" width="0.762" layer="92"/>
<wire x1="67.31" y1="-73.66" x2="67.31" y2="57.15" width="0.762" layer="92"/>
</segment>
</bus>
<bus name="B:AB[0..11],BCAS0,BCAS2,BRAS0,BRAS1,WE">
<segment>
<wire x1="144.78" y1="-69.85" x2="144.78" y2="64.77" width="0.762" layer="92"/>
</segment>
</bus>
</busses>
<nets>
<net name="GND" class="0">
<segment>
<pinref part="JP2" gate="A" pin="1"/>
<pinref part="U$2" gate="GND" pin="GND"/>
<wire x1="52.07" y1="-58.42" x2="55.88" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="55.88" y1="-58.42" x2="55.88" y2="-60.96" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="JP1" gate="A" pin="1"/>
<pinref part="U$3" gate="GND" pin="GND"/>
<wire x1="52.07" y1="-25.4" x2="55.88" y2="-25.4" width="0.1524" layer="91"/>
<wire x1="55.88" y1="-25.4" x2="55.88" y2="-27.94" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C3" gate="A" pin="1"/>
<wire x1="208.28" y1="-60.96" x2="208.28" y2="-68.58" width="0.1524" layer="91"/>
<wire x1="208.28" y1="-68.58" x2="199.39" y2="-68.58" width="0.1524" layer="91"/>
<pinref part="IC3" gate="P" pin="GND"/>
<wire x1="199.39" y1="-68.58" x2="191.77" y2="-68.58" width="0.1524" layer="91"/>
<wire x1="191.77" y1="-68.58" x2="182.88" y2="-68.58" width="0.1524" layer="91"/>
<wire x1="182.88" y1="-68.58" x2="175.26" y2="-68.58" width="0.1524" layer="91"/>
<wire x1="175.26" y1="-68.58" x2="166.37" y2="-68.58" width="0.1524" layer="91"/>
<wire x1="166.37" y1="-68.58" x2="158.75" y2="-68.58" width="0.1524" layer="91"/>
<wire x1="199.39" y1="-66.04" x2="199.39" y2="-68.58" width="0.1524" layer="91"/>
<pinref part="C2" gate="A" pin="1"/>
<wire x1="191.77" y1="-60.96" x2="191.77" y2="-68.58" width="0.1524" layer="91"/>
<wire x1="182.88" y1="-66.04" x2="182.88" y2="-68.58" width="0.1524" layer="91"/>
<pinref part="C1" gate="A" pin="1"/>
<wire x1="175.26" y1="-60.96" x2="175.26" y2="-68.58" width="0.1524" layer="91"/>
<pinref part="IC1" gate="P" pin="GND"/>
<wire x1="166.37" y1="-66.04" x2="166.37" y2="-68.58" width="0.1524" layer="91"/>
<junction x="199.39" y="-68.58"/>
<junction x="191.77" y="-68.58"/>
<junction x="182.88" y="-68.58"/>
<junction x="175.26" y="-68.58"/>
<junction x="166.37" y="-68.58"/>
<pinref part="U$5" gate="GND" pin="GND"/>
<wire x1="158.75" y1="-68.58" x2="158.75" y2="-71.12" width="0.1524" layer="91"/>
<pinref part="IC4" gate="P" pin="GND"/>
<wire x1="208.28" y1="-68.58" x2="215.9" y2="-68.58" width="0.1524" layer="91"/>
<wire x1="215.9" y1="-68.58" x2="215.9" y2="-66.04" width="0.1524" layer="91"/>
<junction x="208.28" y="-68.58"/>
<pinref part="C4" gate="A" pin="1"/>
<wire x1="215.9" y1="-68.58" x2="224.79" y2="-68.58" width="0.1524" layer="91"/>
<wire x1="224.79" y1="-68.58" x2="224.79" y2="-60.96" width="0.1524" layer="91"/>
<junction x="215.9" y="-68.58"/>
<pinref part="IC2" gate="P" pin="GND"/>
</segment>
<segment>
<pinref part="J2" gate="A" pin="15"/>
<wire x1="-2.54" y1="-43.18" x2="0" y2="-43.18" width="0.1524" layer="91"/>
<wire x1="0" y1="-43.18" x2="0" y2="-45.72" width="0.1524" layer="91"/>
<pinref part="J2" gate="A" pin="16"/>
<wire x1="0" y1="-45.72" x2="-2.54" y2="-45.72" width="0.1524" layer="91"/>
<pinref part="J2" gate="A" pin="9"/>
<wire x1="-2.54" y1="-27.94" x2="0" y2="-27.94" width="0.1524" layer="91"/>
<wire x1="0" y1="-27.94" x2="0" y2="-30.48" width="0.1524" layer="91"/>
<pinref part="J2" gate="A" pin="12"/>
<wire x1="0" y1="-30.48" x2="0" y2="-33.02" width="0.1524" layer="91"/>
<wire x1="0" y1="-33.02" x2="0" y2="-35.56" width="0.1524" layer="91"/>
<wire x1="0" y1="-35.56" x2="-2.54" y2="-35.56" width="0.1524" layer="91"/>
<pinref part="J2" gate="A" pin="10"/>
<wire x1="-2.54" y1="-30.48" x2="0" y2="-30.48" width="0.1524" layer="91"/>
<pinref part="J2" gate="A" pin="11"/>
<wire x1="-2.54" y1="-33.02" x2="0" y2="-33.02" width="0.1524" layer="91"/>
<wire x1="0" y1="-43.18" x2="0" y2="-35.56" width="0.1524" layer="91"/>
<pinref part="U$9" gate="GND" pin="GND"/>
<wire x1="0" y1="-30.48" x2="6.35" y2="-30.48" width="0.1524" layer="91"/>
<wire x1="6.35" y1="-30.48" x2="6.35" y2="-31.75" width="0.1524" layer="91"/>
<junction x="0" y="-30.48"/>
<junction x="0" y="-33.02"/>
<junction x="0" y="-35.56"/>
<junction x="0" y="-43.18"/>
</segment>
<segment>
<wire x1="92.71" y1="-26.67" x2="91.44" y2="-26.67" width="0.1524" layer="91"/>
<wire x1="91.44" y1="-26.67" x2="91.44" y2="-22.86" width="0.1524" layer="91"/>
<pinref part="U$17" gate="GND" pin="GND"/>
<wire x1="91.44" y1="-22.86" x2="86.36" y2="-22.86" width="0.1524" layer="91"/>
<wire x1="86.36" y1="-22.86" x2="86.36" y2="-24.13" width="0.1524" layer="91"/>
<pinref part="IC2" gate="A" pin="!OE"/>
</segment>
<segment>
<pinref part="IC1" gate="A" pin="!OE"/>
<wire x1="92.71" y1="63.5" x2="91.44" y2="63.5" width="0.1524" layer="91"/>
<wire x1="91.44" y1="63.5" x2="91.44" y2="67.31" width="0.1524" layer="91"/>
<pinref part="U$16" gate="GND" pin="GND"/>
<wire x1="91.44" y1="67.31" x2="86.36" y2="67.31" width="0.1524" layer="91"/>
<wire x1="86.36" y1="67.31" x2="86.36" y2="66.04" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U$11" gate="GND" pin="GND"/>
<wire x1="6.35" y1="44.45" x2="6.35" y2="45.72" width="0.1524" layer="91"/>
<pinref part="J1" gate="A" pin="13"/>
<wire x1="-2.54" y1="35.56" x2="0" y2="35.56" width="0.1524" layer="91"/>
<wire x1="0" y1="35.56" x2="0" y2="33.02" width="0.1524" layer="91"/>
<pinref part="J1" gate="A" pin="14"/>
<wire x1="0" y1="33.02" x2="-2.54" y2="33.02" width="0.1524" layer="91"/>
<pinref part="J1" gate="A" pin="9"/>
<wire x1="-2.54" y1="45.72" x2="0" y2="45.72" width="0.1524" layer="91"/>
<wire x1="0" y1="45.72" x2="0" y2="43.18" width="0.1524" layer="91"/>
<pinref part="J1" gate="A" pin="10"/>
<wire x1="0" y1="43.18" x2="-2.54" y2="43.18" width="0.1524" layer="91"/>
<wire x1="0" y1="35.56" x2="0" y2="43.18" width="0.1524" layer="91"/>
<junction x="0" y="43.18"/>
<junction x="0" y="35.56"/>
<wire x1="6.35" y1="45.72" x2="0" y2="45.72" width="0.1524" layer="91"/>
<junction x="0" y="45.72"/>
</segment>
<segment>
<pinref part="IC3" gate="A" pin="IN9/!OE"/>
<pinref part="U$19" gate="GND" pin="GND"/>
<wire x1="92.71" y1="0" x2="88.9" y2="0" width="0.1524" layer="91"/>
<wire x1="88.9" y1="0" x2="88.9" y2="-1.27" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="GND"/>
<pinref part="U$21" gate="GND" pin="GND"/>
<wire x1="172.72" y1="-27.94" x2="168.91" y2="-27.94" width="0.1524" layer="91"/>
<wire x1="168.91" y1="-27.94" x2="168.91" y2="-29.21" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C5" gate="A" pin="K"/>
<pinref part="U$22" gate="GND" pin="GND"/>
<wire x1="156.21" y1="-12.7" x2="154.94" y2="-12.7" width="0.1524" layer="91"/>
<wire x1="154.94" y1="-12.7" x2="154.94" y2="-13.97" width="0.1524" layer="91"/>
</segment>
</net>
<net name="VCC" class="0">
<segment>
<pinref part="JP1" gate="A" pin="3"/>
<pinref part="U$1" gate="VCC" pin="VCC"/>
<wire x1="52.07" y1="-20.32" x2="55.88" y2="-20.32" width="0.1524" layer="91"/>
<wire x1="55.88" y1="-20.32" x2="55.88" y2="-17.78" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="JP2" gate="A" pin="3"/>
<pinref part="U$4" gate="VCC" pin="VCC"/>
<wire x1="52.07" y1="-53.34" x2="55.88" y2="-53.34" width="0.1524" layer="91"/>
<wire x1="55.88" y1="-53.34" x2="55.88" y2="-50.8" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C3" gate="A" pin="2"/>
<wire x1="208.28" y1="-50.8" x2="208.28" y2="-43.18" width="0.1524" layer="91"/>
<wire x1="208.28" y1="-43.18" x2="199.39" y2="-43.18" width="0.1524" layer="91"/>
<pinref part="IC1" gate="P" pin="VCC"/>
<wire x1="199.39" y1="-43.18" x2="191.77" y2="-43.18" width="0.1524" layer="91"/>
<wire x1="191.77" y1="-43.18" x2="182.88" y2="-43.18" width="0.1524" layer="91"/>
<wire x1="182.88" y1="-43.18" x2="175.26" y2="-43.18" width="0.1524" layer="91"/>
<wire x1="175.26" y1="-43.18" x2="166.37" y2="-43.18" width="0.1524" layer="91"/>
<wire x1="166.37" y1="-43.18" x2="161.29" y2="-43.18" width="0.1524" layer="91"/>
<wire x1="166.37" y1="-45.72" x2="166.37" y2="-43.18" width="0.1524" layer="91"/>
<pinref part="C1" gate="A" pin="2"/>
<wire x1="175.26" y1="-50.8" x2="175.26" y2="-43.18" width="0.1524" layer="91"/>
<wire x1="182.88" y1="-45.72" x2="182.88" y2="-43.18" width="0.1524" layer="91"/>
<pinref part="C2" gate="A" pin="2"/>
<wire x1="191.77" y1="-50.8" x2="191.77" y2="-43.18" width="0.1524" layer="91"/>
<pinref part="IC3" gate="P" pin="VCC"/>
<wire x1="199.39" y1="-45.72" x2="199.39" y2="-43.18" width="0.1524" layer="91"/>
<junction x="166.37" y="-43.18"/>
<junction x="175.26" y="-43.18"/>
<junction x="182.88" y="-43.18"/>
<junction x="191.77" y="-43.18"/>
<junction x="199.39" y="-43.18"/>
<pinref part="U$6" gate="VCC" pin="VCC"/>
<pinref part="IC4" gate="P" pin="VCC"/>
<wire x1="208.28" y1="-43.18" x2="215.9" y2="-43.18" width="0.1524" layer="91"/>
<wire x1="215.9" y1="-43.18" x2="215.9" y2="-45.72" width="0.1524" layer="91"/>
<junction x="208.28" y="-43.18"/>
<pinref part="C4" gate="A" pin="2"/>
<wire x1="215.9" y1="-43.18" x2="224.79" y2="-43.18" width="0.1524" layer="91"/>
<wire x1="224.79" y1="-43.18" x2="224.79" y2="-50.8" width="0.1524" layer="91"/>
<junction x="215.9" y="-43.18"/>
<pinref part="IC2" gate="P" pin="VCC"/>
</segment>
<segment>
<pinref part="J2" gate="A" pin="1"/>
<pinref part="U$7" gate="VCC" pin="VCC"/>
<wire x1="2.54" y1="-7.62" x2="0" y2="-7.62" width="0.1524" layer="91"/>
<pinref part="J2" gate="A" pin="2"/>
<wire x1="0" y1="-7.62" x2="-2.54" y2="-7.62" width="0.1524" layer="91"/>
<wire x1="-2.54" y1="-10.16" x2="0" y2="-10.16" width="0.1524" layer="91"/>
<wire x1="0" y1="-10.16" x2="0" y2="-7.62" width="0.1524" layer="91"/>
<junction x="0" y="-7.62"/>
</segment>
<segment>
<pinref part="J2" gate="A" pin="25"/>
<pinref part="U$8" gate="VCC" pin="VCC"/>
<wire x1="2.54" y1="-68.58" x2="0" y2="-68.58" width="0.1524" layer="91"/>
<pinref part="J2" gate="A" pin="26"/>
<wire x1="0" y1="-68.58" x2="-2.54" y2="-68.58" width="0.1524" layer="91"/>
<wire x1="-2.54" y1="-71.12" x2="0" y2="-71.12" width="0.1524" layer="91"/>
<wire x1="0" y1="-71.12" x2="0" y2="-68.58" width="0.1524" layer="91"/>
<junction x="0" y="-68.58"/>
</segment>
<segment>
<pinref part="J1" gate="A" pin="2"/>
<pinref part="U$10" gate="VCC" pin="VCC"/>
<wire x1="2.54" y1="63.5" x2="-2.54" y2="63.5" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="J1" gate="A" pin="23"/>
<pinref part="U$12" gate="VCC" pin="VCC"/>
<wire x1="2.54" y1="10.16" x2="0" y2="10.16" width="0.1524" layer="91"/>
<pinref part="J1" gate="A" pin="24"/>
<wire x1="0" y1="10.16" x2="-2.54" y2="10.16" width="0.1524" layer="91"/>
<wire x1="-2.54" y1="7.62" x2="0" y2="7.62" width="0.1524" layer="91"/>
<wire x1="0" y1="7.62" x2="0" y2="10.16" width="0.1524" layer="91"/>
<junction x="0" y="10.16"/>
</segment>
<segment>
<pinref part="IC4" gate="A" pin="OE"/>
<pinref part="U$13" gate="VCC" pin="VCC"/>
<wire x1="93.98" y1="-66.04" x2="95.25" y2="-66.04" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC1" gate="A" pin="DIR"/>
<pinref part="U$14" gate="VCC" pin="VCC"/>
<wire x1="91.44" y1="60.96" x2="92.71" y2="60.96" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U$15" gate="VCC" pin="VCC"/>
<wire x1="91.44" y1="-29.21" x2="92.71" y2="-29.21" width="0.1524" layer="91"/>
<pinref part="IC2" gate="A" pin="DIR"/>
</segment>
<segment>
<pinref part="IC3" gate="A" pin="IN5"/>
<pinref part="U$18" gate="VCC" pin="VCC"/>
<wire x1="90.17" y1="10.16" x2="91.44" y2="10.16" width="0.1524" layer="91"/>
<pinref part="IC3" gate="A" pin="IN6"/>
<wire x1="91.44" y1="10.16" x2="92.71" y2="10.16" width="0.1524" layer="91"/>
<wire x1="92.71" y1="7.62" x2="91.44" y2="7.62" width="0.1524" layer="91"/>
<wire x1="91.44" y1="7.62" x2="91.44" y2="10.16" width="0.1524" layer="91"/>
<junction x="91.44" y="10.16"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="VCC"/>
<pinref part="U$20" gate="VCC" pin="VCC"/>
<wire x1="161.29" y1="-22.86" x2="167.64" y2="-22.86" width="0.1524" layer="91"/>
<pinref part="C5" gate="A" pin="A"/>
<wire x1="167.64" y1="-22.86" x2="172.72" y2="-22.86" width="0.1524" layer="91"/>
<wire x1="166.37" y1="-12.7" x2="167.64" y2="-12.7" width="0.1524" layer="91"/>
<wire x1="167.64" y1="-12.7" x2="167.64" y2="-22.86" width="0.1524" layer="91"/>
<junction x="167.64" y="-22.86"/>
</segment>
</net>
<net name="SMA0/A0" class="0">
<segment>
<pinref part="J1" gate="A" pin="8"/>
<wire x1="-2.54" y1="48.26" x2="24.13" y2="48.26" width="0.1524" layer="91"/>
<label x="22.86" y="48.514" size="1.524" layer="95" rot="MR0"/>
<wire x1="25.4" y1="49.53" x2="24.13" y2="48.26" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="67.31" y1="39.37" x2="68.58" y2="38.1" width="0.1524" layer="91"/>
<wire x1="68.58" y1="38.1" x2="92.71" y2="38.1" width="0.1524" layer="91"/>
<label x="69.85" y="38.354" size="1.524" layer="95"/>
<pinref part="IC1" gate="A" pin="A8"/>
</segment>
</net>
<net name="SMA1/A1" class="0">
<segment>
<pinref part="J1" gate="A" pin="5"/>
<wire x1="-2.54" y1="55.88" x2="24.13" y2="55.88" width="0.1524" layer="91"/>
<label x="22.86" y="56.134" size="1.524" layer="95" rot="MR0"/>
<wire x1="25.4" y1="57.15" x2="24.13" y2="55.88" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="67.31" y1="41.91" x2="68.58" y2="40.64" width="0.1524" layer="91"/>
<wire x1="68.58" y1="40.64" x2="92.71" y2="40.64" width="0.1524" layer="91"/>
<label x="69.85" y="40.894" size="1.524" layer="95"/>
<pinref part="IC1" gate="A" pin="A7"/>
</segment>
</net>
<net name="SMA2/A2" class="0">
<segment>
<pinref part="J1" gate="A" pin="6"/>
<wire x1="-2.54" y1="53.34" x2="24.13" y2="53.34" width="0.1524" layer="91"/>
<label x="22.86" y="53.594" size="1.524" layer="95" rot="MR0"/>
<wire x1="25.4" y1="54.61" x2="24.13" y2="53.34" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="67.31" y1="44.45" x2="68.58" y2="43.18" width="0.1524" layer="91"/>
<wire x1="68.58" y1="43.18" x2="92.71" y2="43.18" width="0.1524" layer="91"/>
<label x="69.85" y="43.434" size="1.524" layer="95"/>
<pinref part="IC1" gate="A" pin="A6"/>
</segment>
</net>
<net name="SMA3/A3" class="0">
<segment>
<pinref part="J1" gate="A" pin="3"/>
<wire x1="-2.54" y1="60.96" x2="24.13" y2="60.96" width="0.1524" layer="91"/>
<label x="22.86" y="61.214" size="1.524" layer="95" rot="MR0"/>
<wire x1="25.4" y1="62.23" x2="24.13" y2="60.96" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="67.31" y1="46.99" x2="68.58" y2="45.72" width="0.1524" layer="91"/>
<wire x1="68.58" y1="45.72" x2="92.71" y2="45.72" width="0.1524" layer="91"/>
<label x="69.85" y="45.974" size="1.524" layer="95"/>
<pinref part="IC1" gate="A" pin="A5"/>
</segment>
</net>
<net name="SMA19/A11" class="0">
<segment>
<pinref part="J1" gate="A" pin="7"/>
<wire x1="-2.54" y1="50.8" x2="24.13" y2="50.8" width="0.1524" layer="91"/>
<label x="22.86" y="51.054" size="1.524" layer="95" rot="MR0"/>
<wire x1="25.4" y1="52.07" x2="24.13" y2="50.8" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="67.31" y1="-48.26" x2="68.58" y2="-49.53" width="0.1524" layer="91"/>
<wire x1="68.58" y1="-49.53" x2="92.71" y2="-49.53" width="0.1524" layer="91"/>
<label x="69.85" y="-49.276" size="1.524" layer="95"/>
<pinref part="IC2" gate="A" pin="A7"/>
</segment>
<segment>
<pinref part="IC3" gate="A" pin="IN0/CLK"/>
<wire x1="67.31" y1="24.13" x2="68.58" y2="22.86" width="0.1524" layer="91"/>
<wire x1="68.58" y1="22.86" x2="92.71" y2="22.86" width="0.1524" layer="91"/>
<label x="69.85" y="23.114" size="1.524" layer="95"/>
</segment>
</net>
<net name="SMA20/A10" class="0">
<segment>
<pinref part="J1" gate="A" pin="4"/>
<wire x1="-2.54" y1="58.42" x2="24.13" y2="58.42" width="0.1524" layer="91"/>
<label x="22.86" y="58.674" size="1.524" layer="95" rot="MR0"/>
<wire x1="25.4" y1="59.69" x2="24.13" y2="58.42" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="67.31" y1="-50.8" x2="68.58" y2="-52.07" width="0.1524" layer="91"/>
<wire x1="68.58" y1="-52.07" x2="92.71" y2="-52.07" width="0.1524" layer="91"/>
<label x="69.85" y="-51.816" size="1.524" layer="95"/>
<pinref part="IC2" gate="A" pin="A8"/>
</segment>
<segment>
<pinref part="IC3" gate="A" pin="IN1"/>
<wire x1="67.31" y1="21.59" x2="68.58" y2="20.32" width="0.1524" layer="91"/>
<wire x1="68.58" y1="20.32" x2="92.71" y2="20.32" width="0.1524" layer="91"/>
<label x="69.85" y="20.574" size="1.524" layer="95"/>
</segment>
</net>
<net name="WRN/WE" class="0">
<segment>
<pinref part="J1" gate="A" pin="11"/>
<wire x1="-2.54" y1="40.64" x2="24.13" y2="40.64" width="0.1524" layer="91"/>
<label x="22.86" y="40.894" size="1.524" layer="95" rot="MR0"/>
<wire x1="25.4" y1="41.91" x2="24.13" y2="40.64" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC4" gate="A" pin="A"/>
<wire x1="67.31" y1="-69.85" x2="68.58" y2="-71.12" width="0.1524" layer="91"/>
<wire x1="68.58" y1="-71.12" x2="95.25" y2="-71.12" width="0.1524" layer="91"/>
<label x="69.85" y="-70.866" size="1.524" layer="95"/>
</segment>
</net>
<net name="SMRAS/RAS" class="0">
<segment>
<pinref part="J1" gate="A" pin="12"/>
<wire x1="-2.54" y1="38.1" x2="24.13" y2="38.1" width="0.1524" layer="91"/>
<label x="22.86" y="38.354" size="1.524" layer="95" rot="MR0"/>
<wire x1="25.4" y1="39.37" x2="24.13" y2="38.1" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC3" gate="A" pin="IN2"/>
<wire x1="67.31" y1="19.05" x2="68.58" y2="17.78" width="0.1524" layer="91"/>
<wire x1="68.58" y1="17.78" x2="92.71" y2="17.78" width="0.1524" layer="91"/>
<label x="69.85" y="18.034" size="1.524" layer="95"/>
</segment>
</net>
<net name="SD0/D7" class="0">
<segment>
<pinref part="J1" gate="A" pin="21"/>
<wire x1="-2.54" y1="15.24" x2="38.1" y2="15.24" width="0.1524" layer="91"/>
<label x="36.83" y="15.494" size="1.524" layer="95" rot="MR0"/>
<wire x1="39.37" y1="16.51" x2="38.1" y2="15.24" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D7"/>
<wire x1="223.52" y1="46.99" x2="222.25" y2="45.72" width="0.1524" layer="91"/>
<wire x1="222.25" y1="45.72" x2="205.74" y2="45.72" width="0.1524" layer="91"/>
<label x="220.98" y="45.974" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D23"/>
<wire x1="223.52" y1="6.35" x2="222.25" y2="5.08" width="0.1524" layer="91"/>
<wire x1="222.25" y1="5.08" x2="205.74" y2="5.08" width="0.1524" layer="91"/>
<label x="220.98" y="5.334" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="SD1/D6" class="0">
<segment>
<pinref part="J1" gate="A" pin="22"/>
<wire x1="-2.54" y1="12.7" x2="38.1" y2="12.7" width="0.1524" layer="91"/>
<label x="36.83" y="12.954" size="1.524" layer="95" rot="MR0"/>
<wire x1="39.37" y1="13.97" x2="38.1" y2="12.7" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D6"/>
<wire x1="223.52" y1="49.53" x2="222.25" y2="48.26" width="0.1524" layer="91"/>
<wire x1="222.25" y1="48.26" x2="205.74" y2="48.26" width="0.1524" layer="91"/>
<label x="220.98" y="48.514" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D22"/>
<wire x1="223.52" y1="8.89" x2="222.25" y2="7.62" width="0.1524" layer="91"/>
<wire x1="222.25" y1="7.62" x2="205.74" y2="7.62" width="0.1524" layer="91"/>
<label x="220.98" y="7.874" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="SD3/D4" class="0">
<segment>
<pinref part="J1" gate="A" pin="20"/>
<wire x1="-2.54" y1="17.78" x2="38.1" y2="17.78" width="0.1524" layer="91"/>
<label x="36.83" y="18.034" size="1.524" layer="95" rot="MR0"/>
<wire x1="39.37" y1="19.05" x2="38.1" y2="17.78" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D4"/>
<wire x1="223.52" y1="54.61" x2="222.25" y2="53.34" width="0.1524" layer="91"/>
<wire x1="222.25" y1="53.34" x2="205.74" y2="53.34" width="0.1524" layer="91"/>
<label x="220.98" y="53.594" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D20"/>
<wire x1="223.52" y1="13.97" x2="222.25" y2="12.7" width="0.1524" layer="91"/>
<wire x1="222.25" y1="12.7" x2="205.74" y2="12.7" width="0.1524" layer="91"/>
<label x="220.98" y="12.954" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="SD2/D5" class="0">
<segment>
<pinref part="J1" gate="A" pin="19"/>
<wire x1="-2.54" y1="20.32" x2="38.1" y2="20.32" width="0.1524" layer="91"/>
<label x="36.83" y="20.574" size="1.524" layer="95" rot="MR0"/>
<wire x1="39.37" y1="21.59" x2="38.1" y2="20.32" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D5"/>
<wire x1="223.52" y1="52.07" x2="222.25" y2="50.8" width="0.1524" layer="91"/>
<wire x1="222.25" y1="50.8" x2="205.74" y2="50.8" width="0.1524" layer="91"/>
<label x="220.98" y="51.054" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D21"/>
<wire x1="223.52" y1="11.43" x2="222.25" y2="10.16" width="0.1524" layer="91"/>
<wire x1="222.25" y1="10.16" x2="205.74" y2="10.16" width="0.1524" layer="91"/>
<label x="220.98" y="10.414" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="SD5/D3" class="0">
<segment>
<pinref part="J1" gate="A" pin="18"/>
<wire x1="-2.54" y1="22.86" x2="38.1" y2="22.86" width="0.1524" layer="91"/>
<label x="36.83" y="23.114" size="1.524" layer="95" rot="MR0"/>
<wire x1="39.37" y1="24.13" x2="38.1" y2="22.86" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D3"/>
<wire x1="223.52" y1="57.15" x2="222.25" y2="55.88" width="0.1524" layer="91"/>
<wire x1="222.25" y1="55.88" x2="205.74" y2="55.88" width="0.1524" layer="91"/>
<label x="220.98" y="56.134" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D19"/>
<wire x1="223.52" y1="16.51" x2="222.25" y2="15.24" width="0.1524" layer="91"/>
<wire x1="222.25" y1="15.24" x2="205.74" y2="15.24" width="0.1524" layer="91"/>
<label x="220.98" y="15.494" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="SD4/D2" class="0">
<segment>
<pinref part="J1" gate="A" pin="17"/>
<wire x1="-2.54" y1="25.4" x2="38.1" y2="25.4" width="0.1524" layer="91"/>
<label x="36.83" y="25.654" size="1.524" layer="95" rot="MR0"/>
<wire x1="39.37" y1="26.67" x2="38.1" y2="25.4" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D2"/>
<wire x1="223.52" y1="59.69" x2="222.25" y2="58.42" width="0.1524" layer="91"/>
<wire x1="222.25" y1="58.42" x2="205.74" y2="58.42" width="0.1524" layer="91"/>
<label x="220.98" y="58.674" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D18"/>
<wire x1="223.52" y1="19.05" x2="222.25" y2="17.78" width="0.1524" layer="91"/>
<wire x1="222.25" y1="17.78" x2="205.74" y2="17.78" width="0.1524" layer="91"/>
<label x="220.98" y="18.034" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="SD7/D1" class="0">
<segment>
<pinref part="J1" gate="A" pin="16"/>
<wire x1="-2.54" y1="27.94" x2="38.1" y2="27.94" width="0.1524" layer="91"/>
<label x="36.83" y="28.194" size="1.524" layer="95" rot="MR0"/>
<wire x1="39.37" y1="29.21" x2="38.1" y2="27.94" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D1"/>
<wire x1="223.52" y1="62.23" x2="222.25" y2="60.96" width="0.1524" layer="91"/>
<wire x1="222.25" y1="60.96" x2="205.74" y2="60.96" width="0.1524" layer="91"/>
<label x="220.98" y="61.214" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D17"/>
<wire x1="223.52" y1="21.59" x2="222.25" y2="20.32" width="0.1524" layer="91"/>
<wire x1="222.25" y1="20.32" x2="205.74" y2="20.32" width="0.1524" layer="91"/>
<label x="220.98" y="20.574" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="SD6/D0" class="0">
<segment>
<wire x1="39.37" y1="31.75" x2="38.1" y2="30.48" width="0.1524" layer="91"/>
<pinref part="J1" gate="A" pin="15"/>
<wire x1="-2.54" y1="30.48" x2="38.1" y2="30.48" width="0.1524" layer="91"/>
<label x="36.83" y="30.734" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D0"/>
<wire x1="223.52" y1="64.77" x2="222.25" y2="63.5" width="0.1524" layer="91"/>
<wire x1="222.25" y1="63.5" x2="205.74" y2="63.5" width="0.1524" layer="91"/>
<label x="220.98" y="63.754" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D16"/>
<wire x1="223.52" y1="24.13" x2="222.25" y2="22.86" width="0.1524" layer="91"/>
<wire x1="222.25" y1="22.86" x2="205.74" y2="22.86" width="0.1524" layer="91"/>
<label x="220.98" y="23.114" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="SMCAS/CAS" class="0">
<segment>
<pinref part="J2" gate="A" pin="13"/>
<wire x1="-2.54" y1="-38.1" x2="24.13" y2="-38.1" width="0.1524" layer="91"/>
<label x="22.86" y="-37.846" size="1.524" layer="95" rot="MR0"/>
<wire x1="25.4" y1="-36.83" x2="24.13" y2="-38.1" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC3" gate="A" pin="IN7"/>
<wire x1="67.31" y1="6.35" x2="68.58" y2="5.08" width="0.1524" layer="91"/>
<wire x1="68.58" y1="5.08" x2="92.71" y2="5.08" width="0.1524" layer="91"/>
<label x="69.85" y="5.334" size="1.524" layer="95"/>
</segment>
</net>
<net name="BASEM1" class="0">
<segment>
<pinref part="J2" gate="A" pin="14"/>
<wire x1="-2.54" y1="-40.64" x2="24.13" y2="-40.64" width="0.1524" layer="91"/>
<label x="22.86" y="-40.386" size="1.524" layer="95" rot="MR0"/>
<wire x1="25.4" y1="-39.37" x2="24.13" y2="-40.64" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC3" gate="A" pin="IN8"/>
<wire x1="67.31" y1="3.81" x2="68.58" y2="2.54" width="0.1524" layer="91"/>
<wire x1="68.58" y1="2.54" x2="92.71" y2="2.54" width="0.1524" layer="91"/>
<label x="69.85" y="2.794" size="1.524" layer="95"/>
</segment>
</net>
<net name="SMA4/A4" class="0">
<segment>
<pinref part="J2" gate="A" pin="3"/>
<wire x1="-2.54" y1="-12.7" x2="24.13" y2="-12.7" width="0.1524" layer="91"/>
<label x="22.86" y="-12.446" size="1.524" layer="95" rot="MR0"/>
<wire x1="25.4" y1="-11.43" x2="24.13" y2="-12.7" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="67.31" y1="49.53" x2="68.58" y2="48.26" width="0.1524" layer="91"/>
<wire x1="68.58" y1="48.26" x2="92.71" y2="48.26" width="0.1524" layer="91"/>
<label x="69.85" y="48.514" size="1.524" layer="95"/>
<pinref part="IC1" gate="A" pin="A4"/>
</segment>
</net>
<net name="SMA18/A9" class="0">
<segment>
<pinref part="J2" gate="A" pin="4"/>
<wire x1="-2.54" y1="-15.24" x2="24.13" y2="-15.24" width="0.1524" layer="91"/>
<label x="22.86" y="-14.986" size="1.524" layer="95" rot="MR0"/>
<wire x1="25.4" y1="-13.97" x2="24.13" y2="-15.24" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="67.31" y1="-43.18" x2="68.58" y2="-44.45" width="0.1524" layer="91"/>
<wire x1="68.58" y1="-44.45" x2="92.71" y2="-44.45" width="0.1524" layer="91"/>
<label x="69.85" y="-44.196" size="1.524" layer="95"/>
<pinref part="IC2" gate="A" pin="A5"/>
</segment>
</net>
<net name="SMA6/A6" class="0">
<segment>
<pinref part="J2" gate="A" pin="5"/>
<wire x1="-2.54" y1="-17.78" x2="24.13" y2="-17.78" width="0.1524" layer="91"/>
<label x="22.86" y="-17.526" size="1.524" layer="95" rot="MR0"/>
<wire x1="25.4" y1="-16.51" x2="24.13" y2="-17.78" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="67.31" y1="54.61" x2="68.58" y2="53.34" width="0.1524" layer="91"/>
<wire x1="68.58" y1="53.34" x2="92.71" y2="53.34" width="0.1524" layer="91"/>
<label x="69.85" y="53.594" size="1.524" layer="95"/>
<pinref part="IC1" gate="A" pin="A2"/>
</segment>
</net>
<net name="SMA5/A5" class="0">
<segment>
<pinref part="J2" gate="A" pin="6"/>
<wire x1="-2.54" y1="-20.32" x2="24.13" y2="-20.32" width="0.1524" layer="91"/>
<label x="22.86" y="-20.066" size="1.524" layer="95" rot="MR0"/>
<wire x1="25.4" y1="-19.05" x2="24.13" y2="-20.32" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="67.31" y1="52.07" x2="68.58" y2="50.8" width="0.1524" layer="91"/>
<wire x1="68.58" y1="50.8" x2="92.71" y2="50.8" width="0.1524" layer="91"/>
<label x="69.85" y="51.054" size="1.524" layer="95"/>
<pinref part="IC1" gate="A" pin="A3"/>
</segment>
</net>
<net name="SMA16/A8" class="0">
<segment>
<pinref part="J2" gate="A" pin="7"/>
<wire x1="-2.54" y1="-22.86" x2="24.13" y2="-22.86" width="0.1524" layer="91"/>
<label x="22.86" y="-22.606" size="1.524" layer="95" rot="MR0"/>
<wire x1="25.4" y1="-21.59" x2="24.13" y2="-22.86" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="67.31" y1="-45.72" x2="68.58" y2="-46.99" width="0.1524" layer="91"/>
<wire x1="68.58" y1="-46.99" x2="92.71" y2="-46.99" width="0.1524" layer="91"/>
<label x="69.85" y="-46.736" size="1.524" layer="95"/>
<pinref part="IC2" gate="A" pin="A6"/>
</segment>
</net>
<net name="SMA7/A7" class="0">
<segment>
<pinref part="J2" gate="A" pin="8"/>
<wire x1="-2.54" y1="-25.4" x2="24.13" y2="-25.4" width="0.1524" layer="91"/>
<label x="22.86" y="-25.146" size="1.524" layer="95" rot="MR0"/>
<wire x1="25.4" y1="-24.13" x2="24.13" y2="-25.4" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="67.31" y1="57.15" x2="68.58" y2="55.88" width="0.1524" layer="91"/>
<wire x1="68.58" y1="55.88" x2="92.71" y2="55.88" width="0.1524" layer="91"/>
<label x="69.85" y="56.134" size="1.524" layer="95"/>
<pinref part="IC1" gate="A" pin="A1"/>
</segment>
</net>
<net name="SD8/D15" class="0">
<segment>
<pinref part="J2" gate="A" pin="18"/>
<wire x1="-2.54" y1="-50.8" x2="38.1" y2="-50.8" width="0.1524" layer="91"/>
<label x="36.83" y="-50.546" size="1.524" layer="95" rot="MR0"/>
<wire x1="39.37" y1="-49.53" x2="38.1" y2="-50.8" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D15"/>
<wire x1="223.52" y1="26.67" x2="222.25" y2="25.4" width="0.1524" layer="91"/>
<wire x1="222.25" y1="25.4" x2="205.74" y2="25.4" width="0.1524" layer="91"/>
<label x="220.98" y="25.654" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D31"/>
<wire x1="223.52" y1="-13.97" x2="222.25" y2="-15.24" width="0.1524" layer="91"/>
<wire x1="222.25" y1="-15.24" x2="205.74" y2="-15.24" width="0.1524" layer="91"/>
<label x="220.98" y="-14.986" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="SD13/D10" class="0">
<segment>
<pinref part="J2" gate="A" pin="21"/>
<wire x1="-2.54" y1="-58.42" x2="38.1" y2="-58.42" width="0.1524" layer="91"/>
<label x="36.83" y="-58.166" size="1.524" layer="95" rot="MR0"/>
<wire x1="39.37" y1="-57.15" x2="38.1" y2="-58.42" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D10"/>
<wire x1="223.52" y1="39.37" x2="222.25" y2="38.1" width="0.1524" layer="91"/>
<wire x1="222.25" y1="38.1" x2="205.74" y2="38.1" width="0.1524" layer="91"/>
<label x="220.98" y="38.354" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D26"/>
<wire x1="223.52" y1="-1.27" x2="222.25" y2="-2.54" width="0.1524" layer="91"/>
<wire x1="222.25" y1="-2.54" x2="205.74" y2="-2.54" width="0.1524" layer="91"/>
<label x="220.98" y="-2.286" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="CAS2" class="0">
<segment>
<pinref part="IC3" gate="A" pin="IO0"/>
<wire x1="120.65" y1="22.86" x2="137.16" y2="22.86" width="0.1524" layer="91"/>
<wire x1="137.16" y1="22.86" x2="137.16" y2="-10.16" width="0.1524" layer="91"/>
<wire x1="137.16" y1="-10.16" x2="73.66" y2="-10.16" width="0.1524" layer="91"/>
<wire x1="73.66" y1="-10.16" x2="73.66" y2="-41.91" width="0.1524" layer="91"/>
<wire x1="73.66" y1="-41.91" x2="92.71" y2="-41.91" width="0.1524" layer="91"/>
<label x="128.27" y="23.114" size="1.524" layer="95" rot="MR0"/>
<label x="87.63" y="-41.656" size="1.524" layer="95"/>
<pinref part="IC2" gate="A" pin="A4"/>
</segment>
</net>
<net name="CAS0" class="0">
<segment>
<pinref part="IC3" gate="A" pin="IO1"/>
<wire x1="120.65" y1="20.32" x2="134.62" y2="20.32" width="0.1524" layer="91"/>
<wire x1="134.62" y1="20.32" x2="134.62" y2="-12.7" width="0.1524" layer="91"/>
<wire x1="134.62" y1="-12.7" x2="76.2" y2="-12.7" width="0.1524" layer="91"/>
<wire x1="76.2" y1="-12.7" x2="76.2" y2="-39.37" width="0.1524" layer="91"/>
<wire x1="76.2" y1="-39.37" x2="92.71" y2="-39.37" width="0.1524" layer="91"/>
<label x="128.27" y="20.574" size="1.524" layer="95" rot="MR0"/>
<label x="87.63" y="-39.116" size="1.524" layer="95"/>
<pinref part="IC2" gate="A" pin="A3"/>
</segment>
</net>
<net name="RAS0" class="0">
<segment>
<pinref part="IC3" gate="A" pin="IO2"/>
<wire x1="120.65" y1="17.78" x2="132.08" y2="17.78" width="0.1524" layer="91"/>
<wire x1="132.08" y1="17.78" x2="132.08" y2="-15.24" width="0.1524" layer="91"/>
<wire x1="132.08" y1="-15.24" x2="78.74" y2="-15.24" width="0.1524" layer="91"/>
<wire x1="78.74" y1="-15.24" x2="78.74" y2="-36.83" width="0.1524" layer="91"/>
<wire x1="78.74" y1="-36.83" x2="92.71" y2="-36.83" width="0.1524" layer="91"/>
<label x="128.27" y="18.034" size="1.524" layer="95" rot="MR0"/>
<label x="87.63" y="-36.576" size="1.524" layer="95"/>
<pinref part="IC2" gate="A" pin="A2"/>
</segment>
</net>
<net name="RAS1" class="0">
<segment>
<pinref part="IC3" gate="A" pin="IO7"/>
<wire x1="120.65" y1="5.08" x2="129.54" y2="5.08" width="0.1524" layer="91"/>
<wire x1="129.54" y1="5.08" x2="129.54" y2="-17.78" width="0.1524" layer="91"/>
<wire x1="129.54" y1="-17.78" x2="81.28" y2="-17.78" width="0.1524" layer="91"/>
<wire x1="81.28" y1="-17.78" x2="81.28" y2="-34.29" width="0.1524" layer="91"/>
<wire x1="81.28" y1="-34.29" x2="92.71" y2="-34.29" width="0.1524" layer="91"/>
<label x="128.27" y="5.334" size="1.524" layer="95" rot="MR0"/>
<label x="87.63" y="-34.036" size="1.524" layer="95"/>
<pinref part="IC2" gate="A" pin="A1"/>
</segment>
</net>
<net name="JP1" class="0">
<segment>
<pinref part="JP1" gate="A" pin="2"/>
<wire x1="67.31" y1="-21.59" x2="66.04" y2="-22.86" width="0.1524" layer="91"/>
<wire x1="66.04" y1="-22.86" x2="52.07" y2="-22.86" width="0.1524" layer="91"/>
<label x="64.77" y="-22.606" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="IC3" gate="A" pin="IN3/PD"/>
<wire x1="67.31" y1="16.51" x2="68.58" y2="15.24" width="0.1524" layer="91"/>
<wire x1="68.58" y1="15.24" x2="92.71" y2="15.24" width="0.1524" layer="91"/>
<label x="69.85" y="15.494" size="1.524" layer="95"/>
</segment>
</net>
<net name="JP2" class="0">
<segment>
<pinref part="JP2" gate="A" pin="2"/>
<wire x1="67.31" y1="-54.61" x2="66.04" y2="-55.88" width="0.1524" layer="91"/>
<wire x1="66.04" y1="-55.88" x2="52.07" y2="-55.88" width="0.1524" layer="91"/>
<label x="64.77" y="-55.626" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="IC3" gate="A" pin="IN4"/>
<wire x1="67.31" y1="13.97" x2="68.58" y2="12.7" width="0.1524" layer="91"/>
<wire x1="68.58" y1="12.7" x2="92.71" y2="12.7" width="0.1524" layer="91"/>
<label x="69.85" y="12.954" size="1.524" layer="95"/>
</segment>
</net>
<net name="AB0" class="0">
<segment>
<wire x1="144.78" y1="39.37" x2="143.51" y2="38.1" width="0.1524" layer="91"/>
<wire x1="143.51" y1="38.1" x2="120.65" y2="38.1" width="0.1524" layer="91"/>
<label x="142.24" y="38.354" size="1.524" layer="95" rot="MR0"/>
<pinref part="IC1" gate="A" pin="B8"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="A0"/>
<wire x1="144.78" y1="64.77" x2="146.05" y2="63.5" width="0.1524" layer="91"/>
<wire x1="146.05" y1="63.5" x2="172.72" y2="63.5" width="0.1524" layer="91"/>
<label x="147.32" y="63.754" size="1.524" layer="95"/>
</segment>
</net>
<net name="AB1" class="0">
<segment>
<wire x1="144.78" y1="41.91" x2="143.51" y2="40.64" width="0.1524" layer="91"/>
<wire x1="143.51" y1="40.64" x2="120.65" y2="40.64" width="0.1524" layer="91"/>
<label x="142.24" y="40.894" size="1.524" layer="95" rot="MR0"/>
<pinref part="IC1" gate="A" pin="B7"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="A1"/>
<wire x1="144.78" y1="62.23" x2="146.05" y2="60.96" width="0.1524" layer="91"/>
<wire x1="146.05" y1="60.96" x2="172.72" y2="60.96" width="0.1524" layer="91"/>
<label x="147.32" y="61.214" size="1.524" layer="95"/>
</segment>
</net>
<net name="AB2" class="0">
<segment>
<wire x1="144.78" y1="44.45" x2="143.51" y2="43.18" width="0.1524" layer="91"/>
<wire x1="143.51" y1="43.18" x2="120.65" y2="43.18" width="0.1524" layer="91"/>
<label x="142.24" y="43.434" size="1.524" layer="95" rot="MR0"/>
<pinref part="IC1" gate="A" pin="B6"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="A2"/>
<wire x1="144.78" y1="59.69" x2="146.05" y2="58.42" width="0.1524" layer="91"/>
<wire x1="146.05" y1="58.42" x2="172.72" y2="58.42" width="0.1524" layer="91"/>
<label x="147.32" y="58.674" size="1.524" layer="95"/>
</segment>
</net>
<net name="AB3" class="0">
<segment>
<wire x1="144.78" y1="46.99" x2="143.51" y2="45.72" width="0.1524" layer="91"/>
<wire x1="143.51" y1="45.72" x2="120.65" y2="45.72" width="0.1524" layer="91"/>
<label x="142.24" y="45.974" size="1.524" layer="95" rot="MR0"/>
<pinref part="IC1" gate="A" pin="B5"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="A3"/>
<wire x1="144.78" y1="57.15" x2="146.05" y2="55.88" width="0.1524" layer="91"/>
<wire x1="146.05" y1="55.88" x2="172.72" y2="55.88" width="0.1524" layer="91"/>
<label x="147.32" y="56.134" size="1.524" layer="95"/>
</segment>
</net>
<net name="AB4" class="0">
<segment>
<wire x1="144.78" y1="49.53" x2="143.51" y2="48.26" width="0.1524" layer="91"/>
<wire x1="143.51" y1="48.26" x2="120.65" y2="48.26" width="0.1524" layer="91"/>
<label x="142.24" y="48.514" size="1.524" layer="95" rot="MR0"/>
<pinref part="IC1" gate="A" pin="B4"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="A4"/>
<wire x1="144.78" y1="54.61" x2="146.05" y2="53.34" width="0.1524" layer="91"/>
<wire x1="146.05" y1="53.34" x2="172.72" y2="53.34" width="0.1524" layer="91"/>
<label x="147.32" y="53.594" size="1.524" layer="95"/>
</segment>
</net>
<net name="AB5" class="0">
<segment>
<wire x1="144.78" y1="52.07" x2="143.51" y2="50.8" width="0.1524" layer="91"/>
<wire x1="143.51" y1="50.8" x2="120.65" y2="50.8" width="0.1524" layer="91"/>
<label x="142.24" y="51.054" size="1.524" layer="95" rot="MR0"/>
<pinref part="IC1" gate="A" pin="B3"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="A5"/>
<wire x1="144.78" y1="52.07" x2="146.05" y2="50.8" width="0.1524" layer="91"/>
<wire x1="146.05" y1="50.8" x2="172.72" y2="50.8" width="0.1524" layer="91"/>
<label x="147.32" y="51.054" size="1.524" layer="95"/>
</segment>
</net>
<net name="AB6" class="0">
<segment>
<wire x1="144.78" y1="54.61" x2="143.51" y2="53.34" width="0.1524" layer="91"/>
<wire x1="143.51" y1="53.34" x2="120.65" y2="53.34" width="0.1524" layer="91"/>
<label x="142.24" y="53.594" size="1.524" layer="95" rot="MR0"/>
<pinref part="IC1" gate="A" pin="B2"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="A6"/>
<wire x1="144.78" y1="49.53" x2="146.05" y2="48.26" width="0.1524" layer="91"/>
<wire x1="146.05" y1="48.26" x2="172.72" y2="48.26" width="0.1524" layer="91"/>
<label x="147.32" y="48.514" size="1.524" layer="95"/>
</segment>
</net>
<net name="AB7" class="0">
<segment>
<wire x1="144.78" y1="57.15" x2="143.51" y2="55.88" width="0.1524" layer="91"/>
<wire x1="143.51" y1="55.88" x2="120.65" y2="55.88" width="0.1524" layer="91"/>
<label x="142.24" y="56.134" size="1.524" layer="95" rot="MR0"/>
<pinref part="IC1" gate="A" pin="B1"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="A7"/>
<wire x1="144.78" y1="46.99" x2="146.05" y2="45.72" width="0.1524" layer="91"/>
<wire x1="146.05" y1="45.72" x2="172.72" y2="45.72" width="0.1524" layer="91"/>
<label x="147.32" y="45.974" size="1.524" layer="95"/>
</segment>
</net>
<net name="AB10" class="0">
<segment>
<wire x1="144.78" y1="-50.8" x2="143.51" y2="-52.07" width="0.1524" layer="91"/>
<wire x1="143.51" y1="-52.07" x2="120.65" y2="-52.07" width="0.1524" layer="91"/>
<label x="142.24" y="-51.816" size="1.524" layer="95" rot="MR0"/>
<pinref part="IC2" gate="A" pin="B8"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="A10"/>
<wire x1="144.78" y1="39.37" x2="146.05" y2="38.1" width="0.1524" layer="91"/>
<wire x1="146.05" y1="38.1" x2="172.72" y2="38.1" width="0.1524" layer="91"/>
<label x="147.32" y="38.354" size="1.524" layer="95"/>
</segment>
</net>
<net name="AB11" class="0">
<segment>
<wire x1="144.78" y1="-48.26" x2="143.51" y2="-49.53" width="0.1524" layer="91"/>
<wire x1="143.51" y1="-49.53" x2="120.65" y2="-49.53" width="0.1524" layer="91"/>
<label x="142.24" y="-49.276" size="1.524" layer="95" rot="MR0"/>
<pinref part="IC2" gate="A" pin="B7"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="A11"/>
<wire x1="144.78" y1="36.83" x2="146.05" y2="35.56" width="0.1524" layer="91"/>
<wire x1="146.05" y1="35.56" x2="172.72" y2="35.56" width="0.1524" layer="91"/>
<label x="147.32" y="35.814" size="1.524" layer="95"/>
</segment>
</net>
<net name="AB8" class="0">
<segment>
<wire x1="144.78" y1="-45.72" x2="143.51" y2="-46.99" width="0.1524" layer="91"/>
<wire x1="143.51" y1="-46.99" x2="120.65" y2="-46.99" width="0.1524" layer="91"/>
<label x="142.24" y="-46.736" size="1.524" layer="95" rot="MR0"/>
<pinref part="IC2" gate="A" pin="B6"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="A8"/>
<wire x1="144.78" y1="44.45" x2="146.05" y2="43.18" width="0.1524" layer="91"/>
<wire x1="146.05" y1="43.18" x2="172.72" y2="43.18" width="0.1524" layer="91"/>
<label x="147.32" y="43.434" size="1.524" layer="95"/>
</segment>
</net>
<net name="AB9" class="0">
<segment>
<wire x1="144.78" y1="-43.18" x2="143.51" y2="-44.45" width="0.1524" layer="91"/>
<wire x1="143.51" y1="-44.45" x2="120.65" y2="-44.45" width="0.1524" layer="91"/>
<label x="142.24" y="-44.196" size="1.524" layer="95" rot="MR0"/>
<pinref part="IC2" gate="A" pin="B5"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="A9"/>
<wire x1="144.78" y1="41.91" x2="146.05" y2="40.64" width="0.1524" layer="91"/>
<wire x1="146.05" y1="40.64" x2="172.72" y2="40.64" width="0.1524" layer="91"/>
<label x="147.32" y="40.894" size="1.524" layer="95"/>
</segment>
</net>
<net name="BCAS2" class="0">
<segment>
<wire x1="144.78" y1="-40.64" x2="143.51" y2="-41.91" width="0.1524" layer="91"/>
<wire x1="143.51" y1="-41.91" x2="120.65" y2="-41.91" width="0.1524" layer="91"/>
<label x="142.24" y="-41.656" size="1.524" layer="95" rot="MR0"/>
<pinref part="IC2" gate="A" pin="B4"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="!CAS2"/>
<wire x1="172.72" y1="12.7" x2="170.18" y2="12.7" width="0.1524" layer="91"/>
<wire x1="170.18" y1="12.7" x2="170.18" y2="10.16" width="0.1524" layer="91"/>
<pinref part="SIMM1" gate="A" pin="!CAS3"/>
<wire x1="170.18" y1="10.16" x2="172.72" y2="10.16" width="0.1524" layer="91"/>
<wire x1="144.78" y1="13.97" x2="146.05" y2="12.7" width="0.1524" layer="91"/>
<wire x1="146.05" y1="12.7" x2="170.18" y2="12.7" width="0.1524" layer="91"/>
<junction x="170.18" y="12.7"/>
<label x="147.32" y="12.954" size="1.524" layer="95"/>
</segment>
</net>
<net name="BCAS0" class="0">
<segment>
<wire x1="144.78" y1="-38.1" x2="143.51" y2="-39.37" width="0.1524" layer="91"/>
<wire x1="143.51" y1="-39.37" x2="120.65" y2="-39.37" width="0.1524" layer="91"/>
<label x="142.24" y="-39.116" size="1.524" layer="95" rot="MR0"/>
<pinref part="IC2" gate="A" pin="B3"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="!CAS0"/>
<wire x1="172.72" y1="17.78" x2="170.18" y2="17.78" width="0.1524" layer="91"/>
<wire x1="170.18" y1="17.78" x2="170.18" y2="15.24" width="0.1524" layer="91"/>
<pinref part="SIMM1" gate="A" pin="!CAS1"/>
<wire x1="170.18" y1="15.24" x2="172.72" y2="15.24" width="0.1524" layer="91"/>
<wire x1="144.78" y1="19.05" x2="146.05" y2="17.78" width="0.1524" layer="91"/>
<wire x1="146.05" y1="17.78" x2="170.18" y2="17.78" width="0.1524" layer="91"/>
<junction x="170.18" y="17.78"/>
<label x="147.32" y="18.034" size="1.524" layer="95"/>
</segment>
</net>
<net name="BRAS0" class="0">
<segment>
<wire x1="144.78" y1="-35.56" x2="143.51" y2="-36.83" width="0.1524" layer="91"/>
<wire x1="143.51" y1="-36.83" x2="120.65" y2="-36.83" width="0.1524" layer="91"/>
<label x="142.24" y="-36.576" size="1.524" layer="95" rot="MR0"/>
<pinref part="IC2" gate="A" pin="B2"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="!RAS0"/>
<wire x1="172.72" y1="30.48" x2="170.18" y2="30.48" width="0.1524" layer="91"/>
<wire x1="170.18" y1="30.48" x2="170.18" y2="25.4" width="0.1524" layer="91"/>
<pinref part="SIMM1" gate="A" pin="!RAS2"/>
<wire x1="170.18" y1="25.4" x2="172.72" y2="25.4" width="0.1524" layer="91"/>
<wire x1="144.78" y1="31.75" x2="146.05" y2="30.48" width="0.1524" layer="91"/>
<wire x1="146.05" y1="30.48" x2="170.18" y2="30.48" width="0.1524" layer="91"/>
<junction x="170.18" y="30.48"/>
<label x="147.32" y="30.734" size="1.524" layer="95"/>
</segment>
</net>
<net name="BRAS1" class="0">
<segment>
<wire x1="144.78" y1="-33.02" x2="143.51" y2="-34.29" width="0.1524" layer="91"/>
<wire x1="143.51" y1="-34.29" x2="120.65" y2="-34.29" width="0.1524" layer="91"/>
<label x="142.24" y="-34.036" size="1.524" layer="95" rot="MR0"/>
<pinref part="IC2" gate="A" pin="B1"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="!RAS1"/>
<wire x1="172.72" y1="27.94" x2="167.64" y2="27.94" width="0.1524" layer="91"/>
<wire x1="167.64" y1="27.94" x2="167.64" y2="22.86" width="0.1524" layer="91"/>
<pinref part="SIMM1" gate="A" pin="!RAS3"/>
<wire x1="167.64" y1="22.86" x2="172.72" y2="22.86" width="0.1524" layer="91"/>
<wire x1="144.78" y1="29.21" x2="146.05" y2="27.94" width="0.1524" layer="91"/>
<wire x1="146.05" y1="27.94" x2="167.64" y2="27.94" width="0.1524" layer="91"/>
<junction x="167.64" y="27.94"/>
<label x="147.32" y="28.194" size="1.524" layer="95"/>
</segment>
</net>
<net name="WE" class="0">
<segment>
<pinref part="IC4" gate="A" pin="Y"/>
<wire x1="144.78" y1="-69.85" x2="143.51" y2="-71.12" width="0.1524" layer="91"/>
<wire x1="143.51" y1="-71.12" x2="118.11" y2="-71.12" width="0.1524" layer="91"/>
<label x="142.24" y="-70.866" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="!WE"/>
<wire x1="144.78" y1="6.35" x2="146.05" y2="5.08" width="0.1524" layer="91"/>
<wire x1="146.05" y1="5.08" x2="172.72" y2="5.08" width="0.1524" layer="91"/>
<label x="147.32" y="5.334" size="1.524" layer="95"/>
</segment>
</net>
<net name="SD9/D8" class="0">
<segment>
<pinref part="J2" gate="A" pin="17"/>
<wire x1="-2.54" y1="-48.26" x2="38.1" y2="-48.26" width="0.1524" layer="91"/>
<label x="36.83" y="-48.006" size="1.524" layer="95" rot="MR0"/>
<wire x1="39.37" y1="-46.99" x2="38.1" y2="-48.26" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D8"/>
<wire x1="223.52" y1="44.45" x2="222.25" y2="43.18" width="0.1524" layer="91"/>
<wire x1="222.25" y1="43.18" x2="205.74" y2="43.18" width="0.1524" layer="91"/>
<label x="220.98" y="43.434" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D24"/>
<wire x1="223.52" y1="3.81" x2="222.25" y2="2.54" width="0.1524" layer="91"/>
<wire x1="222.25" y1="2.54" x2="205.74" y2="2.54" width="0.1524" layer="91"/>
<label x="220.98" y="2.794" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="SD11/D9" class="0">
<segment>
<pinref part="J2" gate="A" pin="19"/>
<wire x1="-2.54" y1="-53.34" x2="38.1" y2="-53.34" width="0.1524" layer="91"/>
<label x="36.83" y="-53.086" size="1.524" layer="95" rot="MR0"/>
<wire x1="39.37" y1="-52.07" x2="38.1" y2="-53.34" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D9"/>
<wire x1="223.52" y1="41.91" x2="222.25" y2="40.64" width="0.1524" layer="91"/>
<wire x1="222.25" y1="40.64" x2="205.74" y2="40.64" width="0.1524" layer="91"/>
<label x="220.98" y="40.894" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D25"/>
<wire x1="223.52" y1="1.27" x2="222.25" y2="0" width="0.1524" layer="91"/>
<wire x1="222.25" y1="0" x2="205.74" y2="0" width="0.1524" layer="91"/>
<label x="220.98" y="0.254" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="SD10/D14" class="0">
<segment>
<pinref part="J2" gate="A" pin="20"/>
<wire x1="-2.54" y1="-55.88" x2="38.1" y2="-55.88" width="0.1524" layer="91"/>
<label x="36.83" y="-55.626" size="1.524" layer="95" rot="MR0"/>
<wire x1="39.37" y1="-54.61" x2="38.1" y2="-55.88" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D14"/>
<wire x1="223.52" y1="29.21" x2="222.25" y2="27.94" width="0.1524" layer="91"/>
<wire x1="222.25" y1="27.94" x2="205.74" y2="27.94" width="0.1524" layer="91"/>
<label x="220.98" y="28.194" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D30"/>
<wire x1="223.52" y1="-11.43" x2="222.25" y2="-12.7" width="0.1524" layer="91"/>
<wire x1="222.25" y1="-12.7" x2="205.74" y2="-12.7" width="0.1524" layer="91"/>
<label x="220.98" y="-12.446" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="SD12/D13" class="0">
<segment>
<pinref part="J2" gate="A" pin="22"/>
<wire x1="-2.54" y1="-60.96" x2="38.1" y2="-60.96" width="0.1524" layer="91"/>
<label x="36.83" y="-60.706" size="1.524" layer="95" rot="MR0"/>
<wire x1="39.37" y1="-59.69" x2="38.1" y2="-60.96" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D13"/>
<wire x1="223.52" y1="31.75" x2="222.25" y2="30.48" width="0.1524" layer="91"/>
<wire x1="222.25" y1="30.48" x2="205.74" y2="30.48" width="0.1524" layer="91"/>
<label x="220.98" y="30.734" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D29"/>
<wire x1="223.52" y1="-8.89" x2="222.25" y2="-10.16" width="0.1524" layer="91"/>
<wire x1="222.25" y1="-10.16" x2="205.74" y2="-10.16" width="0.1524" layer="91"/>
<label x="220.98" y="-9.906" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="SD15/D11" class="0">
<segment>
<pinref part="J2" gate="A" pin="23"/>
<wire x1="-2.54" y1="-63.5" x2="38.1" y2="-63.5" width="0.1524" layer="91"/>
<label x="36.83" y="-63.246" size="1.524" layer="95" rot="MR0"/>
<wire x1="39.37" y1="-62.23" x2="38.1" y2="-63.5" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D11"/>
<wire x1="223.52" y1="36.83" x2="222.25" y2="35.56" width="0.1524" layer="91"/>
<wire x1="222.25" y1="35.56" x2="205.74" y2="35.56" width="0.1524" layer="91"/>
<label x="220.98" y="35.814" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D27"/>
<wire x1="223.52" y1="-3.81" x2="222.25" y2="-5.08" width="0.1524" layer="91"/>
<wire x1="222.25" y1="-5.08" x2="205.74" y2="-5.08" width="0.1524" layer="91"/>
<label x="220.98" y="-4.826" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="SD14/D12" class="0">
<segment>
<pinref part="J2" gate="A" pin="24"/>
<wire x1="-2.54" y1="-66.04" x2="38.1" y2="-66.04" width="0.1524" layer="91"/>
<label x="36.83" y="-65.786" size="1.524" layer="95" rot="MR0"/>
<wire x1="39.37" y1="-64.77" x2="38.1" y2="-66.04" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D12"/>
<wire x1="223.52" y1="34.29" x2="222.25" y2="33.02" width="0.1524" layer="91"/>
<wire x1="222.25" y1="33.02" x2="205.74" y2="33.02" width="0.1524" layer="91"/>
<label x="220.98" y="33.274" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="SIMM1" gate="A" pin="D28"/>
<wire x1="223.52" y1="-6.35" x2="222.25" y2="-7.62" width="0.1524" layer="91"/>
<wire x1="222.25" y1="-7.62" x2="205.74" y2="-7.62" width="0.1524" layer="91"/>
<label x="220.98" y="-7.366" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
</nets>
</sheet>
</sheets>
<errors>
<approved hash="113,1,189.23,19.3675,SIMM1,,,,,"/>
<approved hash="113,1,51.197,-21.1963,JP1,,,,,"/>
<approved hash="113,1,51.197,-54.2163,JP2,,,,,"/>
</errors>
</schematic>
</drawing>
</eagle>
